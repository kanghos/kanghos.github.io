package com.ntels.nidp.mvc.comp.agent.dao;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import com.ntels.nidp.mvc.comp.hive.dao.AnalyzermetaDaoImpl;
import com.ntels.nidp.mvc.comp.hive.domain.AnalyzermetaVo;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"/spring/application-config.xml", "/context/applicationContext-mybatis.xml"})
public class TestAnalzerMetaDao {
	
	@Autowired(required = true) AnalyzermetaDaoImpl daoImpl;
	
//	@Test
	public void insert(){
		AnalyzermetaVo vo = new AnalyzermetaVo();
		vo.setAnlmodtype("hive");
		vo.setDataid(28);
		vo.setModname("sample daya");
		vo.setUseyn(1);
		
		daoImpl.insert(vo);
	}

	//@Test
	public void getAll(){
		List<AnalyzermetaVo> list = daoImpl.getListAll();
		System.out.println(list.toString());
	}
	
	@Test
	public void getById(){
		AnalyzermetaVo vo = new AnalyzermetaVo();
		vo.setAnalyzeseq(2);
		AnalyzermetaVo obj = daoImpl.getById(vo);
		System.out.println(obj.toString());
	}
}
