package com.ntels.nidp.mvc.comp.agent.dao;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ntels.nidp.mvc.comp.collect.dao.CollectDaoImpl;
import com.ntels.nidp.mvc.comp.collect.domain.CollectVo;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"/context/applicationContext-mybatis.xml"})

public class TestCollectInfoImpl {
	@Autowired(required = false)
	private CollectDaoImpl collectDaoImpl;
	
//	@Test
	@Transactional
	public void insert(){
		
		int count = collectDaoImpl.countByDataUrl("room.csv");
		System.out.println("******* count :"+count);
		
		CollectVo collectInfo = new CollectVo();
		 collectInfo.setAgentId(0);
		 collectInfo.setDataCode("none");
		 collectInfo.setDataName("none");
		 collectInfo.setDataType("K");
		 collectInfo.setDataUrl("room.csv");
		 collectInfo.setDataMimeType("CSV");
		 collectInfo.setCreateId("any");
		 collectInfo.setUpdateId("any");
		 int result;
		 result = collectDaoImpl.insertCollect(collectInfo);
		 System.out.println("******* result :"+result);
		 System.out.println("******* result :"+collectInfo.getDataId());
	
		// CollectInfo info =  collectDaoImpl.selectByDataUrl("room.csv");
		 //System.out.println("******* info :"+info.toString());
	}
	
	 @Test
	 public void collect_update_dataname(){
		 CollectVo collectInfo = new CollectVo();
		 collectInfo.setDataId(47);
		 collectInfo.setDataName("sampledata3");
		 collectDaoImpl.updateCollectDataName(collectInfo);
	 }
}
