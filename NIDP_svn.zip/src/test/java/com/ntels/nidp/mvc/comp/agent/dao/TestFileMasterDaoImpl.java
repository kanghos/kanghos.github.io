package com.ntels.nidp.mvc.comp.agent.dao;

import java.util.List;

import javax.jdo.annotations.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ntels.nidp.mvc.comp.hive.dao.FileMasterDaoImpl;
import com.ntels.nidp.mvc.comp.hive.domain.FileMasterVo;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"/spring/application-config.xml", "/context/applicationContext-mybatis.xml"})
public class TestFileMasterDaoImpl {

	@Autowired(required = true) FileMasterDaoImpl daoImpl;
	
	@Transactional
	@Test
	public void insert(){
		//String fileName = fileVo.getFile().getOriginalFilename();
		FileMasterVo fileMasterVo = new FileMasterVo();
		fileMasterVo.setFilenm("sam.csv");
		fileMasterVo.setFileuri("/hom/hadoop");
		fileMasterVo.setSvrid("none");
		fileMasterVo.setDescription("sample");
		fileMasterVo.setCreateid(1111);
		fileMasterVo.setDataid(22);
		fileMasterVo.setFiletype("csv");
		daoImpl.insert(fileMasterVo);
	}
	
	@Test
	public void selectAll(){
		List<FileMasterVo> list =  daoImpl.getListById(22);
		System.out.println(list.toString());
	}
}
