package com.ntels.nidp.mvc.comp.agent.dao;

import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ntels.nidp.mvc.comp.hive.dao.HiveqlDaoImpl;
import com.ntels.nidp.mvc.comp.hive.domain.HiveqlVo;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"/spring/application-config.xml", "/context/applicationContext-mybatis.xml"})
public class TestHiveqlDaoImpl {
	
	@Autowired HiveqlDaoImpl daoImpl;
	
//	@Test
	public void select(){
		HiveqlVo hiveqlVo = new HiveqlVo();
		hiveqlVo.setAnalyzeseq(2);
		List<HiveqlVo> listById = daoImpl.getListById(hiveqlVo);
		System.out.println(listById.toString());
	}
	
	//@Test
	public void string_test(){
		String aa = null;
		System.out.println(new String(aa).isEmpty());
	}

	@Test
	public void string_test_split(){
		String outputFilePath = "C:\\Users\\in-3\\Documents\\ubuntuShareFolder\\tempFile\\result_2014-01-29_114946.csv";
		String bb = FilenameUtils.getName(outputFilePath);
		System.out.println(bb);
	}
	
}
