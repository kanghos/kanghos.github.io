package com.ntels.nidp.mvc.comp.agent.dao;

import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ntels.nidp.mvc.comp.agent.domain.AgentVo;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"/context/applicationContext-mybatis.xml"})
@Transactional
public class AgentDaoImplTest {

	@Autowired(required = false) 
	private ApplicationContext context;
	private AgentDaoImpl agentDaoImpl;
	
	@Before
	 public void setUp(){
	  this.agentDaoImpl = this.context.getBean("agentDao", AgentDaoImpl.class);
	}

	private AgentVo getAgentTestData() throws Exception {
		AgentVo agentInfo = new AgentVo();
		agentInfo.setAgentName("AGENT");
		agentInfo.setCreateId("JHLIM");
		agentInfo.setUpdateId("JHLIM");
		return agentInfo;
	}
	
	@Test
	public void testAgentCRUD() throws Exception{
		
		List<AgentVo> agentList = agentDaoImpl.selectAgentAll();
		Assert.assertTrue(agentList.size() > 0);
		
		//AgentInfo agentInfo = getAgentTestData();
		//Assert.assertEquals(1, agentDaoImpl.insertAgent(agentInfo));
		
		//Assert.assertEquals(1, agentDaoImpl.updateAgent(agentInfo));
		
		//Assert.assertEquals(1, agentDaoImpl.deleteAgent(agentInfo));
		
	}

}
