package util;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.RedirectException;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CookieStore;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.params.ClientPNames;
import org.apache.http.client.protocol.ClientContext;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ntels.nidp.mvc.comp.hive.domain.FileStatus;
import com.ntels.nidp.mvc.comp.hive.domain.FileStatuses;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="/spring/application-config.xml")
public class TestHttp {

	private final String NODE_NAME_1_IP="218.239.45.37"; 
	private final String NODE_NAME_2_IP="218.239.45.36"; 
	private final String NODE_NAME_1="nidpdata1";
	private final String NODE_NAME_2="nidpdata2"; 
	private final String FIEL_TEMP_FOLDER_PATH="C:\\Users\\in-3\\Documents\\ubuntuShareFolder\\tempFile\\"; 
	
	@Test
	public void parse(){
		String reMakeUrl="http://218.239.45.37:50075/webhdfs/v1/tmp/test2.txt?op=OPEN&offset=0";
		String[] aa = reMakeUrl.split("\\?")[0].split("/");
		System.out.println("***aa="+aa[aa.length-1]);
	}
	
	//@Test
	public void webhdfs_read_file_and_download(){
		String url="http://218.239.45.37:50070/webhdfs/v1/user/hive/warehouse/sample/sampledata.csv?op=OPEN";
		String redirectUrl = get_redirect_url(url);
		String nodeName = redirectUrl.substring(7).toString().split(":")[0].toString();
		System.out.println("***nodeName="+nodeName);
		
		String reMakeUrl = null;
		if(NODE_NAME_1.equals(nodeName)){
			reMakeUrl = redirectUrl.replace(NODE_NAME_1, NODE_NAME_1_IP);
		}else if(NODE_NAME_2.equals(nodeName)){
			reMakeUrl = redirectUrl.replace(NODE_NAME_2, NODE_NAME_2_IP);
		}
		System.out.println("***reMakeUrl="+reMakeUrl);
		
		read_file_from_hdfs_and_make_file_into_server(reMakeUrl);
	}
	
	private boolean read_file_from_hdfs_and_make_file_into_server(String reMakeUrl){
		boolean isCreateFile = true;
		
		HttpClient httpclient = new DefaultHttpClient();
		try {
			// HttpGet생성
			HttpGet httpget = new HttpGet(reMakeUrl);
			HttpResponse response = httpclient.execute(httpget);
			HttpEntity entity = response.getEntity();
			
			System.out.println("----------------------------------------");
			// 응답 결과
			if (entity != null) {
				System.out.println("Response content length: "+ entity.getContentLength());
				BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
 
				FileWriter fileWriter = new FileWriter(FIEL_TEMP_FOLDER_PATH+"sampledata.csv");
				String line = "";
				while ((line = rd.readLine()) != null) {
					String lines = line+"\n";
					fileWriter.write(line);
				}
				fileWriter.close();
				rd.close();
			}
			httpget.abort();
			System.out.println("----------------------------------------");
			httpclient.getConnectionManager().shutdown();
 
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			httpclient.getConnectionManager().shutdown();
		}
		
		return isCreateFile;
	}
	
	private String get_redirect_url(String url){
		HttpClient httpclient = new DefaultHttpClient();
		// HTTP parameters stores header etc.
		HttpParams params = new BasicHttpParams();
		params.setParameter(ClientPNames.HANDLE_REDIRECTS, Boolean.FALSE);
		//HttpGet생성
		HttpGet httpget = new HttpGet(url);
		httpget.setParams(params);
		String redirectLocation = null;
		
		try {
			HttpResponse response = httpclient.execute(httpget);
			org.apache.http.Header locationHeader = response.getFirstHeader("location");
			if (response.getStatusLine().getStatusCode() == 307 && locationHeader != null) {
			    redirectLocation = locationHeader.getValue();
			    System.out.println("loaction: " + redirectLocation);
			}
			httpget.abort();
			httpclient.getConnectionManager().shutdown();
		}catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return redirectLocation;
	}
	
	//@Test
	public void http_get_test1(){
		String urlpre="http://218.239.45.37:50070/webhdfs/v1/";
		String urlsub="?op=LISTSTATUS";	
		String url =urlpre+urlsub;
		
		String json = getHttp(url);
		JSONObject jsonObject = JSONObject.fromObject( json ).getJSONObject("FileStatuses");
		
		int length = jsonObject.getJSONArray("FileStatus").size();
		//for (int i = 0; i < length; i++) {
			String urldept2="";
			JSONArray  object = jsonObject.getJSONArray("FileStatus");
			String ps = object.getJSONObject(0).getString("pathSuffix");
			urldept2 += ps;
			String json2 = getHttp(urlpre+urldept2+urlsub);
			JSONArray jsonObject2 = JSONObject.fromObject( json2 ).getJSONObject("FileStatuses").getJSONArray("FileStatus");
			object.getJSONObject(0).accumulate("children", jsonObject2);
		//}
			System.out.println("object ="+object);
			System.out.println("jsonObject ="+jsonObject);
	}
	
	//@Test
	public void use_webhdfs_api_liststatus(){
		String urlpre="http://218.239.45.37:50070/webhdfs/v1/";
		String urlsub="?op=LISTSTATUS";	
		String url =urlpre+urlsub;
		//String url ="http://218.239.45.37:50070/webhdfs/v1/user/hive/warehouse?op=LISTSTATUS";
		
		String json = getHttp(url);
		
		JSONObject jsonObject = JSONObject.fromObject( json ).getJSONObject("FileStatuses");
		FileStatuses fileStatuses = new FileStatuses();
		fileStatuses.setChildren((List<FileStatus>) jsonObject.get("FileStatus"));
		fileStatuses.setText(".");
		
		System.out.println(fileStatuses);
		
		
		int dept1=fileStatuses.getChildren().size();
		for (int i = 0; i < dept1; i++) {
			String urldept ="";
			JSONObject ele = JSONObject.fromObject(fileStatuses.getChildren().get(i));
			//System.out.println("** ele="+ele);
			FileStatus obj = (FileStatus) JSONObject.toBean(ele, FileStatus.class);
			urldept +=obj.getPathSuffix();
			String json1 = getHttp(urlpre+urldept+urlsub);
			JSONObject jsonObject1 = JSONObject.fromObject( json1 ).getJSONObject("FileStatuses");
			obj.setChildren((List<FileStatus>) jsonObject1.get("FileStatus"));
			fileStatuses.getChildren().set(i, obj);
			
			
			int dept2=obj.getChildren().size();
			for (int j = 0; j < dept2; j++) {
				String urldept2 = urldept;
				
				JSONObject ele2 = JSONObject.fromObject(obj.getChildren().get(j));
				//System.out.println("** ele2="+ele2);
				FileStatus obj2 = (FileStatus) JSONObject.toBean(ele2, FileStatus.class);
				
				urldept2 +="/"+obj2.getPathSuffix();
				String json2 = getHttp(urlpre+urldept2+urlsub);
				JSONObject jsonObject2 = JSONObject.fromObject( json2 ).getJSONObject("FileStatuses");
				obj2.setChildren((List<FileStatus>) jsonObject2.get("FileStatus"));
				obj.getChildren().set(j, obj2);
				fileStatuses.getChildren().set(i, obj);
			
				int dept3=obj2.getChildren().size();
				for (int k = 0; k < dept3; k++) {
					String urldept3 = urldept2;
					JSONObject ele3 = JSONObject.fromObject(obj2.getChildren().get(k));
					//System.out.println("** ele3="+ele3);
					FileStatus obj3 = (FileStatus) JSONObject.toBean(ele3, FileStatus.class);
					
					urldept3 +="/"+obj3.getPathSuffix();
					if(urldept3.contains("WIUX")) {
						break;
					}else if(urldept3.contains("twitter")){
						break;
					}else if(urldept3.contains("weather")){
						break;
					}
					
					String json3 = getHttp(urlpre+urldept3+urlsub);
					JSONObject jsonObject3 = JSONObject.fromObject( json3 ).getJSONObject("FileStatuses");
					obj3.setChildren((List<FileStatus>) jsonObject3.get("FileStatus"));
					
					obj2.getChildren().set(k, obj3);
					obj.getChildren().set(j, obj2);
					fileStatuses.getChildren().set(i, obj);
				
					int dept4=obj3.getChildren().size();
					for (int l = 0; l < dept4; l++) {
						String urldept4 = urldept3;
						JSONObject ele4 = JSONObject.fromObject(obj3.getChildren().get(l));
						//System.out.println("** ele3="+ele3);
						FileStatus obj4 = (FileStatus) JSONObject.toBean(ele4, FileStatus.class);
						
						urldept4 +="/"+obj4.getPathSuffix();
						if(urldept4.contains("WIUX")) {
							break;
						}else if(urldept4.contains("twitter")){
							break;
						}else if(urldept4.contains("weather")){
							break;
						}
						
						String json4 = getHttp(urlpre+urldept4+urlsub);
						JSONObject jsonObject4 = JSONObject.fromObject( json4 ).getJSONObject("FileStatuses");
						obj4.setChildren((List<FileStatus>) jsonObject4.get("FileStatus"));
						
						
						int thisObjLength = obj4.getChildren().size();
						for (int m = 0; m < thisObjLength; m++) {
							JSONObject thisEle = JSONObject.fromObject(obj4.getChildren().get(m));
							String type = thisEle.getString("type");
							String fileName = thisEle.getString("pathSuffix");
							if("FILE".equals(type)){
								thisEle.accumulate("leaf", true);
								thisEle.accumulate("path", urlpre+urldept4+"/"+fileName);
							}
							FileStatus thisObj = (FileStatus) JSONObject.toBean(thisEle, FileStatus.class);
							obj4.getChildren().set(m, thisObj);
						}
						
						obj3.getChildren().set(l, obj4);
						obj2.getChildren().set(k, obj3);
						obj.getChildren().set(j, obj2);
						fileStatuses.getChildren().set(i, obj);
					}
					
				}
				
			}
			
			System.out.println("**fileStatuses="+fileStatuses);
		}
	}
	
	private String getHttp(String url){
		System.out.println("*** url="+url);
		HttpClient httpclient = new DefaultHttpClient();
		StringBuffer sb = new StringBuffer();
		try {
			// HttpGet생성
			HttpGet httpget = new HttpGet(url);
			//httpget.setHeader("Accept", "application/json");
			//httpget.setHeader("Content-Type", "application/json");
			//httpget.setHeader("Content-Type", "text/plain; charset=utf-8");
			HttpResponse response = httpclient.execute(httpget);
			HttpEntity entity = response.getEntity();
			
			System.out.println("----------------------------------------");
			// 응답 결과
			System.out.println(response.getStatusLine());
			if (entity != null) {
				System.out.println("Response content length: "
						+ entity.getContentLength());
				BufferedReader rd = new BufferedReader(new InputStreamReader(
						response.getEntity().getContent()));
 
				String line = "";
				while ((line = rd.readLine()) != null) {
					sb.append(line);
				}
				rd.close();
			}
			httpget.abort();
			System.out.println("----------------------------------------");
			httpclient.getConnectionManager().shutdown();
 
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			httpclient.getConnectionManager().shutdown();
		}
		
		return sb.toString();
	}
	
}
