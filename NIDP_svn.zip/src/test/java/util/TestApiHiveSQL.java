package util;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.hive.ql.parse.SemanticException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ntels.nidp.common.utils.ApiHiveSQL;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="/spring/application-config.xml")
public class TestApiHiveSQL{

	final static String FOLDER_PATH ="/usr/local/hive-0.11.0/examples/files/"; 
	
//	@Test
	public void TestCreateTable(){
		String query = "pokes (foo INT, bar STRING)";
		boolean createTable = ApiHiveSQL.getInstance().createTable(query);
		System.out.println("** TestCreateTable :"+createTable);
	}
	
//	@Test
	public void TestCreateExternalTable(){
		
	}
	
//	@Test
	public void TesetDataLoad(){
		String tableName = "pokes";
		String fileName = "kv1.txt";
//		String fileName = "pokes.txt";
//		String fileName = "pokes.csv";
		String localPath = FOLDER_PATH + fileName;
		boolean dataLoad = ApiHiveSQL.getInstance().dataLoad(tableName, localPath);
		System.out.println("** TesetDataLoad data load :"+dataLoad);
		
		String sql = "select * from pokes";
		List<String> columnLabelList = new ArrayList<String>();
		columnLabelList.add("foo");
		columnLabelList.add("bar");
		List<Map<String, String>> selectTableAsList = ApiHiveSQL.getInstance().selectTableAsList(sql, columnLabelList);
		System.out.println("** TesetDataLoad select rows :"+selectTableAsList.toString());
	}
	
//	@Test
	public void TestSelectTable(){
	}
	
//	@Test
	public void TestSelectTableAsList(){
		String sql = "select * from citi";
		List<String> columnLabelList = new ArrayList<String>();
		columnLabelList.add("citing");
		columnLabelList.add("cited");
		List<Map<String, String>> selectTableAsList = ApiHiveSQL.getInstance().selectTableAsList(sql, columnLabelList);
		System.out.println("** TestSelectTable :"+selectTableAsList.toString());		
	}
	
//	@Test
	public void TestGetTables(){
		String sql = "show tables";
		List<String> tables = ApiHiveSQL.getInstance().getTables(sql);
		System.out.println("** TestGetTables :"+tables.toString());		
	}
	
//	@Test
	public void TestDropTable(){
		String tableName = "pokes";
		boolean dropTable = false;
		dropTable = ApiHiveSQL.getInstance().dropTable(tableName);
		System.out.println("** TestDropTable "+dropTable);
	}
	
//	@Test
	public void TestDescribeTable(){
		String tableName = "pokes";
		List<Map<String, String>> describeTable = ApiHiveSQL.getInstance().describeTable(tableName);
		System.out.println("** TestDescribeTable [ "+tableName+" ]="+describeTable);
	}
	
//	@Test
	public void TestgetReultAsCSVFile(){
		String sql = "select * from pokes";
		String outputFilePath = ApiHiveSQL.getInstance().getOutputFilePath(null);
		boolean reultAsCSVFile = ApiHiveSQL.getInstance().ouputFileAsCSV(sql, outputFilePath);
	}
	
	@Test
	public void get_columns_by_tablename(){
		getColumnsForTalble("airport");
	}
	
	
	private String getColumnsForTalble(String tableName) {
		List<Map<String, String>> result = ApiHiveSQL.getInstance().describeTable(tableName);
		System.out.println(result);
		StringBuffer sb = new StringBuffer();
		int length = result.size();
		
		for (int i = 0; i < length; i++) {
			appendColumns(result, sb, length, i);
		}
		
		System.out.println("colums ="+sb);
		return sb.toString();
	}

	private void appendColumns(List<Map<String, String>> result, StringBuffer sb, int length, int i) {
		String  columnWithComment =	"{0} {1} comment ''{2}''";
		String  column = "{0} {1}";
		
		Map<String, String> map = result.get(i);
		String cName = map.get("columnName");
		String type = map.get("type");
		String comment = map.get("comment");

		if("None".equals(comment)){
			sb.append(MessageFormat.format(column, cName, type));
		}else {
			sb.append(MessageFormat.format(columnWithComment, cName, type, comment));
		}
		
		if(length != i+1){
			sb.append(", ");
		}
	}
	
}
