package util;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="/spring/application-config.xml")
public class TestApiHiveConn{

	private static String driverName = "org.apache.hadoop.hive.jdbc.HiveDriver";
	private static Connection conn = null;

	final static String FOLDER_PATH ="/usr/local/hive-0.11.0/examples/files/"; 
	final static String QUERY_LOAD_DATA ="load data local inpath \"{0}\" overwrite into table {1}"; 
	final static String QUERY_CREATE_TABLE ="load data local inpath \"{0}\" overwrite into table {1}"; 
	
	@Before
	public void init(){
		try {
			Class.forName(driverName);
			conn = DriverManager.getConnection("jdbc:hive://192.168.56.101:10000/hive","hiveid","hivepass");
			System.out.println("*** CONNECTED ***");
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
/*	@After
	public void close(){

	}
*/	
	//@Test
	public void select() {
		List<String> columnLabelList = new ArrayList<String>();
		columnLabelList.add("citing");
		columnLabelList.add("cited");
		List<Map<String, String>> selectTableAsList = getSQLAsList("select * from citi limit 2", columnLabelList);
		System.out.println(selectTableAsList.toString());
	}
	
	@Test
	public void TestLoadFile(){
		String fileName = "citi-data.csv";
		String tableName = "citi";
		loadData(fileName, tableName);
	}
	
	
	private String getQuery(String fileName, String tableName){
		String filePath = FOLDER_PATH+fileName;
		String query = MessageFormat.format(QUERY_LOAD_DATA, filePath, tableName).toString();
		System.out.println("*** query :"+query);
		return query;
	}
	
	private boolean loadData(String fileName, String tableName){
		String query = getQuery(fileName, tableName);
		Statement stmt = null;
		ResultSet res = null;
		try {
			stmt = conn.createStatement();
			res = stmt.executeQuery(query);
			result(res);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close(conn, stmt, res);
		}
		return true;
	}
	
	
	private void result(ResultSet res){
		System.out.println("result : " + res.toString());

		try {
			while (res.next()) {
				System.out.println("result : " + res.getString(0));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private List<Map<String, String>> getSQLAsList(String sql, List<String> columnLabelList) {
		System.out.println("ApiJDBCHiveBase getSelectSQL()");
		//Connection conn = null;
		Statement stmt = null;
		ResultSet res = null;
		String column = "";

		List<Map<String, String>> result = new ArrayList<Map<String, String>>();
		
		try {
			System.out.println("ApiJDBCHiveBase getSelectSQL() -------------- sql : " + sql);
			//conn = getConnection();
			stmt = conn.createStatement();
			res = stmt.executeQuery(sql);
			int columnLabelListSize = columnLabelList.size();
			
			while (res.next()) {
				Map<String, String> map = new HashMap<String, String>();
				for(int i = 0; i < columnLabelListSize; i++) {
					column = columnLabelList.get(i);
					System.out.println("HiveJDBCClient getSelectSQL() -------------- column : " + column);
					System.out.println("HiveJDBCClient getSelectSQL() --------------  value : " + res.getString(column.trim()));
					
					String value = res.getString(column.trim());
					map.put(column, value == null ? "0" : value);
				}
				result.add(map);
			}
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			close(conn, stmt, res);
		}
		return result;
	}

	
	private void close(Connection conn, Statement stmt, ResultSet rs) {
		System.out.println("*** Closed ***");
		if(rs!=null) { 
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(stmt!=null) {
			try {
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(conn!=null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
}
