function d3_true() {
  return true;
}
