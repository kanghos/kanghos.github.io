
Map = function(){
 this.map = new Object();
};   
Map.prototype = {   
    put : function(key, value){   
        this.map[key] = value;
    },   
    get : function(key){   
        return this.map[key];
    },
    containsKey : function(key){    
     return key in this.map;
    },
    containsValue : function(value){    
     for(var prop in this.map){
      if(this.map[prop] == value) return true;
     }
     return false;
    },
    isEmpty : function(key){    
     return (this.size() == 0);
    },
    clear : function(){   
     for(var prop in this.map){
      delete this.map[prop];
     }
    },
    remove : function(key){    
     delete this.map[key];
    },
    keys : function(){   
        var keys = new Array();   
        for(var prop in this.map){   
            keys.push(prop);
        }   
        return keys;
    },
    values : function(){   
     var values = new Array();   
        for(var prop in this.map){   
         values.push(this.map[prop]);
        }   
        return values;
    },
    size : function(){
      var count = 0;
      for (var prop in this.map) {
        count++;
      }
      return count;
    }
};


/**
 * 
 */

// linking the key-value-pairs is optional
// if no argument is provided, linkItems === undefined, i.e. !== false
// --> linking will be enabled
/*function Map(linkItems) {
    this.current = undefined;
    this.size = 0;

    if(linkItems === false)
        this.disableLinking();
}

Map.noop = function() {
    return this;
};

Map.illegal = function() {
    throw new Error("illegal operation for maps without linking");
};

// map initialisation from existing object
// doesn't add inherited properties if not explicitly instructed to:
// omitting foreignKeys means foreignKeys === undefined, i.e. == false
// --> inherited properties won't be added
Map.from = function(obj, foreignKeys) {
    var map = new Map;

    for(var prop in obj) {
        if(foreignKeys || obj.hasOwnProperty(prop))
            map.put(prop, obj[prop]);
    }

    return map;
};

Map.prototype.disableLinking = function() {
    this.link = Map.noop;
    this.unlink = Map.noop;
    this.disableLinking = Map.noop;
    this.next = Map.illegal;
    this.key = Map.illegal;
    this.value = Map.illegal;
    this.removeAll = Map.illegal;

    return this;
};

// overwrite in Map instance if necessary
Map.prototype.hash = function(value) {
    return (typeof value) + ' ' + (value instanceof Object ?
        (value.__hash || (value.__hash = ++arguments.callee.current)) :
        value.toString());
};

Map.prototype.hash.current = 0;

// --- mapping functions

Map.prototype.get = function(key) {
    var item = this[this.hash(key)];
    return item === undefined ? undefined : item.value;
};

Map.prototype.put = function(key, value) {
    var hash = this.hash(key);

    if(this[hash] === undefined) {
        var item = { key : key, value : value };
        this[hash] = item;

        this.link(item);
        ++this.size;
    }
    else this[hash].value = value;

    return this;
};

Map.prototype.remove = function(key) {
    var hash = this.hash(key);
    var item = this[hash];

    if(item !== undefined) {
        --this.size;
        this.unlink(item);

        delete this[hash];
    }

    return this;
};

// only works if linked
Map.prototype.removeAll = function() {
    while(this.size)
        this.remove(this.key());

    return this;
};

// --- linked list helper functions

Map.prototype.link = function(item) {
    if(this.size == 0) {
        item.prev = item;
        item.next = item;
        this.current = item;
    }
    else {
        item.prev = this.current.prev;
        item.prev.next = item;
        item.next = this.current;
        this.current.prev = item;
    }
};

Map.prototype.unlink = function(item) {
    if(this.size == 0)
        this.current = undefined;
    else {
        item.prev.next = item.next;
        item.next.prev = item.prev;
        if(item === this.current)
            this.current = item.next;
    }
};

// --- iterator functions - only work if map is linked

Map.prototype.next = function() {
    this.current = this.current.next;
};

Map.prototype.key = function() {
    return this.current.key;
};

Map.prototype.value = function() {
    return this.current.value;
};*/



/*
 =====================================================================
 @license MIT
 @author Daniel Kwiecinski <daniel.kwiecinski@lambder.com>
 @copyright 2009 Daniel Kwiecinski.
 @end
 =====================================================================
 */
/*var HashMap = function() {
  this.initialize();
 // alert("init!");
}

HashMap.prototype = {
  hashkey_prefix: "<#HashMapHashkeyPerfix>",
  hashcode_field: "<#HashMapHashkeyPerfix>",

  initialize: function() {
    this.backing_hash = {};
    this.code = 0;
  },
  
   maps value to key returning previous assocciation
   
  put: function(key, value) {
    var prev;
    if (key && value) {
      var hashCode = key[this.hashcode_field];
      if (hashCode) {
        prev = this.backing_hash[hashCode];
      } else {
        this.code += 1;
        hashCode = this.hashkey_prefix + this.code;
        key[this.hashcode_field] = hashCode;
      }
      this.backing_hash[hashCode] = value;
    }
    return prev;
  },
  
   returns value associated with given key
   
  get: function(key) {
    var value;
    if (key) {
      var hashCode = key[this.hashcode_field];
      if (hashCode) {
        value = this.backing_hash[hashCode];
      }
    }
    return value;
  },
  
   deletes association by given key.
   Returns true if the assocciation existed, false otherwise
   
  del: function(key) {
    var success = false;
    if (key) {
      var hashCode = key[this.hashcode_field];
      if (hashCode) {
        var prev = this.backing_hash[hashCode];
        this.backing_hash[hashCode] = undefined;
        if(prev !== undefined)
          success = true;
      }
    }
    return success;
  }
}*/


function createRequestObject() {  //object 생성이 가능한 브라우저인지 확인.

	   var req;

	   if(window.XMLHttpRequest){
	      // Firefox, Safari, Opera...
	      req = new XMLHttpRequest();
	   } else if(window.ActiveXObject) {
	      // Internet Explorer 5+
	      req = new ActiveXObject("Microsoft.XMLHTTP");
	   } else {

	     alert("Your Browser Does Not Support This Script - Please Upgrade Your Browser ASAP");
	   }

	   return req;

	}


function SetActivePageView(url, w, h)
{
	var div = document.createElement('div');
	div.style.position = "absolute";
	div.style.display = "block";
	div.style.zIndex = 9999;
	div.setAttribute("id", "activeLayerDiv");
	div.style.width 		=w;
	div.style.height 	= h;
	
	var overDiv = document.createElement('div');
	overDiv.style.position = "absolute";
	overDiv.style.display = "block";
	overDiv.style.zIndex = 99999;
	overDiv.setAttribute("name", "overLayerDiv");
	//div.onmouseup = methodize(this.stopMoving, this);   
	overDiv.style.width 	=w-35;
	overDiv.style.height 	= 32;
	
	
	div.innerHTML = "<table border='0' cellpadding='0' cellspacing='0' ><tr><td><iframe name='activeLayerFrame' src='"+url+"' id='activeLayerFrame' allowtransparency='true' width='"+w+"'height='"+h+"' frameborder='0' marginWidth='0' marginHeight='0' scrolling='yes' ></iframe></td></tr></table>";
	overDiv.innerHTML ="<table  width='"+(w-35)+"' height='32'><tr><td></td></tr></talbe>"
//$("activeLayerDiv").onmouseover = function(){SetActivePopScoll();}
	overDiv.style.left = 18 + "%";
	overDiv.style.top = 150 + "px";
	
	div.style.left = 18 + "%";
	div.style.top = 150 + "px"; 
	
	document.body.appendChild(div);
	overDiv.onmouseover=function(){overDiv.style.cursor="hand"; };
	overDiv.onmousedown=function(){PopMove2(event,div,this); };
	overDiv.onmouseup=Function("MoveEnabled=false");

	document.body.appendChild(overDiv);
}
function PopMove2(e,obj,tObj){

	
    MoveEnabled=true;

    document.onmousemove=function(){PopMove(e,obj,tObj);};
}

 

function PopMove(e,obj,tObj){
	
    if (!MoveEnabled) return; 
    x = window.event.clientX  ;
    y = window.event.clientY ;
    obj.style.left = x;
    obj.style.top = y;
    tObj.style.left = x; 
    tObj.style.top = y;
    
    mouseX = window.event.clientX;
    mouseY = window.event.clientY;
    
   
    return false;
}


/* ----------------------------------------------------------------------------
 * 특정 날짜에 대해 지정한 값만큼 가감(+-)한 날짜를 반환

 * 

 * 입력 파라미터 -----
 * pInterval : "yyyy" 는 연도 가감, "m" 은 월 가감, "d" 는 일 가감
 * pAddVal  : 가감 하고자 하는 값 (정수형)
 * pYyyymmdd : 가감의 기준이 되는 날짜
 * pDelimiter : pYyyymmdd 값에 사용된 구분자를 설정 (없으면 "" 입력)

 * 

 * 반환값 ----

 * yyyymmdd 또는 함수 입력시 지정된 구분자를 가지는 yyyy?mm?dd 값
 *

 * 사용예 ---

 * 2008-01-01 에 3 일 더하기 ==> addDate("d", 3, "2008-08-01", "-");

 * 20080301 에 8 개월 더하기 ==> addDate("m", 8, "20080301", "");
 --------------------------------------------------------------------------- */
function addDate(pInterval, pAddVal, pYyyymmdd, pDelimiter)
{
 var yyyy;
 var mm;
 var dd;
 var cDate;
 var oDate;
 var cYear, cMonth, cDay;
 
 if (pDelimiter != "") {
  pYyyymmdd = pYyyymmdd.replace(eval("/\\" + pDelimiter + "/g"), "");
 }
 

 yyyy = pYyyymmdd.substr(0, 4);
 mm  = pYyyymmdd.substr(4, 2);
 dd  = pYyyymmdd.substr(6, 2);
 
 if (pInterval == "yyyy") {
  yyyy = (yyyy * 1) + (pAddVal * 1); 
 } else if (pInterval == "m") {
  mm  = (mm * 1) + (pAddVal * 1);
 } else if (pInterval == "d") {
  dd  = (dd * 1) + (pAddVal * 1);
 }
 

 cDate = new Date(yyyy, mm - 1, dd) // 12월, 31일을 초과하는 입력값에 대해 자동으로 계산된 날짜가 만들어짐.
 cYear = cDate.getFullYear();
 cMonth = cDate.getMonth() + 1;
 cDay = cDate.getDate();
 
 cMonth = cMonth < 10 ? "0" + cMonth : cMonth;
 cDay = cDay < 10 ? "0" + cDay : cDay;

 

 if (pDelimiter != "") {
  return cYear + pDelimiter + cMonth + pDelimiter + cDay;
 } else {
  return cYear + cMonth + cDay;
 }
 
}




