
<!-- //소셜스코어검색 부분 클릭시 글씨사라지는 태그
function Clickcheck_form()
{
 var f = document.entry;
 if(f.check.value == f.check.defaultValue) { f.check.value = ""; }
}

//-->

//스크린샷 팝업 좌우 컨트롤 제이쿼리
$(document).ready(function(){
	$(".awareness_btn").click(function () {
			$(".quality").show();
			$(".awareness").hide();
			});

			$(".quality_lebtn").click(function () {
			$(".awareness").show();
			$(".quality").hide();
			});

			$(".quality_ribtn").click(function () {
			$(".infull").show();
			$(".quality").hide();
			});

			$(".infull_lebtn").click(function () {
			$(".quality").show();
			$(".infull").hide();
			});

			$(".infull_ribtn").click(function () {
			$(".issue").show();
			$(".infull").hide();
			});

			$(".issue_lebtn").click(function () {
			$(".infull").show();
			$(".issue").hide();
			});

			$(".awareness_pag").click(function () {
			$(".awareness").show();
			$(".quality, .infull, .issue").hide();
			});

			$(".quality_pag").click(function () {
			$(".quality").show();
			$(".awareness, .infull, .issue").hide();
			});

			$(".infull_pag").click(function () {
			$(".infull").show();
			$(".awareness, .quality, .issue").hide();
			});

			$(".issue_pag").click(function () {
			$(".issue").show();
			$(".awareness, .quality, .infull").hide();
			});

			$(".close").click(function () {
			$(".awareness").show();
			$(".quality, .infull, .issue").hide();
			});
////////////////////listening끝

			$(".inform_btn, .monitoring_pag").click(function () {
			$(".monitoring").show();
			$(".inform").hide();
			});

			$(".monitoring_btn, .inform_pag").click(function () {
			$(".inform").show();
			$(".monitoring").hide();
			});

			$(".close2").click(function () {
			$(".inform").show();
			$(".monitoring").hide();
			});
///////////////////crisis끝
			$(".comparison_btn, .combination_pag").click(function () {
			$(".combination").show();
			$(".comparison").hide();
			});

			$(".combination_btn, .comparison_pag").click(function () {
			$(".comparison").show();
			$(".combination").hide();
			});

			$(".close3").click(function () {
			$(".comparison").show();
			$(".combination").hide();
			});
///////////////////
			$(".business_btn, .tag_pag").click(function () {
			$(".tag").show();
			$(".business").hide();
			});

			$(".tag_btn, .business_pag").click(function () {
			$(".business").show();
			$(".tag").hide();
			});

			$(".close4").click(function () {
			$(".business").show();
			$(".tag").hide();
			});
///////////////////
			$(".creation_btn, .extrafeatures_pag").click(function () {
			$(".extrafeatures").show();
			$(".creation").hide();
			});

			$(".extrafeatures_btn, .creation_pag").click(function () {
			$(".creation").show();
			$(".extrafeatures").hide();
			});

			$(".close5").click(function () {
			$(".creation").show();
			$(".extrafeatures").hide();
			});
		});

$(document).ready(function(){
$('.link, .screenview').bind('click', function (e) {
    e.preventDefault();
 });
});
//서비스특징, 펄스-k 주요기능 부분
$(document).ready(function(){
		//좌측 이동
		$(".major_right01").click(function () {
		$(".major02").show();
		$(".major01").hide();
		});
		$(".major_right02").click(function () {
		$(".major03").show();
		$(".major02").hide();
		});
		$(".major_right03").click(function () {
		$(".major04").show();
		$(".major03").hide();
		});
		$(".major_right04").click(function () {
		$(".major05").show();
		$(".major04").hide();
		});
		$(".major_right05").click(function () {
		$(".major06").show();
		$(".major05").hide();
		});
		$(".major_right06").click(function () {
		$(".major07").show();
		$(".major06").hide();
		});
		$(".major_right07").click(function () {
		$(".major01").show();
		$(".major07").hide();
		});
		//우측 이동
		$(".major_left01").click(function () {
		$(".major07").show();
		$(".major01").hide();
		});
		$(".major_left07").click(function () {
		$(".major06").show();
		$(".major07").hide();
		});
		$(".major_left06").click(function () {
		$(".major05").show();
		$(".major06").hide();
		});
		$(".major_left05").click(function () {
		$(".major04").show();
		$(".major05").hide();
		});
		$(".major_left04").click(function () {
		$(".major03").show();
		$(".major04").hide();
		});
		$(".major_left03").click(function () {
		$(".major02").show();
		$(".major03").hide();
		});
		$(".major_left02").click(function () {
		$(".major01").show();
		$(".major02").hide();
		});
		//제목클릭시 변경
		$(".major_con01").click(function () {
		$(".major01").show();
		$(".major02,.major03,.major04,.major05,.major06,.major07").hide();
		});
		$(".major_con02").click(function () {
		$(".major02").show();
		$(".major01,.major03,.major04,.major05,.major06,.major07").hide();
		});
		$(".major_con03").click(function () {
		$(".major03").show();
		$(".major01,.major02,.major04,.major05,.major06,.major07").hide();
		});
		$(".major_con04").click(function () {
		$(".major04").show();
		$(".major01,.major03,.major02,.major05,.major06,.major07").hide();
		});
		$(".major_con05").click(function () {
		$(".major05").show();
		$(".major01,.major03,.major04,.major02,.major06,.major07").hide();
		});
		$(".major_con06").click(function () {
		$(".major06").show();
		$(".major01,.major03,.major04,.major05,.major02,.major07").hide();
		});
		$(".major_con07").click(function () {
		$(".major07").show();
		$(".major01,.major03,.major04,.major05,.major06,.major02").hide();
		});
	});