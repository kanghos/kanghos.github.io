

$().ready(function(){
	
		$("#nav li a").mousedown(function(){
		$(this).addClass("active");
	});
	$("#nav li a").mouseup(function(){
		$(this).removeClass("active");
	});
	$("#nav li a").mouseout(function(){
		$(this).removeClass("active");
	}); //edit_v.2
	
	$(".find_pw").click(function(){$("#ly_findpw .in_box").css("top", $(window).scrollTop()+($(window).height()/2));$("#ly_findpw").show(); return false;});
	$(".re_send").click(function(){$("#ly_confirmEmail .in_box").css("top", $(window).scrollTop()+($(window).height()/2));$("#ly_confirmEmail").show(); return false;});
	$("#ly_findpw .bt_cencel").click(function(){$("#ly_findpw").hide(); return false;}); 
	$("#ly_findpw .bt_close").click(function(){$("#ly_findpw").hide(); return false;});
	$("#ly_confirmEmail .bt_cencel").click(function(){$("#ly_confirmEmail").hide(); return false;}); 
	$("#ly_confirmEmail .bt_close").click(function(){$("#ly_confirmEmail").hide(); return false;});
	
	$(".table_gray .bt_purple span").mouseover(function(){$(this).parent("a").addClass("bt_price").removeClass("bt_purple")});
	$(".table_gray .bt_purple span").mouseout(function(){$(this).parent("a").addClass("bt_purple").removeClass("bt_price")});
	
	$(".change_plan li a").click(function(){
		$(".s_li a").attr("href","#");
		$(".s_li").removeClass("s_li");
		$(this).parent("li").addClass("s_li");
		$(this).removeAttr("href");
		$(".choice_plan em span").html($(this).text());
		//2011.09.08 sychoi add start
		if($(this).parent("li").attr("id") == 'PRO'){
	        $("#customDom").removeClass("hidden");
	    }else{
	        $("#customDom").addClass("hidden");
	    }
		//2011.09.08 sychoi add end
		return false;
	});
	$(".ly_bt").click(function(){
		if($(".change_plan ul").hasClass("hidden")){$(".change_plan ul").removeClass("hidden");}
		else{$(".change_plan ul").addClass("hidden");}
		return false;
	});
	
	$(document).bind("mouseup",function(){$(".change_plan ul").addClass("hidden");});
	
	$('.bt_stipulation').click(function(ev){
		window.open('99-03pop_stipulation.html','stipulation','width=880,height=661,scrollbars=1,resizable=yes');
		ev.preventDefault();
		return false;
	}); //edit_OBT
	
	$('.bt_privacy').click(function(ev){
		window.open('99-03pop_privacy.html','privacy','width=880,height=661,scrollbars=1,resizable=yes');
		ev.preventDefault();
		return false;
	}); //edit_OBT

	
});

$(window).bind("resize", function(){
	$(".fuzz").css("height", $(document).height()); 
	$(".fuzz .in_box").css("top", $(window).scrollTop()+($(window).height()/2));
});

window.onload=function(){
	$(".fuzz").css("height", $(document).height());
	$(".fuzz .in_box").css("top", $(window).scrollTop()+($(window).height()/2));
}