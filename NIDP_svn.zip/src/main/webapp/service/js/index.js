var D_SHARE_TWITTER 					= 1
var D_SHARE_FACEBOOK					= 2
var D_SET_POST_RANKING_TWITTER_URL     	= "./ajax/sns/ajaxPostRankingSns.php";
var D_SET_POST_RANKING_FACEBOOK_URL     = "./ajax/sns/ajaxPostRankingSnsByFacebook.php";
var D_AUTH_TWITTER_AUTHENTICATE 		= 1;
var D_AUTH_TWITTER_FORCE_LOGIN        	= 1;
var D_AUTH_FACEBOOK_AUTHENTICATE		= 1;
var D_AUTH_FACEBOOK_API_POST			= "post";
//var SET_OAUTH_FACEBOOK_URL        		= "./ajax/sns/ajaxSetOAuthFacebook.php";
var D_GET_SOCIAL_RANK_URL				= "./ajax/idx/ajaxGetIdxSocialScore.php";
var D_GET_RENDING_MENTION_URL			= "./ajax/idx/ajaxGetReviewMention.php";

var intGSocialScore = 0;
var intGRecognitionScore = 0;
var intGQualityScore = 0;

function getSearchPulseMention(intOffset)
{
	showTotLoading();

    $("#divNoResult").hide();
    $("#divLoading").show();
    $("#divViewMore").hide();
    $("#divToTop").hide();

    if(intOffset == 0){
        $("#ulMention").hide();
    }

	arrGSameKwd = undefined;
    arrGNotKwd = undefined;

	$.ajax({ 
						      url: D_GET_RENDING_MENTION_URL,
						      global: false, 
						      type: "POST", 
							  cache:false,
						      data: ({
										sk  : 1,
										pi  : strGPulseId,
                                        pn  : strGPulseName,
                                        sallw:strGRepKwd,
                                        aanyw:arrGSameKwd,
                                        anotw:arrGNotKwd,
                                        ofs : intOffset,
                                        ps  : D_MENTION_PAGE_SIZE,
                                        o   : intGOrder,
                                        cscn: strGOutCurrentScn,
	
										bc:		strGBCategory,
										ss:		intGSocialScore,
										rs:		intGRecognitionScore,
										qs:		intGQualityScore
							  		}), 
						      dataType: "json", 
						      async:true, 
							  success:function(data){
								$("#review_brand").show();
								printSearchPulseMention(data);
								if(data.ispiestatexist==true){
									printGraph(data.graphtotalcnt, data.graphlist);
								}
								
								hideTotLoading();
								return false;
							  },
							  error: function(){
								hideTotLoading();
								return;
							  }
						   });

}

function printSearchPulseMention(obj)
{
   $("#divLoading").hide();
	
    if(parseInt(obj.error) == 1){
        $("#divViewMore").hide();
        $("#divToTop").hide();

        return false;
    }

    $("#ulMention").show();
    
	strGOutCurrentScn       = obj.outcurrentscn;
    intGOutProcessedOffset  = parseInt(obj.outproccessedofs);

	if(D_MENTION_OFS>0){
		$(".info_stream").append(obj.html);    
	}else{
		$('.info_stream').html(obj.html);
	}
	
	/*
    var strMention          = "";
    if(D_MENTION_OFS>0){
        strMention =  $("#ulMention").html()+obj.html;
    }else{
        strMention = obj.html;
    }
    $("#ulMention").html(strMention);
	*/

	var intTotCnt = parseInt(obj.totalcnt);
	
	if(intTotCnt == 0){
        $("#divViewMore").hide();
        $("#divToTop").hide();
    }else if( D_MENTION_OFS <= 860 && (intTotCnt > (D_MENTION_OFS+D_MENTION_PAGE_SIZE))){
        $("#divViewMore").show();
        $("#divToTop").hide();
    }else{
        $("#divViewMore").hide();
        $("#divToTop").show();
    }

    $("#strongMentionCnt").html(commify(intTotCnt)+"건"); //20120317
}

function printGraph(intTotalCnt, objPieData)
{
	for(var i=0; i<intTotalCnt;i++)
	{
		drawPieChart ("divPieChart"+objPieData[i].media, objPieData[i].senti);
	}
}

function clickPostRankingSns(intType)
{
	$.ajax({ 
						      url: D_GET_SOCIAL_RANK_URL,
						      global: false, 
						      type: "POST", 
							  cache:false,
						      data: ({
							  			ca: document.searchForm.ca.value,
										r:document.searchForm.r.value
							  		}), 
						      dataType: "text", 
						      async:true, 
							  success:function(data){
										var strUrl			= "";
									    var strSnsOAuthUrl 	= "";
										var strParams		= "";
									    var strPostMessage  = data+"";

									    if(intType == D_SHARE_TWITTER){
									        strSnsOAuthUrl  	= D_SET_POST_RANKING_TWITTER_URL;
									        var intAuthenticate = D_AUTH_TWITTER_AUTHENTICATE;
									        var intForce        = D_AUTH_TWITTER_FORCE_LOGIN;
									        var strCallbackUrl  = 'http://www.twitter.com';
											strParams			= "?authenticate="+intAuthenticate+"&force="+intForce+"&msg="+strPostMessage;
										}else if(intType == D_SHARE_FACEBOOK){
									        var strSnsOAuthUrl= D_SET_POST_RANKING_FACEBOOK_URL;
											var intAuthenticate = D_AUTH_FACEBOOK_AUTHENTICATE;
											var strAPI			= D_AUTH_FACEBOOK_API_POST;
											var strCallbackUrl 	= 'http://www.facebook.com';
											//strParams           = "?authenticate="+intAuthenticate+"&api="+strAPI+"&msg=aaa";
											strParams           = "?authenticate="+intAuthenticate+"&api="+strAPI+"&msg="+strPostMessage;
										}else{
									        return;
									    }
									    var strUrl = strSnsOAuthUrl + strParams;
									    window.open(strUrl, "_blank");
							  },
							  error: function(){
								return;
							  }
						   });

}



function callbackPostRankingSns(intError, strErrorMsg)
{
    if(intError==0){
        alert("등록되었습니다.");
    }else if(intError==2){ //post message error
        alert("잠시 후 다시 시도해 주세요.");
    }else{  //error
        alert("잠시 후 다시 시도해 주세요.");
    }
}

function clkTryBasic()
{
	setCookie("pulseK_callback", "dashboard.html?cbu=1" , 365);
	location.href = 'login.html';
}

function clkBuyBasic()
{
	setCookie("pulseK_callback", "account_step1.html?service=BASIC&cbu=1" , 365);
	location.href = 'login.html';

}

function clkTryPro()
{
	setCookie("pulseK_callback", "dashboard.html?cbu=1" , 365);
	location.href = 'login.html';

}

function clkBuyPro()
{
	setCookie("pulseK_callback", "account_step1.html?service=PRO&cbu=1" , 365);
	location.href = 'login.html';

}

function clkTryBasicLogin()
{
	location.href = 'dashboard.html';
}

function clkBuyBasicLogin()
{
	location.href = 'account_step1.html?service=BASIC';

}

function clkTryProLogin()
{
	location.href = 'dashboard.html';

}

function clkBuyProLogin()
{
	location.href = 'account_step1.html?service=PRO';

}
