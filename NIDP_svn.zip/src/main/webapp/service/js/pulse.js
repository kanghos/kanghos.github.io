var D_UPDATE_PULSE_ISFIRST_URL		= "./ajax/pulse/ajaxUpdatePulseIsFirst.php"
var D_UPDATE_PULSE_URL 				= "./ajax/pulse/ajaxUpdatePulse.php";
var D_CHECK_VALID_PULSE_URL			= "./ajax/pulse/ajaxIsValidChkPulse.php";
var D_CREATE_PULSE_NEW_URL			= "./ajax/pulse/ajaxCreatePulseNew.php";
var D_GET_MENTION_URL				= "./ajax/srch/ajaxGetMention.php";
var D_GET_MENTION_ORD_LIKE_URL  	= "./ajax/srch/ajaxGetMentionOrdByLikePulse.php";
var D_GET_EDIT_PULSE_INFO_URL		= "./ajax/pulse/ajaxGetEditPulseInfo.php";

var MAX_SIZE_OF_PULSE_LIST 		= 0; //O: 모두 가져옴, 1 이상 :  가져올 최대 개수 설정 

var D_ORDER_DATE				= 0;
var D_ORDER_LIKE				= 1;

var strGOutCurrentScn       	= "";
var intGOutProcessedOffset	   	= 0;

var strGPulseId					= "";
var strGComPulseId				= "";

var strGPulseName				= "";
var strGRepKwd					= "";
var arrGSameKwd					= null;
var arrGNotKwd					= null;
var strGSameKwd1				= "";
var strGSameKwd2				= "";
var strGSameKwd3				= "";
var strGNotKwd1					= "";
var strGNotKwd2					= "";
var strGNotKwd3					= "";

var strGBCategory				= 0;
var strGSCategory				= 0;

var strGOrgStartDate        	= "";
var strGOrgEndDate      	    = "";
var strGStartDate     	      	= "";
var strGEndDate             	= "";
var intGOrder					= D_ORDER_DATE;

var D_MENTION_OFS				= 0;
var D_MENTION_PAGE_SIZE			= 20;

var intGTotCnt					= 0;

var D_MAX_INPUT_PULSE_LENGTH	= 20;

$().ready(function(){
	var strCurrentPageName = getCurrentPageName();
	if(strCurrentPageName == "pulse_edit.html") {
		editPulseWindow();
	}else if(strCurrentPageName == "pulse_create.html"){
		if(document.frmPulse.inputIssueKwd.value  == ""){
			initNewPulseWindow();
			initCategory();
		}else{
				$('input[id="inputNewPulseName"]').val(document.frmPulse.inputIssueKwd.value);
				$('input[id="inputNewPulseName"]').removeClass("text_el text_df").addClass("text_el");
				$('input[id="inputNewRepKwd"]').val(document.frmPulse.inputIssueKwd.value);
				$('input[id="inputNewRepKwd"]').removeClass("text_el text_df").addClass("text_el");
				editCategory(document.frmPulse.inputIssueBCategory.value, document.frmPulse.inputIssueSCategory.value);
		}

	}
});

function initCategory()
{
	$('.cate_detail .check_ico').remove();
	$('.cate_ctr .selected').removeClass('selected');
	$('.cate_detail.selected').removeClass('selected');

	$("input[name='cate']").each(function(){
		$(this).attr("checked","");
	});
	$("input[name='chk_detail']").each(function(){
		$(this).attr("checked","");
	});

		
	//$("#cate_brand").trigger("click");
	//$('#chk_detail0-0').trigger("click");
}

function editPulseWindow()
{
	var strComPulseId = getParam('cpi');

	$.ajax({ 
						      url		: D_GET_EDIT_PULSE_INFO_URL,
						      global	: false, 
						      type		: "POST", 
							  cache		: false,
						      data		: ({ cpi:strComPulseId }), 
						      dataType	: "json", 
						      async		: false, 
							  success:function(data){
							  		if(data.error == 0){
										printEditPulseWindow(data);
									}else{
										printErrorMsg(1);
									}
							  },
							  error: function(){
							  	printErrorMsg(1);
								return;
							  }
						   });
	
	
}

function printEditPulseWindow(objJson)
{
	if(objJson.srchlist[0].Pulse)
	{
		$('input[id="inputNewPulseName"]').val(objJson.srchlist[0].Pulse);
		$('input[id="inputNewPulseName"]').removeClass("text_el text_df").addClass("text_el");
	}
	if(objJson.srchlist[0].RepKwd)
	{
		$('input[id="inputNewRepKwd"]').val(objJson.srchlist[0].RepKwd);
		$('input[id="inputNewRepKwd"]').removeClass("text_el text_df").addClass("text_el");
	}
	if(objJson.srchlist[0].Anyword1)
	{
		$('input[id="inputNewSameKwd1"]').val(objJson.srchlist[0].Anyword1);
		$('input[id="inputNewSameKwd1"]').removeClass("text_el text_df").addClass("text_el");
	}
	if(objJson.srchlist[0].Anyword2)
	{
		$('input[id="inputNewSameKwd2"]').val(objJson.srchlist[0].Anyword2);
		$('input[id="inputNewSameKwd2"]').removeClass("text_el text_df").addClass("text_el");
	}
	if(objJson.srchlist[0].Anyword3)
	{
		$('input[id="inputNewSameKwd3"]').val(objJson.srchlist[0].Anyword3);
		$('input[id="inputNewSameKwd3"]').removeClass("text_el text_df").addClass("text_el");
	}
	if(objJson.srchlist[0].Notword1)
	{
		$('input[id="inputNewNotKwd1"]').val(objJson.srchlist[0].Notword1);
		$('input[id="inputNewNotKwd1"]').removeClass("text_el text_df").addClass("text_el");
	}
	if(objJson.srchlist[0].Notword2)
	{
		$('input[id="inputNewNotKwd2"]').val(objJson.srchlist[0].Notword2);
		$('input[id="inputNewNotKwd2"]').removeClass("text_el text_df").addClass("text_el");
	}
	if(objJson.srchlist[0].Notword3)
	{
		$('input[id="inputNewNotKwd3"]').val(objJson.srchlist[0].Notword3);
		$('input[id="inputNewNotKwd3"]').removeClass("text_el text_df").addClass("text_el");
	}

	
	strBCategoryCode = objJson.srchlist[0].BCategory ? objJson.srchlist[0].BCategory : 0;
	strSCategoryCode = objJson.srchlist[0].SCategory ? objJson.srchlist[0].SCategory : 0;
	editCategory(strBCategoryCode, strSCategoryCode);
}

function editCategory(strBCategoryCode, strSCategoryCode)
{
	$('input[name="cate"]').each(function(){
		if($(this).val() == strBCategoryCode){
			$(this).trigger("click");
			return false;
		}
	});
	
	$("#chk_detail"+strBCategoryCode+"-"+strSCategoryCode).trigger("click");
}

function checkValidPulse()
{
	$("#divLoading").show();

    strPulseName    = getPulseText("inputNewPulseName");
    strRepKwd       = getPulseText("inputNewRepKwd");
    strSameKwd1     = getPulseText("inputNewSameKwd1");
    strSameKwd2     = getPulseText("inputNewSameKwd2");
    strSameKwd3     = getPulseText("inputNewSameKwd3");
    strNotKwd1      = getPulseText("inputNewNotKwd1");
    strNotKwd2      = getPulseText("inputNewNotKwd2");
    strNotKwd3      = getPulseText("inputNewNotKwd3");
	
	strBigCate		= getBigCateCode();
	strSmallCate	= getSmallCateCode();
/*	
	$('input[name="inputNewPulseName"]').val(getPulseText("inputNewPulseName")? getPulseText("inputNewPulseName") : "");
	$('input[name="inputNewRepKwd"]').val(getPulseText("inputNewRepKwd")? getPulseText("inputNewRepKwd") : "");
	$('input[name="inputNewSameKwd1"]').val(getPulseText("inputNewSameKwd1")? getPulseText("inputNewSameKwd1") : "");
	$('input[name="inputNewSameKwd2"]').val(getPulseText("inputNewSameKwd2")? getPulseText("inputNewSameKwd2") : "");
	$('input[name="inputNewSameKwd3"]').val(getPulseText("inputNewSameKwd3")? getPulseText("inputNewSameKwd3") : "");
	$('input[name="inputNewNotKwd1"]').val(getPulseText("inputNewNotKwd1")? getPulseText("inputNewNotKwd1") : "");
	$('input[name="inputNewNotKwd2"]').val(getPulseText("inputNewNotKwd2")? getPulseText("inputNewNotKwd2") : "");
	$('input[name="inputNewNotKwd3"]').val(getPulseText("inputNewNotKwd3")? getPulseText("inputNewNotKwd3") : "");
	$('input[name="inputBCategory"]').val($('input[name="cate"]:checked').val()? $('input[name="cate"]:checked').val() : "");
	$('input[name="inputSCategory"]').val($('input[name="chk_detail"]:checked').val()? $('input[name="chk_detail"]:checked').val() : "");
*/
	
	$('input[name="inputNewPulseName"]').val(strPulseName ? strPulseName : "");
	$('input[name="inputNewRepKwd"]').val(strRepKwd ? strRepKwd : "");
	$('input[name="inputNewSameKwd1"]').val(strSameKwd1 ? strSameKwd1 : "");
	$('input[name="inputNewSameKwd2"]').val(strSameKwd2 ? strSameKwd2 : "");
	$('input[name="inputNewSameKwd3"]').val(strSameKwd3 ? strSameKwd3 : "");
	$('input[name="inputNewNotKwd1"]').val(strNotKwd1 ? strNotKwd1 : "");
	$('input[name="inputNewNotKwd2"]').val(strNotKwd2 ?strNotKwd2  : "");
	$('input[name="inputNewNotKwd3"]').val(strNotKwd3 ? strNotKwd3 : "");
	$('input[name="inputBCategory"]').val(strBigCate ? strBigCate : "");
	$('input[name="inputSCategory"]').val(strSmallCate ? strSmallCate : "");

	var strCurrentPageName = getCurrentPageName();
	var strComPulseId = getParam('cpi');
	var strPulseId = getParam('id');
	var intEditFlag = 0;

	if(strCurrentPageName == "pulse_edit.html" && strComPulseId != "" && strPulseId != ""){
		intEditFlag = 1;
		$('input[name="inputEditFlag"]').val(intEditFlag);
		$('input[name="inputComPulseId"]').val(strComPulseId);
		$('input[name="inputPulseId"]').val(strPulseId);
	}else{
		intEditFlag = 0;
		strComPulseId = 0;
	}

	if(strPulseName == "" || strRepKwd  == ""){
		alert("펄스명과 공식 키워드를 입력해주세요");
		return false;
	}

	if(strSmallCate == "" || strBigCate == ""){
		alert("카테고리를 선택해주세요.");
		return false;
	}

	showTotLoading();
	$.ajax({ 
						      url		: D_CHECK_VALID_PULSE_URL,
						      global	: false, 
						      type		: "POST", 
							  cache		: false,
						      data		:   ({
							  					pnm: 	strPulseName,
												all:	strRepKwd,
												any1:	strSameKwd1,
												any2:	strSameKwd2,
												any3:	strSameKwd3,
												not1:	strNotKwd1,
												not2:	strNotKwd2,
												not3:	strNotKwd3,
												bc:		strBigCate,
												sc:		strSmallCate,
												edit: 	intEditFlag,
												cid:	strComPulseId
							  				}), 
						      dataType	: "json", 
						      async		: false, 
							  success:function(data){
							  	
								$("#divLoading").hide();
								if(data.error == 5){ //20120507 start
									hideTotLoading();
                                    alert("분석에 적합하지 않은 일음절 키워드는 펄스 공식 키워드, 동의어, 제외어에 입력할 수 없습니다.");
									return;
								}else if(data.error == 4){ //20120507 end
									hideTotLoading();
									if(data.ischarge == 0)
									{
										if(confirm("이용할 수 있는 펄스 수를 추가하였습니다.\n\r펄스 추가는 유료서비스 상품(베이직, 프로) 구매시에만 가능합니다.\n\r지금 유료서비스 상품을 구매하시겠습니까?")){
											location.href = "account_step1.html?service=PRO";
										}										
										else
											return;
									}
									else
									{
										if(confirm("생성 가능한 펄스 갯수를 초과하였습니다. 추가 결제 후 사용해 주시기 바랍니다.")){
										//location.href = "upgrade.html";		
											location.href= "account_step1.html";
										}
									}
								}else if(data.error == 3){
									hideTotLoading();
									alert("특수기호는 등록이 불가능합니다.");
									return;
								}else if(data.error == 2){
									hideTotLoading();
									alert("같은 펄스명이 이미 존재합니다.");
									return;
								}else if(data.error == 0){
									$("#frmPulse").submit();
								}else{
									hideTotLoading();
									printErrorMsg(1);
								}
							  },
							  error: function(){
								hideTotLoading();
							  	printErrorMsg(1);
								return;
							  }
						   });
}

function createPulseNew(	strPulseName, 
							strRepKwd, 
							strSameKwd1, 
							strSameKwd2, 
							strSameKwd3, 
							strNotKwd1, 
							strNotKwd2, 
							strNotKwd3, 
							strBigCate,
							strSmallCate)
{
	$("#divLoading").show();
	

	strPulseName = strPulseName ? strPulseName : undefined;
	strRepKwd = strRepKwd ? strRepKwd : undefined;
	strSameKwd1 = strSameKwd1 ? strSameKwd1 : undefined;
	strSameKwd2 = strSameKwd2 ? strSameKwd2 : undefined;
	strSameKwd3 = strSameKwd3 ? strSameKwd3 : undefined;
	strNotKwd1 = strNotKwd1 ? strNotKwd1 : undefined;
	strNotKwd2 = strNotKwd2 ? strNotKwd2 : undefined;
	strNotKwd3 = strNotKwd3 ? strNotKwd3 : undefined;
	strBigCate = strBigCate ? strBigCate : undefined;
	strSmallCate = strSmallCate ? strSmallCate : undefined;

	$.ajax({ 
						      url		: D_CREATE_PULSE_NEW_URL,
						      global	: false, 
						      type		: "POST", 
							  cache		: false,
						      data		:   ({
							  					pnm: 	strPulseName,
												all:	strRepKwd,
												any1:	strSameKwd1,
												any2:	strSameKwd2,
												any3:	strSameKwd3,
												not1:	strNotKwd1,
												not2:	strNotKwd2,
												not3:	strNotKwd3,
												bc:		strBigCate,
												sc:		strSmallCate
							  				}), 
						      dataType	: "json", 
						      async		: false, 
							  success:function(data){

								$("#divLoading").hide();
								if(data.error == 5){ //20120507 start
                                    hideTotLoading();
                                    alert("분석에 적합하지 않은 일음절 키워드는 펄스 공식 키워드, 동의어, 제외어에 입력할 수 없습니다.");
                                    return;
                                }else if(data.error == 4){ //20120507 end
									if(data.ischarge == 0)
									{
										if(confirm("이용할 수 있는 펄스 수를 추가하였습니다.<br>펄스 추가는 유료서비스 상품(베이직, 프로) 구매시에만 가능합니다.<br>지금 유료서비스 상품을 구매하시겠습니까?")){
											location.href = "account_step1.html?service=PRO";
										}										
										else
											return;
									}
									else
									{
										if(confirm("생성 가능한 펄스 갯수를 초과하였습니다. 추가 결제 후 사용해 주시기 바랍니다.")){
										//location.href = "upgrade.html";		
											location.href= "account_step1.html";
										}
									}
									
									/*alert("생성할 수 있는 펄스 개수를 초과하였습니다.");
									location.href = "upgrade.html";*/
								}else if(data.error == 3){
									alert("특수기호는 등록이 불가능합니다.");
									return;
								}else if(data.error == 2){
									alert("같은 펄스명이 이미 존재합니다.");
									return;
								}else if(data.error == 0){
									alert("새로운 펄스로 등록되었습니다.");
									//clickSetScrollPulse(data.id);
									if(data.stat == 0){
										clickPulse(data.pulseid, data.id, data.pulse)
									}else if(data.first == 1){
										location.href = "pulse_complete.html?pi="+data.pulseid+"&cpi="+data.id;;
									}else{
										location.href = "pulse_analing.html?pi="+data.pulseid+"&cpi="+data.id;
									}
								}else{
									printErrorMsg(1);
								}
							  },
							  error: function(){
								printErrorMsg(1);
								return;
							  }
						   });
}

function getMentionByName(intOffset)
{
    $("#divNoResult").hide();
    $("#divLoading").show();
    $("#divViewMore").hide();
    $("#divToTop").hide();

    if(intOffset == 0){
        $("#ulMention").hide();
    }

	var strUrl = D_GET_MENTION_URL;
    if(intGOrder == D_ORDER_LIKE){
		strUrl = D_GET_MENTION_ORD_LIKE_URL;
    }
	
	$.ajax({ 
				//url		: D_GET_MENTION_URL,
				url		: strUrl,
				global	: false, 
				type	: "POST", 
				cache	: false,
				data	: ({sk	: 1,
							pn	: strGPulseName,
							aallw:strGRepKwd,
							aanyw:arrGSameKwd,
							anotw:arrGNotKwd,
							ofs : intOffset,
                            ps  : D_MENTION_PAGE_SIZE,
							o	: intGOrder,
							cscn: strGOutCurrentScn
							/*,
							cscn: strGOutCurrentScn,
							sd	: strGStartDate, */
							}),
				dataType: "json", 
				async	: true, 
				success	:function(data){
					if(data.error == 0){
						printMentionByName(data);
                    }else{
                    	printErrorMsg(1);
                    }
                },
				error: function(){
					printErrorMsg(1);
					return;
				}
		});
}



function printMentionByName(obj)
{

	$("#divLoading").hide();

    if(parseInt(obj.error) == 1){
        $("#divViewMore").hide();
        $("#divToTop").hide();

        return false;
    }

    $("#ulMention").show();
/*
	if(D_MENTION_OFS == 0){
		var intTotCnt = parseInt(obj.totalcnt);
		intGTotCnt = intTotCnt;
	}else{
		var intTotCnt = intGTotCnt; 
	}
*/	
	strGOutCurrentScn 		= obj.outcurrentscn;
	intGOutProcessedOffset 	= parseInt(obj.outproccessedofs);

	var strMention 			= "";
	if(D_MENTION_OFS>0){
		strMention =  $("#ulMention").html()+obj.html;
	}else{
		strMention = obj.html;
	}
	$("#ulMention").html(strMention);

	var intTotCnt = parseInt(obj.totalcnt);

	if(intTotCnt == 0){
		$("#divViewMore").hide();
		$("#divToTop").hide();
	}else if( D_MENTION_OFS <= 860 && (intTotCnt > (D_MENTION_OFS+D_MENTION_PAGE_SIZE))){
		$("#divViewMore").show();
		$("#divToTop").hide();
	}else{
		$("#divViewMore").hide();
		$("#divToTop").show();
	}

	$("#strongMentionCnt").html(commify(intTotCnt)+"건"); //20120317
}

function clickOrder(intOrder){
    intGOrder = intOrder;

    switch(intOrder)
    {
        case D_ORDER_LIKE:
            $("#aOrdLike").addClass("selected");
            $("#aOrdDate").removeClass("selected");
            break;
        case D_ORDER_DATE:
            $("#aOrdLike").removeClass("selected");
            $("#aOrdDate").addClass("selected");
            break;
    }

    initVal();
    getMentionByName(0);
}


function clkViewMore()
{
	var intSrchOffset = 0;
    if(intGOutProcessedOffset > 0){
    	intSrchOffset = intGOutProcessedOffset;
    }else{
       	intSrchOffset = D_MENTION_OFS + D_MENTION_PAGE_SIZE;
    }
	D_MENTION_OFS = intSrchOffset;
	getMentionByName(intSrchOffset);
}

function initVal()
{
    strGOutCurrentScn        = "";
    intGOutProcessedOffset   = 0;
    D_MENTION_OFS            = 0;
}

function updatePulseNew(	strComPulseId,
							strPulseName, 
							strRepKwd, 
							strSameKwd1, 
							strSameKwd2, 
							strSameKwd3, 
							strNotKwd1, 
							strNotKwd2, 
							strNotKwd3, 
							strBigCate,
							strSmallCate)
{
	$("#divLoading").show();

	strPulseName = strPulseName ? strPulseName : undefined;
	strRepKwd = strRepKwd ? strRepKwd : undefined;
	strSameKwd1 = strSameKwd1 ? strSameKwd1 : undefined;
	strSameKwd2 = strSameKwd2 ? strSameKwd2 : undefined;
	strSameKwd3 = strSameKwd3 ? strSameKwd3 : undefined;
	strNotKwd1 = strNotKwd1 ? strNotKwd1 : undefined;
	strNotKwd2 = strNotKwd2 ? strNotKwd2 : undefined;
	strNotKwd3 = strNotKwd3 ? strNotKwd3 : undefined;
	strBigCate = strBigCate ? strBigCate : undefined;
	strSmallCate = strSmallCate ? strSmallCate : undefined;

	
	$.ajax({ 
						      url		: D_UPDATE_PULSE_URL,
						      global	: false, 
						      type		: "POST", 
							  cache		: false,
						      data		:   ({
												cid:	strComPulseId,
							  					pnm: 	strPulseName,
												all:	strRepKwd,
												any1:	strSameKwd1,
												any2:	strSameKwd2,
												any3:	strSameKwd3,
												not1:	strNotKwd1,
												not2:	strNotKwd2,
												not3:	strNotKwd3,
												bc:		strBigCate,
												sc:		strSmallCate
							  				}), 
						      dataType	: "json", 
						      async		: false, 
							  success:function(data){
								
								if(data.error == 3){
                                    alert("특수기호는 등록이 불가능합니다.");
                                    return;
                                }else if(data.error == 2){
                                    alert("같은 펄스명이 이미 존재합니다.");
                                    return;
                                }else if(data.error == 0){
                                    alert("펄스가 수정되었습니다.");
                                    if(data.stat == 0){
										//clickSetScrollPulse(data.id);
										if(data.first == 1){
	                                        clickPulse(data.pulseid, data.id, data.pulse);
										}else{
											location.href = "pulse_complete.html?id="+data.pulseid+"&cpi="+data.id;
										}
                                    }else if(data.first == 1){
                                        location.href = "pulse_complete.html?id="+data.pulseid+"&cpi="+data.id;
                                    }else{
                                        location.href = "pulse_analing.html?pi="+data.pulseid+"&cpi="+data.id;
                                    }
								}else{
									printErrorMsg(1);
								}
							  },
							  error: function(){
							  	alert("처리되지 않았습니다. 재시도해주세요");
								return false;
							  }
						   });
}

function updatePulseIsFirst(strPulseId, strComPulseId)
{

	$.ajax({ 
						      url		: D_UPDATE_PULSE_ISFIRST_URL,
						      global	: false, 
						      type		: "POST", 
							  cache		: false,
						      data		: ({cid:strComPulseId}), 
						      dataType	: "json", 
						      async		: true, 
							  success:function(data){
								if(data.error == 0){
									//clickSetScrollPulse(data.id);
                                	clickPulse(strPulseId, strComPulseId)
								}else{
									printErrorMsg(1);
								}
							  },
							  error: function(){
							  	alert("처리되지 않았습니다. 재시도해주세요");
								return false;
							  }
						   });
	
}
