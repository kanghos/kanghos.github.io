D_CREATE_PULSE_URL		= "./ajax/pulse/ajaxCreatePulse.php";
D_DELETE_PULSE_URL      = "./ajax/pulse/ajaxDeletePulse.php";
D_GET_PULSE_URL         = "./ajax/pulse/ajaxGetPulse.php"
D_LOGOUT_URL            = "./ajax/login/logout.php";
D_CHECK_VALID_PULSE_URL = "./ajax/pulse/ajaxIsValidChkPulse.php";
D_SET_SCROLL_PULSE_URL	= "./ajax/user/ajaxSetScrollPulse.php";
D_GET_SCROLL_PULSE_URL	= "./ajax/user/ajaxGetScrollPulseList.php";
D_DELETE_OVER_PULSE_URL = "./ajax/pulse/ajaxDeleteOverPulse.php";

D_GET_MENTION_SENTIMENT_POSITIVE	= 5;
D_GET_MENTION_SENTIMENT_NEUTRAL		= 3;
D_GET_MENTION_SENTIMENT_NEGATIVE	= 1;

D_SHARE_TWITTER = 1
D_SHARE_FACEBOOK= 2
D_SHARE_ME2DAY	= 3
D_SHARE_BLOG	= 11

D_APP_URL					= "http://www.pulsek.com/pulsek";
D_NO_USER_IMG				= "/html/images/sum_noimg.gif";

D_PULSE_K_IS_LOGIN			= 'pulseK_is_login';
D_PULSE_K_ID				= "pulseK_id";
D_PULSE_K_COMPANY_ID		= "pulseK_companyId";
D_PULSE_K_ACCOUNT_KEY		= "pulseK_accountKey";
D_PULSE_K_IS_2_WEEK			= "pulseK_is_2_week";
D_PULSE_K_EXPIRE_TIME		= "pulseK_expireTime";
D_PULSE_K_IS_CONFIRMED		= "pulsek_is_confirmed";
D_PULSE_K_ORDER_ID			= "pulseK_order_id";
D_PULSE_K_PLAN				= "pulseK_plan";
D_PULSE_K_ALARM_CALLBACK	= "pulseK_alarm_callback";

D_AUTH_TWITTER_AUTHENTICATE = 1;
D_AUTH_TWITTER_AUTHORIZE 	= 0;
D_AUTH_TWITTER_FORCE_LOGIN	= 1;

D_BASIC_ALLOW_PULSE_COUNT	= 5
D_PRO_ALLOW_PULSE_COUNT		= 10
D_TOTAL_ALLOW_USER_COUNT	= 5

D_TRIAL_DAYS				= 3;

D_SET_PULSE_DASH_ON_URL		= "./ajax/pulse/ajaxUpdatePulseDashOn.php";

var strGPopMentionId	= "";
var strGPopMention		= "";
var intGPopSource		= 0;
var strGPopUserId		= "";
var strGPopUserName		= "";
var strGPopRegisterDate	= "";
var strGPopPostUrl		= "";
var strGPopPostSubId	= "";
var intGPopLikeCnt	    = 0;
var intGReportAddType	= 0;
var strGReplyId			= "";


function clkOpenComDelLayer()
{
	setCookie("pulseK_comm_del","0");
	$("#ly_comm_del").show();
}

function clkCloseComDelLayer()
{
	setCookie("pulseK_comm_del","1");
}

//펄스에 dash on 설정
function setPulseDashOn(intComPulseId)
{
	var isOK = false;
	$.ajax({ 
						      url		: D_SET_PULSE_DASH_ON_URL,
						      global	: false, 
						      type		: "POST", 
							  cache		: false,
						      data		:   ({
							  					pk  : 	intComPulseId
							  				}), 
						      dataType	: "json", 
						      async		: false, 
							  success:function(data){
							  	if(data.error == 1){
									isOK = false;
								}else if(data.error == 2){
									alert("관심펄스는 8개까지만 설정 가능합니다.");
									isOK = false;
								}else if(data.error == 0){
									isOK = true;
								}else{
									isOK = false;
								}
							  },
							  error: function(){
							  		isOK = false;
							  }
						   });
	return isOK;
}













//멘션클릭시 팝업창에 전달하는 변수 설정 
function setPopVal(	
					strReplyId,
					strMentionId, 
					strMention,
					intSource,
					strUserId,
					strUserName,
					strRegisterDate,
					strPostUrl,
					strPostSubId,
					intLikeCnt
					)
{

	//alert(strReplyId);
	strGReplyId			= strReplyId;
	strGPopMentionId	= strMentionId;
	strGPopMention		= strMention;
	intGPopSource		= intSource;
	strGPopUserId		= strUserId;
	strGPopUserName		= strUserName;
	strGPopRegisterDate	= strRegisterDate;
	strGPopPostUrl		= strPostUrl;
	strGPopPostSubId    = strPostSubId;
	intGPopLikeCnt		= intLikeCnt;
	intGReportAddType 	= D_RPT_MENTION;
/*
	alert(	
			strGPopMentionId+"\n"+
			strGPopMention+"\n"+
			intGPopSource+"\n"+
			strGPopUserId+"\n"+
			strGPopUserName+"\n"+
			strGPopRegisterDate+"\n"+
			strGPopPostUrl);
*/

}

//캘린더에 있는 날짜 (yyyy.m.dd -> yyyymmdd형식으로 변환)
function getRefinedDate(strInDate)
{
		
	var strDate = "";
	arrDate = strInDate.split(".");
	if(parseInt(arrDate[1]) < 10){
		arrDate[1] = "0" + arrDate[1];
	}

	return arrDate.join("");
			
}

//쿠키 설정 
function setCookie(name,value,expiredays) { 
	var todayDate = new Date(); 
	todayDate.setDate(todayDate.getDate() + expiredays); 
	document.cookie = name + "=" + escape( value ) + "; path=/; expires=" + todayDate.toGMTString () + ";" ;
} 

//쿠키 가져오기
function getCookie( check_name ) {
    var a_all_cookies = document.cookie.split( ';' );
    var a_temp_cookie = '';
    var cookie_name = '';
    var cookie_value = '';
    var b_cookie_found = false; // set boolean t/f default f
    for ( i = 0; i < a_all_cookies.length; i++ )
    {
        a_temp_cookie = a_all_cookies[i].split( '=' );
        cookie_name = a_temp_cookie[0].replace(/^\s+|\s+$/g, '');
        if ( cookie_name == check_name )
        {
            b_cookie_found = true;
            if ( a_temp_cookie.length > 1 )
            {
                cookie_value = unescape( a_temp_cookie[1].replace(/^\s+|\s+$/g, '') );
            }
            return cookie_value;
            break;
        }
        a_temp_cookie = null;
        cookie_name = '';
    }
    if ( !b_cookie_found )
    {
        return null;
    }
}

//고급분석 알림창 안띄우기
function closeLyMsgAna(){
	var isChecked = $('#bt_cookie').is(':checked');
	if(isChecked == true){
		setCookie("anal_info_cook", "done" , 365); 
	}
}

function trim(str) {
    return str.replace(/^\s|\s*/, '').replace(/\s\s*$/, '');
}

function getPulseText(strId){
	var strText = "";

	if(!($("#"+strId).hasClass("text_el") && $("#"+strId).hasClass("text_df"))) { 
		strText = $("#"+strId).val();
	}
	return trim(strText);
}

function initPulseTextClass(strId){
	$("#"+strId).removeClass("text_el").addClass("text_el text_df");
}

function initNewPulseWindow()
{
	initPulseTextClass("inputNewPulseName");	
	initPulseTextClass("inputNewRepKwd");	
	initPulseTextClass("inputNewSameKwd1");	
	initPulseTextClass("inputNewSameKwd2");	
	initPulseTextClass("inputNewSameKwd3");	
	initPulseTextClass("inputNewNotKwd1");	
	initPulseTextClass("inputNewNotKwd2");	
	initPulseTextClass("inputNewNotKwd3");	
	
	/*
	//PSKDV-983
	$("#inputNewPulseName").val("휘트니 휴스턴");
	$("#inputNewRepKwd").val("휘트니 휴스턴");
	*/

	$("#inputNewPulseName").val("Super Star K3");	//PSKDV-983
	$("#inputNewRepKwd").val("Super Star K3");		//PSKDV-983
	$("#inputNewSameKwd1").val("예) 슈퍼스타 K3");
	$("#inputNewSameKwd2").val("예) 슈스케3");
	$("#inputNewSameKwd3").val("예) 슈스케 시즌3");
	$("#inputNewNotKwd1").val("예) 슈퍼스타 K3");
	$("#inputNewNotKwd2").val("예) 슈스케3");
	$("#inputNewNotKwd3").val("예) 슈스케 시즌3");
}

function getBigCateCode()
{
	return $('input[name="cate"]:checked').val()? $('input[name="cate"]:checked').val() : 0;
//	return $("#divCateCtr label.selected input").val();
}

function getSmallCateCode()
{
	return $('input[name="chk_detail"]:checked').val()? $('input[name="chk_detail"]:checked').val() : 0;
//	return $('.cate_detail .check_ico').siblings('input').val();
}

//새로운 펄스 생성 유효성 체크 
function isValidCrNewPulse(){
	var strPulseName 	= getPulseText("inputNewPulseName");
	var strRepKwd		= getPulseText("inputNewRepKwd");
	var strSameKwd1		= getPulseText("inputNewSameKwd1");
	var strSameKwd2		= getPulseText("inputNewSameKwd2");
	var strSameKwd3		= getPulseText("inputNewSameKwd3");
	var strNotKwd1		= getPulseText("inputNewNotKwd1");
	var strNotKwd2		= getPulseText("inputNewNotKwd2");
	var strNotKwd3		= getPulseText("inputNewNotKwd3");

	var strBigCate		= getBigCateCode();
	var strSmallCate	= getSmallCateCode();
	
	if(strPulseName == "" || strRepKwd  == ""){
		alert("펄스명과 공식 키워드를 입력해주세요");
		return false;
	}
	
	var isConfirm 		= false;
	$.ajax({ 
						      url		: D_CHECK_VALID_PULSE_URL,
						      global	: false, 
						      type		: "POST", 
							  cache		: false,
						      data		:   ({
							  					pnm: 	strPulseName,
												all:	strRepKwd,
												any1:	strSameKwd1,
												any2:	strSameKwd2,
												any3:	strSameKwd3,
												not1:	strNotKwd1,
												not2:	strNotKwd2,
												not3:	strNotKwd3,
												bc:		strBigCate,
												sc:		strSmallCate
							  				}), 
						      dataType	: "json", 
						      async		: false, 
							  success:function(data){
							  	if(data.error == 1){
									alert("처리되지 않았습니다. 재시도해주세요");
									isConfirm = false;
								}else if(data.error == 3){
									alert("특수기호는 등록이 불가능합니다.");
									isConfirm = false;
								}else if(data.error == 2){
									alert("같은 펄스명이 이미 존재합니다.");
									isConfirm = false;
								}else if(data.error == 4){
									if(confirm("생성 가능한 펄스 갯수를 초과하였습니다. 추가 결제 후 사용해 주시기 바랍니다.")){
										location.href = "upgrade.html";		
									}
									isConfirm = false;
								}else if(data.error == 5){ //20120507 start
									alert("분석에 적합하지 않은 일음절 키워드는 펄스 공식 키워드, 동의어, 제외어에 입력할 수 없습니다.");
									isConfirm = false;
								}else if(data.error == 0){ //20120507 end 
									isConfirm = true;
								}
							  },
							  error: function(){
							  	alert("처리되지 않았습니다. 재시도해주세요");
								isConfirm = false;
							  }
						   });
	return isConfirm;	



}


//새로운 펄스 생성
function createNewPulse(){
	var strPulseName 	= getPulseText("inputNewPulseName");
	var strRepKwd		= getPulseText("inputNewRepKwd");
	var strSameKwd1		= getPulseText("inputNewSameKwd1");
	var strSameKwd2		= getPulseText("inputNewSameKwd2");
	var strSameKwd3		= getPulseText("inputNewSameKwd3");
	var strNotKwd1		= getPulseText("inputNewNotKwd1");
	var strNotKwd2		= getPulseText("inputNewNotKwd2");
	var strNotKwd3		= getPulseText("inputNewNotKwd3");

	var strBigCate		= getBigCateCode();
	var strSmallCate	= getSmallCateCode();
	
	if(strPulseName == "" || strRepKwd  == ""){
		alert("펄스명과 공식 키워드를 입력해주세요");
		return false;
	}
	
	var isConfirm 		= false;
	$.ajax({ 
						      url		: D_CREATE_PULSE_URL,
						      global	: false, 
						      type		: "POST", 
							  cache		: false,
						      data		:   ({
							  					pnm: 	strPulseName,
												all:	strRepKwd,
												any1:	strSameKwd1,
												any2:	strSameKwd2,
												any3:	strSameKwd3,
												not1:	strNotKwd1,
												not2:	strNotKwd2,
												not3:	strNotKwd3,
												bc:		strBigCate,
												sc:		strSmallCate
							  				}), 
						      dataType	: "json", 
						      async		: false, 
							  success:function(data){
							  	if(data.error == 1){
									alert("처리되지 않았습니다. 재시도해주세요");
									isConfirm = false;
								}else if(data.error == 3){
									alert("특수기호는 등록이 불가능합니다.");
									isConfirm = false;
								}else if(data.error == 2){
									alert("같은 펄스명이 이미 존재합니다.");
									isConfirm = false;
								}else if(data.error == 5){ //20120507 start
									alert("분석에 적합하지 않은 일음절 키워드는 펄스 공식 키워드, 동의어, 제외어에 입력할 수 없습니다.");
									isConfirm = false;
								}else if(data.error == 0){ //20120507 end 
									alert("새로운 펄스로 등록되었습니다.");
									isConfirm = true;
								}
							  },
							  error: function(){
							  	alert("처리되지 않았습니다. 재시도해주세요");
								isConfirm = false;
							  }
						   });
	return isConfirm;	
}


function deleteOverPulse(strPulseId)
{
    $.ajax({
                              url: D_DELETE_OVER_PULSE_URL,
                              global: false,
                              type: "POST",
                              cache:false,
                              data: ({pk: strPulseId}),
                              dataType: "json",
                              async:true,
                              success: function(data){
                                postDeletePulse(data);
                              },
                              error: function(){
                                return;
                              }
           });
}

function deletePulse(strPulseId)
{
    $.ajax({
                              url: D_DELETE_PULSE_URL,
                              global: false,
                              type: "POST",
                              cache:false,
                              data: ({pk: strPulseId}),
                              dataType: "json",
                              async:true,
                              success: function(data){
                                postDeletePulse(data);
                              },
                              error: function(){
                                return;
                              }
           });
}

function postDeletePulse(objJson){
    
	if(parseInt(objJson.error) == 0)
    {
		
		location.href = "dashboard.html";
		/*
        var strCurrentPageName = getCurrentPageName();
        
		
		if(strCurrentPageName == "pulse_edit.html" || strCurrentPageName == "pulse_analing.html"){
            location.href = "dashboard.html";
        }else{
			
			location.reload();
            //getPulseList();
            //getOnloadEvent();
        }*/
    }else{
       // alert(objJson.errormsg);
    }

    $("#ly_delPulse").hide();

}

function getPulseList()
{

    $.ajax({
                              url: D_GET_PULSE_URL,
                              global: false,
                              type: "POST",
                              cache:false,
                              data: ({ps:0, ids:0, isc:0}),
                              dataType: "json",
                              async:true,
                              success: function(data){
							  	$("#ulPulseList").html(data.html);
                                //postDeletePulse(data);
                              },
                              error: function(){
                                return;
                              }
           });
}

//이메일 형식 유효 여부 체크
function isValidEmailCheck(str) {

    var testresults=false;
    var filter=/^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
    if (filter.test(str))
        testresults=true;
    else{
        testresults=false;
    }
    return testresults;
}

//숫자인지 체크
function isNumber(s)
{
    s += ''; // 문자열로 변환
    s = s.replace(/^\s*|\s*$/g, ''); // 좌우 공백 제거
    if (s == '' || isNaN(s)) return false;
    return true;

}

//비밀번호길이체크
function isValidPassword(s)
{
    var intLength = s.length;

    if(intLength < 5){
        return false;
    }else if(intLength < 11){
        return true;
    }else{
        return false;
    }

    return false;
}

//펄스 클릭시 이동 
function clickPulse(strStatPulseId, strComPulseId){
	location.href = "socialscore.html?pi="+strStatPulseId+"&cpi="+ strComPulseId;
}

//현재 페이지 명 반환
function getCurrentPageName(){
    var fullUrl = location.href;
    var u = "";
    var lastChar = "";
	var strHtml  = "";
	if(fullUrl.indexOf("?") != -1){
        u =fullUrl.slice(fullUrl.lastIndexOf ("/")+1,fullUrl.indexOf("?"));
    }else{
        u=fullUrl.slice(fullUrl.lastIndexOf ("/")+1,fullUrl.length);
    }
	
	if(u.length > 3){
		strHtml = u;
		lastChar = strHtml.substr(strHtml.length-1, 1);
		if(lastChar == "#"){
			u = u.substring(0, u.length-1);
		}
	}
    return u;
}

//파라미터 array 반환 
function getParam(name) {
    var regexS = "[\\?&]" + name + "=([^&#]*)";
    var regex = new RegExp(regexS);
    var results = regex.exec(window.location.href);
    if (results == null) {
        return "";
    } else {
        return results[1];
    }
}


//천단위 마다 콤마 붙이기 
function commify(n) {
    var reg = /(^[+-]?\d+)(\d{3})/;   // 정규식
    n += '';                          // 숫자를 문자열로 변환

    while (reg.test(n))
          n = n.replace(reg, '$1' + ',' + '$2');

    return n;
}

//캘린더 날짜 설정 
//function setSpanStatDate(strInPreStartDate, strInPreEndDate) //PSKDV-696 20120514
function setSpanStatDate(strInPreStartDate, strInPreEndDate, isShiftTo) //PSKDV-696 20120514
{
	 var arrStartDate = null;
	 var arrEndDate = null;

	 arrStartDate = strInPreStartDate.split(".");
	 arrEndDate   = strInPreEndDate.split(".");
	
	if(arrStartDate[0].substr(0,1) == "0"){
		arrStartDate[0]= arrStartDate[0].replace("0", "");
	}
	if(arrStartDate[1].substr(0,1) == "0"){
		 arrStartDate[1] = arrStartDate[1].replace("0", "");
	}
	if(arrStartDate[2].substr(0,1) == "0"){
		arrStartDate[2]=arrStartDate[2].replace("0", "");
	}
	
	if(arrEndDate[0].substr(0,1) == "0"){
		arrEndDate[0]= arrEndDate[0].replace("0", "");
	}
	if(arrEndDate[1].substr(0,1) == "0"){
		arrEndDate[1]= arrEndDate[1].replace("0", "");
	}
	if(arrEndDate[2].substr(0,1) == "0"){
		arrEndDate[2]= arrEndDate[2].replace("0", "");
	}

	 var now3 = new Date(parseInt(arrStartDate[0]),parseInt(arrStartDate[1])-1, parseInt(arrStartDate[2]));
	 var now4 = new Date(parseInt(arrEndDate[0]), parseInt(arrEndDate[1])-1, parseInt(arrEndDate[2]));

	 //$('#widgetCalendar').DatePickerSetDate([new Date(now3), new Date(now4)], false);  //PSKDV-696 20120514
	 $('#widgetCalendar').DatePickerSetDate([new Date(now3), new Date(now4)], isShiftTo); //PSKDV-696 20120514 
	 var getdate = $('#widgetCalendar').DatePickerGetDate("Y B d");
	 $('#widgetField span').html(getdate.join(" ~ "));
}

function setSpanStatDate2(strInPreStartDate, strInPreEndDate)
{
	 var arrStartDate = null;
	 var arrEndDate = null;

	 arrStartDate = strInPreStartDate.split(".");
	 arrEndDate   = strInPreEndDate.split(".");
	
	if(arrStartDate[0].substr(0,1) == "0"){
		arrStartDate[0]= arrStartDate[0].replace("0", "");
	}
	if(arrStartDate[1].substr(0,1) == "0"){
		 arrStartDate[1] = arrStartDate[1].replace("0", "");
	}
	if(arrStartDate[2].substr(0,1) == "0"){
		arrStartDate[2]=arrStartDate[2].replace("0", "");
	}
	
	if(arrEndDate[0].substr(0,1) == "0"){
		arrEndDate[0]= arrEndDate[0].replace("0", "");
	}
	if(arrEndDate[1].substr(0,1) == "0"){
		arrEndDate[1]= arrEndDate[1].replace("0", "");
	}
	if(arrEndDate[2].substr(0,1) == "0"){
		arrEndDate[2]= arrEndDate[2].replace("0", "");
	}

	 var now3 = new Date(parseInt(arrStartDate[0]),parseInt(arrStartDate[1])-1, parseInt(arrStartDate[2]));
	 var now4 = new Date(parseInt(arrEndDate[0]), parseInt(arrEndDate[1])-1, parseInt(arrEndDate[2]));

	 $('#widgetCalendar2').DatePickerSetDate([new Date(now3), new Date(now4)], false);
	 var getdate = $('#widgetCalendar2').DatePickerGetDate("Y B d");
	 $('#widgetField2 span').html(getdate.join(" ~ "));
}
//PSKDV-696 20120514 start
function calDateRangeDiff(val1, val2)
{
        var FORMAT = ".";

        /*
        if (val1.length != 10 || val2.length != 10)
                             return null;

       
        if (val1.indexOf(FORMAT) < 0 || val2.indexOf(FORMAT) < 0)
                             return null;
*/
         
        var start_dt = val1.split(FORMAT);
        var end_dt = val2.split(FORMAT);



        
        start_dt[1] = (Number(start_dt[1]) - 1) + "";
        end_dt[1] = (Number(end_dt[1]) - 1) + "";

        var from_dt = new Date(start_dt[0], start_dt[1], Number(start_dt[2]));
        var to_dt = new Date(end_dt[0], end_dt[1], Number(end_dt[2]));

        return (to_dt.getTime() - from_dt.getTime()) / 1000 / 60 / 60 / 24;
}

//PSKDV-696 20120514 end
/*
//PSKDV-696 20120514 start
function addzero(n) {
 return n < 10 ? "0" + n : n;
}
//PSKDV-696 20120514 end
*/
//캘린더 켜기 끄기 클릭시 호출됨- 켜기시 끝날짜를 현재날짜로 설정 
function radioDateClicks()
{
	   
	   	intGSetCurDateChk = parseInt($(this).val());

	   	var d = new Date();
	   	var strStartDate     = "";
	   	var strDate = $('#spanSelectedDate').html();
	 	strDate = strDate.replace(/ /g, '');
		arrDate = strDate.split("~");
		strStartDate     =  arrDate[0];

		/*//PSKDV-696 20120514 start - 90일 이상 선택시 문제 해결 
		if(intGSetCurDateChk == 1){
			var d90DaysAgo 		= new Date(Date.parse(d) - 89 * 1000 * 60 * 60 * 24); //90일전
			var int90DaysAgo 	= parseInt(d90DaysAgo.getFullYear() + addzero(d90DaysAgo.getMonth() + 1) + addzero(d90DaysAgo.getDate())); 
			var arrStartDate	= strStartDate.split(".");
			var intStartDate	= parseInt(arrStartDate[0]+""+ addzero(arrStartDate[1])+""+arrStartDate[2]);
	
			if(intStartDate < int90DaysAgo){
				strStartDate     = d90DaysAgo.getFullYear() +"."+(d90DaysAgo.getMonth() + 1) +"."+d90DaysAgo.getDate();
			}
		}
		//PSKDV-696 20120514 end
		*/	
	

	   	var strEndDate 	= d.getFullYear()+"."+ (d.getMonth() + 1)+"."+d.getDate();
	
	    //setSpanStatDate(strStartDate ,strEndDate); //PSKDV-696 20120514
		//PSKDV-696 20120514 start
		if(intGSetCurDateChk == 1){
			setSpanStatDate(strStartDate ,strEndDate, true);
		}/*else{
			setSpanStatDate(strStartDate ,strEndDate, false);
		}*/
		//PSKDV-696 20120514 end
}

//맨 위로 가기
function goToTop()
{
		window.scrollTo(0,0);
}

//문자열 변환 모두
function replaceAll(str, orgStr, repStr)
{
	if(str == null || str == ""){
		return str;
	}
	return str.split(orgStr).join(repStr);
}

//차트에 나타나는 날짜 포맷으로 변경
function chartDateFormat(strDate)
{
	/*
	if(arrStartDate[0].substr(0,1) == "0"){
		arrStartDate[0]= arrStartDate[0].replace("0", "");
	}
	if(arrStartDate[1].substr(0,1) == "0"){
		 arrStartDate[1] = arrStartDate[1].replace("0", "");
	}
	if(arrStartDate[2].substr(0,1) == "0"){
		arrStartDate[2]=arrStartDate[2].replace("0", "");
	}
	*/
	strDate 		= ""+strDate;

	var strMonth 	= strDate.substr(4,2);
	var strDay 		= strDate.substr(6,2);

	if(strMonth.substr(0,1) == "0"){
		strMonth = strMonth.replace("0", "");
	}


	if(strDay.substr(0,1) == "0"){
		strDay = strDay.replace("0", "");
	}
	return strMonth+"."+strDay;
}

function chartDateFormat2(strDate)
{
	strDate 		= ""+strDate;
	return strDate.substr(0,4)+"."+strDate.substr(4,2)+"."+strDate.substr(6,2);
}

//error msg 출력
function printErrorMsg(intErrorCode)
{
	/*
	//intErrorCode 에 따라 에러 메세지 출력 
	$(".pulse_box").html("에러발생");
	*/
	if(intErrorCode < 2){
		$("#Pulse_Splitter").replaceWith('<div id="error_page"><div>사용자의 접속이 많아 서비스가 불안정하니 잠시 후에<br />다시 이용하여 주십시오. </div></div>');
	}else{
		$("#contents_admin").replaceWith('<div id="error_page"><div>사용자의 접속이 많아 서비스가 불안정하니 잠시 후에<br />다시 이용하여 주십시오. </div></div>');

	}
}

//날짜차이구하는 함수
function calDateRange(val1, val2, format)
{
	//var FORMAT = ".";
	var FORMAT = format;

	//FORMAT을 포함한 길이 체크
	if (val1.length != 10 || val2.length != 10)
	return null;
	 
	//FORMAT이 있는지 체크
	if (val1.indexOf(FORMAT) < 0 || val2.indexOf(FORMAT) < 0)
	return null;
	 
	// 년도, 월, 일로 분리
	var start_dt = val1.split(FORMAT);
	var end_dt = val2.split(FORMAT);
	 
	
	 
	//월 - 1(자바스크립트는 월이 0부터 시작하기 때문에...)
	//Number()를 이용하여 08, 09월을 10진수로 인식하게 함.
	start_dt[1] = (Number(start_dt[1]) - 1) + "";
	end_dt[1] = (Number(end_dt[1]) - 1) + "";
	 
 	var from_dt = new Date(start_dt[0], start_dt[1], start_dt[2]);
	var to_dt = new Date(end_dt[0], end_dt[1], end_dt[2]);
	 
	return (to_dt.getTime() - from_dt.getTime()) / 1000 / 60 / 60 / 24;
}

//현재 페이지 파라미터 부분 반환
function getParamFromUrl(){
    var param = "";
    var href = location.href;

    if(href.indexOf('?') > -1){
        param = href.slice(href.indexOf('?')+1, href.length);
    }
	return param;

}

function CheckStrLen(maxlen,field)
{
    var temp; //들어오는 문자값...
    var msglen;

    msglen = maxlen*2;
    var value= field.value;

    l =  field.value.length;
    tmpstr = "" ;

    if (l == 0)
    {
        value = maxlen*2;
    }
    else
    {
        for(k=0;k<l;k++)
        {
            temp =value.charAt(k);

            if (escape(temp).length > 4)
                msglen -= 2;
            else
                msglen--;

            if(msglen < 0)
            {
                if(field.nodeName.toLowerCase() == 'textarea'){
                    alert("영문 1600자 한글 800자 까지 입력가능합니다.");
                }else{
                    alert("영문 200자 한글 100자 까지 입력가능합니다.");
                }
                field.value= tmpstr;
                break;
            }
            else
            {
                tmpstr += temp;
            }
        }
    }
}

/*
//max값 구하기 
Array.prototype.max = function() {
var max = this[0];
var len = this.length;
for (var i = 1; i < len; i++) if (this[i] > max) max = this[i];
return max;
}
//min값구하기 
Array.prototype.min = function() {
var min = this[0];
var len = this.length;
for (var i = 1; i < len; i++) if (this[i] < min) min = this[i];
return min;
}*/

//min값구하기 
function getMinVal(arr)
{
	var min = arr[0];
	var len = arr.length;
	for(var i=1; i < len; i++) if(arr[i] < min ) min = arr[i];
	return min;
}

//max값 구하기 
function getMaxVal(arr)
{
	var max = arr[0];
	var len = arr.length;
	for(var i=1; i < len; i++) if(arr[i] > max ) max = arr[i];
	return max;
}
/*
//padding 
function strpad(i, l, s) {
  var o = i.toString();
	if (!s) { s = '0'; }
	while (o.length < l) {
		o = s + o;
	}
	return o;
*/
/*
	result = padSting+inputString;
  remFromLeft=result.length-chars;
  return result.substr(remFromLeft);
*/
//}

function logout()
{
    $.ajax({
                              url: D_LOGOUT_URL,
                              global: false,
                              type: "POST",
                              cache:false,
                              data: ({}),
                              dataType: "json",
                              async:true,
                              success: function(data){
                                    location.href = "login.html";
                              },
                              error: function(data){
                                	//alert("error");
									return;
                              }
                           });

}

function escapeHtml(str){
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\"/g, "&quot;");
};
 
function unescapeHtml(str){
  return str.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, "\"");
};

/*
function escapeIssue(str){
	return str.replace(/'/g, "\'");

}*/

function checkByte(obj, maxlength) {

    var objstr = obj.value; 		// 입력된 문자열을 담을 변수
    var objstrlen = objstr.length; 	// 전체길이

    // 변수초기화
    var maxlen = maxlength; // 제한할 글자수 최대크기
    var i = 0; 				// for문에 사용
    var bytesize = 0; 		// 바이트크기
    var strlen = 0; 		// 입력된 문자열의 크기
    var onechar = ""; 		// char단위로 추출시 필요한 변수
    var objstr2 = ""; 		// 허용된 글자수까지만 포함한 최종문자열
    var limit_char = /[~!\#$^&*\=+|:;?"<,.>']/;

    // 입력된 문자열의 총바이트수 구하기
    for(i=0; i< objstrlen; i++) {
        // 한글자추출
        onechar = objstr.charAt(i);
        if (escape(onechar).length > 4) {
            bytesize += 2;	// 한글이면 2를 더한다.
        }else if(limit_char.test(onechar)){
            bytesize += 2;	//특수 기호이면 2를 더한다.
        }else {
            bytesize++;		// 그밖의 경우는 1을 더한다.
        }

		// 전체 크기가 maxlen를 넘지않으면
        if(bytesize <= maxlen*2) {
            strlen = i + 1;	// 1씩 증가
        }
    }

    // 총바이트수가 허용된 문자열의 최대값을 초과하면
    if(bytesize > maxlen*2){
		obj.blur();
		objstr2 = objstr.substr(0, strlen);
		obj.value = objstr2;

		//alert(3);
        alert( "입력 가능 글자수를 초과하였습니다.\n초과한 내용은 자동으로 삭제됩니다.");
	}
	obj.focus();
}

function replaceHtml(el, html) {
        var oldEl = (typeof el === "string" ? document.getElementById(el) : el);
        var newEl = document.createElement(oldEl.nodeName);
        newEl.id = oldEl.id;
        newEl.className = oldEl.className;
        newEl.innerHTML = html;
        oldEl.parentNode.replaceChild(newEl, oldEl);
        return newEl;
}

function closeAlertUserPageOnlyTwitt()
{
    $("#ly_userPageOnlyTwitt").hide();
}

function moveToWriterInfoPage(strUserId, intSource, strPulseId, strComPulseId, intPageNum, strTaskId){
	 if(intSource != 1){
        $("#ly_userPageOnlyTwitt .in_box").css("top", $(window).height()/2);
        $("#ly_userPageOnlyTwitt").show();
        return false;
    }
	
	var strCurrentPageName = getCurrentPageName();
	location.href = "writerinfo.html?ppn="+strCurrentPageName+"&pi="+getParam("pi")+"&cpi="+getParam("cpi")+"&u="+strUserId+"&pn="+intPageNum+"&ti="+strTaskId;

}


//input에 숫자만 입력받도록 체크하는 함수
function numbersonly(e, decimal) { 
 	var key; 
    var keychar; 

    if (window.event) { 
 	//IE에서 이벤트를 확인하기 위한 설정 
        key = window.event.keyCode; 
    } else if (e) { 
    //FireFox에서 이벤트를 확인하기 위한 설정 
        key = e.which; 
    } else { 
        return true; 
    } 

    keychar = String.fromCharCode(key); 
    if ((key == null) || (key == 0) || (key == 8) || (key == 9) || (key == 13) 
            || (key == 27)) { 
        return true; 
    } else if ((("0123456789").indexOf(keychar) > -1)) { 
        return true; 
    } else if (decimal && (keychar == ".")) { 
        return true; 
    } else 
        return false; 
}

/*
function onOnlyNumber(obj)
{
 for (var i = 0; i < obj.value.length ; i++){
  chr = obj.value.substr(i,1);  
  chr = escape(chr);
  key_eg = chr.charAt(1);
  if (key_eg == 'u'){
   key_num = chr.substr(i,(chr.length-1));   
   if((key_num < "AC00") || (key_num > "D7A3")) {
    event.returnValue = false;
   }    
  }
 }
 if (event.keyCode >= 48 && event.keyCode <= 57) {
  
 } else {
  event.returnValue = false;
 }
}*/



String.prototype.chunk = function(n) {
    var ret = [];
    for(var i=0, len=this.length; i < len; i += n) {
       ret.push(this.substr(i, n))
    }
    return ret
};

//펄스 클릭시 이동 
function clickSetScrollPulse(strComPulseId){
    $.ajax({
                              url: D_SET_SCROLL_PULSE_URL,
                              global: false,
                              type: "POST",
                              cache:false,
                              data: ({cpi: strComPulseId}),
                              dataType: "json",
                              async:false,
                              success: function(data){
                              },
                              error: function(data){
                                	//alert("error");
									return;
                              }
                           });

}

function getScrollPulse(intValidClickPulse){
	
	$.ajax({
                              url: D_GET_SCROLL_PULSE_URL,
                              global: false,
                              type: "POST",
                              cache:false,
                              data: ({ck:intValidClickPulse}),
                              dataType: "json",
                              async:true,
                              success: function(data){
                                    $('#ulScrollPulseList').html(data.html);
                              },
                              error: function(data){
                                	//alert("error");
									return;
                              }
                           });
}

function getStatStartDate()
{
    var now         = new Date();
    var minusMonth  = 7; // 6 Month + 1

    var currentYear     = now.getFullYear();
    var currentMonth    = now.getMonth() + 1;
    var currentDay      = now.getDate();

    var beforeMonth     = (currentMonth >= minusMonth ) ? currentMonth - minusMonth + 1 : (currentMonth - minusMonth + 1) + 12;

    beforeMonth     = (beforeMonth < 10)? "0"+beforeMonth:beforeMonth;
    var beforeYear      = (currentMonth >= minusMonth ) ? currentYear : currentYear - 1 ;
    var beforeDay       = "01";

    var strStatStartDate = beforeYear + "" + beforeMonth + "" + beforeDay;

    var arrStatStartDate = new Array();
    arrStatStartDate = {date: strStatStartDate,
                        year: beforeYear,
                        month: beforeMonth,
                        day: beforeDay}

    /*   Delete by Moon for Change Period (1Year --> 6 Months)
    //-1 년 전
    var lastYear = new Number(now.getFullYear() - 1);

    //-1 달 전, 10단위 0붙여서
    var lastMonth     = new Number((now.getMonth())>9 ? ''+(now.getMonth()):'0'+(now.getMonth()));
    lastMonth         = lastMonth<10? "0"+lastMonth: lastMonth;

    //일은 default 01 로
    var lastDay = "01";

    //총 날짜 조합
    var strStatStartDate = lastYear + "" + lastMonth + "" + lastDay;

    var arrStatStartDate = new Array();
    arrStatStartDate = {date: strStatStartDate,
                        year: lastYear,
                        month: lastMonth,
                        day: lastDay}
	*/
    return arrStatStartDate;
}
