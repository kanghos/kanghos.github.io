var ACCOUNT_REGIST_URL = "./ajax/account/ajaxAccountRegist.php";
var CONFIRM_EMAIL_URL = "./ajax/email/ajaxSendEmailConfirm.php";
var D_BASIC = "0";
var D_PLUS = "1";
var D_PRO = "2";

$().ready(function(){
	initSingupForm();
});

function initSingupForm()
{
	$("#inputEmail").val("");
	$("#inputPassword").val("");
	$("#inputRePassword").val("");
	$("#inputDomain").val("");
	$("#inputTel1").val("");
	$("#inputTel2").val("");
	$("#inputTel3").val("");
	$("#inputComp").val("");
	$("#inputName").val("");

	$(".help_msg").show();
	$(".error_msg").hide();
	$("#chk_mail").attr("checked", "");
}

function chgType(strType)
{
/*
	$(".change_plan li").removeClass("s_li");
	$(".change_plan li a").attr("href", "#");

	if(strType == D_BASIC){ 
		$("#BASIC").addClass("s_li");
		$("#BASIC > a").removeAttr("href");
		$(".choice_plan em span").html($("#BASIC > a").text());
	}else if(strType == D_PLUS){ 
		$("#PLUS").addClass("s_li");
		$("#PLUS > a").removeAttr("href");
		$(".choice_plan em span").html($("#PLUS > a").text());
	}else if(strType == D_PRO){ 
		$("#PRO").addClass("s_li");
		$("#PRO > a").removeAttr("href");
		$(".choice_plan em span").html($("#PRO > a").text()); 
		$("#customDom").removeClass("hidden");
	}
*/
	if(strType == D_BASIC){
		var str = "베이직 플랜<span>을 선택하였습니다.</span>";
		$("#inputDomain").attr('disabled', 'disabled');
	}else if(strType == D_PLUS){
		var str = "플러스 플랜<span>을 선택하였습니다.</span>";
		$("#inputDomain").attr('disabled', 'disabled');
	}else if(strType == D_PRO){
		var str = "프로 플랜<span>을 선택하였습니다.</span>";
	}
	$("#h3Plan").html(str);
}

function isValidEmailCheck(str) {

    var at="@"
    var dot="."
    var lat=str.indexOf(at)
    var lstr=str.length
    var ldot=str.indexOf(dot)
    if (str.indexOf(at)==-1){
       return false;
    }

    if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
       return false;
    }

    if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
        return false;
    }

    if (str.indexOf(at,(lat+1))!=-1){
        return false;
    }

    if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
        return false;
    }

    if (str.indexOf(dot,(lat+2))==-1){
        return false;
    }
	
	if (str.indexOf(" ")!=-1){
        return false;
    }

    return true;
}


function isValidPasswordCheck(strPassword)
{
	var intLength = strPassword.length;
	if(intLength < 5 || intLength > 10){
		return false;
	}
	return true;
}

function isValidRePasswordCheck(strPassword, strRePassword)
{
	if(strPassword != strRePassword)
	{
		return false;
	}
	return true;
}

function isValidDomainCheck(str)
{
/*
	for(var i=0;i<str.length;i++){	
		if(!((str.charCodeAt(i) >= 48 && str.charCodeAt(i) <= 57) ||
			(str.charCodeAt(i) >= 65 && str.charCodeAt(i) <= 90) ||
			(str.charCodeAt(i) >= 97 && str.charCodeAt(i) <= 122))){
			return false;
		}
	}
*/
/*
	var domainReg = /[A-Za-z0-9]/

    if(!domainReg.test(str)) {
        return false;
    }
*/
	var comp = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    var len = str.length;

    for(i=0;i<len;i++)
    {
        if(comp.indexOf(str.substring(i,i+1))<0)
        {
            return false;
        }
    }
    return true;
}

function isValidTelCheck(strTel1, strTel2, strTel3)
{
	var i = 0;
	var ch = "";
	var strField = strTel1;
	for (i = 0; i < strField.length; i++)
	{
		ch = strField.charAt(i);
        if (!((ch >= '0') && (ch <= '9')))
			return false;
	}

	i = 0;
	ch = "";
	strField = strTel2;
	for (i = 0; i < strField.length; i++)
    {
        ch = strField.charAt(i);
        if (!((ch >= '0') && (ch <= '9')))
            return false;
    }

	i = 0;
    ch = "";
    strField = strTel3;
    for (i = 0; i < strField.length; i++)
    {
        ch = strField.charAt(i);
        if (!((ch >= '0') && (ch <= '9')))
            return false;
    }

    return true;　
}

function clkCancel()
{
	initSingupForm();

	window.location = "signup.html";
}

function clkSignUp()
{
	$(".help_msg").show();
	$(".error_msg").hide();
	$("#chk_mail").attr("checked", "");

	var strEmail = $("#inputEmail").val();
	var strPassword = $("#inputPassword").val();
	var strRePassword = $("#inputRePassword").val();
    var strComp = $("#inputComp").val();
    var strName = $("#inputName").val();
	var strTel1 = $("#inputTel1").val();
	var strTel2 = $("#inputTel2").val();
	var strTel3 = $("#inputTel3").val();
	var isChkAgree = $("#chk_agree ").is(":checked");

	var isValidEmail = false;
	var isValidPwd = false;
	var isValidRePwd = false;
	var isValidComp = false;
	var isValidName = false;
	var isValidTel = false;
	var isPro = false;
	var isAllCheck = true;

	isValidEmail = isValidEmailCheck(strEmail);
	if(strEmail == ""){
		$("#spanHelpEmail").hide();
		$("#spanErrorEmail").html('이메일을 입력해 주세요. 이메일 주소는 로그인 아이디로 사용됩니다.');
		$("#spanErrorEmail").show();
		isAllCheck = false;
	}
	if(isValidEmail == false){
		$("#spanHelpEmail").hide();
		$("#spanErrorEmail").html('잘못된 이메일 형식입니다. 이메일 주소는 로그인 아이디로 사용됩니다.');
		$("#spanErrorEmail").show();
		isAllCheck = false;
	}

	isValidPwd = isValidPasswordCheck(strPassword);
	if(strPassword == ""){
        $("#spanHelpPwd").hide();
		$("#spanErrorPwd").html('비밀번호를 입력해 주세요.');
		$("#spanErrorPwd").show();
        isAllCheck = false;
	}
	if(isValidPwd == false){
		$("#spanHelpPwd").hide();
		$("#spanErrorPwd").html('5자 이상, 10자 이하로 입력해주세요.');
		$("#spanErrorPwd").show();
		isAllCheck = false;
	}	
	isValidRePwd = isValidRePasswordCheck(strPassword, strRePassword);
	if(strRePassword == ""){
		$("#spanHelpRePwd").hide();
		$("#spanErrorRePwd").html('비밀번호를 입력해 주세요.');
		$("#spanErrorRePwd").show();
		isAllCheck = false;
	}
	if(isValidRePwd == false) {
        $("#spanHelpRePwd").hide();
		$("#spanErrorRePwd").html('비밀 번호가 일치하지 않습니다.');
		$("#spanErrorRePwd").show();
		isAllCheck = false;
	}

	if(isNumber(strName) == true)
		isValidName = false;
	else
		isValidName = true;
	
	if(strName == ""){
		$("#spanErrorName").html('이름을 입력해 주세요.');
		$("#spanErrorName").show();
		isAllCheck = false;
	}
	if(isValidName == false){
		$("#spanErrorName").html('잘못된 이름 형식입니다.');
        $("#spanErrorName").show();
		isAllCheck = false;	
	}

	//PSKDV-911 20120514 start
	if(isNumber(strComp) == true)
		isValidComp = false;
	else
		isValidComp = true;
	
	if(strComp == ""){
		$("#spanErrorComp").html('회사명을 입력해 주세요.');
		$("#spanErrorComp").show();
		isAllCheck = false;
	}
	if(isValidComp == false){
		$("#spanErrorComp").html('잘못된 회사명 형식입니다.');
        $("#spanErrorComp").show();
		isAllCheck = false;	
	}
	//PSKDV-911 20120514 end


	isValidTel = isValidTelCheck(strTel1, strTel2, strTel3);
	if(strTel1 == "" || strTel2 == "" || strTel3 == ""){
		$("#spanErrorTel").html("전화번호를 입력해 주세요.");
		$("#spanErrorTel").show();
		isAllCheck = false;
	}
	if(isValidTel == false){
		$("#spanErrorTel").html("잘못된 전화번호 형식입니다.");
		$("#spanErrorTel").show();
		isAllCheck = false;
	}
	var strTel = strTel1+'-'+strTel2+'-'+strTel3;

	if(isChkAgree == false){
		$("#spanErrorAgree").show();
		isAllCheck = false;
	}	

	if(isAllCheck == false){ 
		return;
	}


	
	showTotLoading();

	///////QA 임시////////
	var	strType = 'PRO';
	
	$.ajax({
				url:ACCOUNT_REGIST_URL,
				global: false,
				type: "POST",
				cache: false,
				data: ({
							t:strType, 
							em:strEmail, 
							pw:strPassword, 
							tel:strTel, 
							cm:strComp, 
							nm:strName	
						}),
				dataType: "json",
				async:true,
				success:function(data){

					hideTotLoading();

					if(data.error == 0){
						//alert('success');
						//setCookie(D_PULSE_K_ID, strEmail, 0);
						//window.location= "emailconfirmation.html";
						window.location= "emailconfirmation.html?em="+strEmail;
					}else if(data.error == 2){
						alert("이미 등록된 이메일 주소 입니다.");
						return;
					}else if(data.error == 3){
						alert('사용되고 있는 메일 주소가 아닙니다.');
						return;
					}else if(data.error == 4){
						alert('메일 보내기에 실패하였습니다.\n다시 시도해 주시기 바랍니다.');
						//alert('error'+errormsg);
						return;
					}
				},
				error:function(){
					hideTotLoading();

					return;
					//alert('error');
				}
		});
	
}
