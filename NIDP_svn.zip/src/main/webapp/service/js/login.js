var GET_SNS_PROFILE_URL             = "./ajax/search/ajaxProfileSns.php";

var D_LOGIN_URL                     = "./ajax/login/login.php";
var SET_SNS_DATA_URL				= "./ajax/login/ajaxLoginSns.php";

var SEND_NEW_PWD_URL				= "./ajax/login/ajaxSendNewPwd.php";
var D_UPDATE_ISUSED_URL 			= "./ajax/account/ajaxUpdateIsUsed.php";

//var D_SECRET_URL            		= "https://www.pulsek.com/pulsek";
var FORM_NAME                       = "document.forms['frmLogin']";
//var D_HTTPS_URL                    	= "https://www.pulsek.com/pulsek/html/";
//var D_HTTP_URL 						= "http://www.pulsek.com/pulsek/html/";
var D_ACTIVE_URL 					= "dashboard.html";
var D_EXPIRATION_URL 				= "expiration.html";
var D_VBANK_URL						= "account_proc.html?t=vbank";

var intDelayTime					= 3000;

/*
var GET_SNS_PROFILE_URL_S           = D_HTTPS_URL+"ajax/search/ajaxProfileSns.php";
var D_LOGIN_URL_S                   = D_HTTPS_URL+"ajax/login/login.php";
var SET_SNS_DATA_URL_S				= D_HTTPS_URL+"ajax/login/ajaxLoginSns.php";
var SEND_NEW_PWD_URL_S				= D_HTTPS_URL+"ajax/login/ajaxSendNewPwd.php";
var D_UPDATE_ISUSED_URL_S 			= D_HTTPS_URL+"ajax/account/ajaxUpdateIsUsed.php";
*/

var GET_SNS_PROFILE_URL_S           = "./ajax/search/ajaxProfileSns.php";
var D_LOGIN_URL_S                   = "./ajax/login/login.php";
var SET_SNS_DATA_URL_S				= "./ajax/login/ajaxLoginSns.php";
var SEND_NEW_PWD_URL_S				= "./ajax/login/ajaxSendNewPwd.php";
var D_UPDATE_ISUSED_URL_S 			= "./ajax/account/ajaxUpdateIsUsed.php";


//var strCallBackUrl					= getCookie('pulseK_callback');
/*
$().ready(function(){
	alert(getCookie('pulseK_callback'));
});
*/
function onEnter(e){
	if(e.keyCode == 13){
    		login();	
	   	return false;
	}
}

function onNewPwdEnter(e){
	if(e.keyCode == 13){
		newPwd();
		return false;
	}
}

function getTimeStamp(){
 	var d = new Date();

 	var s =
    	leadingZeros(d.getFullYear(), 4) + '-' +
    	leadingZeros(d.getMonth() + 1, 2) + '-' +
    	leadingZeros(d.getDate(), 2) + ' ' +

    	leadingZeros(d.getHours(), 2) + ':' +
    	leadingZeros(d.getMinutes(), 2) + ':' +
    	leadingZeros(d.getSeconds(), 2);

  	return s;
}

function leadingZeros(n, digits) {
	var zero = '';
  	n = n.toString();

  	if (n.length < digits) {
    	for (i = 0; i < digits - n.length; i++)
      		zero += '0';
  	}
  	return zero + n;
}

function showErrorMsg()
{
	/*
	$('.error_msg').removeClass('hidden');
	setTimeout( "$('.error_msg').addClass('hidden')" , intDelayTime);
*/
	$('.error_msg').show();
	setTimeout( "$('.error_msg').hide()" , intDelayTime);
}

function login()
{
	var strId  	= trim($("#id").val());
	var strPwd 	= $("#pwd").val(); 
	var isValidEmail = false;
	isValidEmail = isValidEmailCheck(strId);

	if(strId == '' || isValidEmail == false){
		showErrorMsg();
		//$('.error_msg').removeClass('hidden');		
		return;
	}

	if(strPwd == ''){
		showErrorMsg();
		//$('.error_msg').removeClass('hidden');
		return;
	}

	var intChk = $("#u_chk").is(":checked")? 1:0;
	
	loginAjax(strId, strPwd, intChk, 0);
}

//트위터 로그인시 세션 연결 함수
function loginSns(intType)
{
	var strSetSnsDataUrl = "";
    if(intType == D_SHARE_TWITTER){
        var strSetSnsDataUrl	= SET_SNS_DATA_URL;
        var intAuthenticate  	= D_AUTH_TWITTER_AUTHENTICATE;
        var intForce         	= D_AUTH_TWITTER_FORCE_LOGIN;
        var strPostMessage   	= "";
    }else if(intType == D_SHARE_FACEBOOK){
//        var strSocialOAuthUrl= SET_SOCIAL_DATA_URL;
    }else{
        return;
    }

    var strUrl = strSetSnsDataUrl;
    strUrl+="?authenticate="+intAuthenticate+"&force="+intForce+"&msg="+strPostMessage;

    window.open(strUrl, "_blank");
}

//트위터 로그인시 세션 연결 후 콜백 함수 및 정보값 리턴
function callbackSetSnsData(intError, strErrorMsg, strUserId, strUserPwd)
{
	if(intError==0)
	{
		var intChk = $("#u_chk").is(":checked")? 1:0;
		loginAjax(strUserId, strUserPwd, intChk, 1);
	}
	else if(intError==2)
	{
		showErrorMsg();
		//$('.error_msg').removeClass('hidden');
		return;
		//ert(strErrorMsg);
	}
	else if(intError==3)
	{
		showErrorMsg();
		//$('.error_msg').removeClass('hidden');
		return;
		//alert(strErrorMsg);
	}
	else if(intError==1){
		printErrorMsg(1);
		//alert("error! "+ strErrorMsg);
	}
}

function moveActiveUrl(objJson){
	var strCallBackUrl	= getCookie('pulseK_callback');
	strCallBackUrl  = replaceAll(strCallBackUrl, "&cbu=1", "");
	strCallBackUrl  = replaceAll(strCallBackUrl, "cbu=1", "");
	
	//alert("[[["+strCallBackUrl+"]]][[["+getCookie('pulseK_callback')+"]]]");
	//alert(strCallBackUrl);	
	if(parseInt(objJson._intErr) == 0){ 
		setCookie("pulseK_callback", "", 365);
		//무료이용자일 경우
		if(objJson._IsCharge == 0){ 
			//가입한 시점부터 무료사용일이 안지났다면 로그인 이동
			var signupTime 		= objJson._SignupTime.split(' ');
			var currentTime 	= getTimeStamp().split(' '); 
			var intDiffDate 	= calDateRange(signupTime[0], currentTime[0], "-");	 





			if(intDiffDate < D_TRIAL_DAYS){ 
       	    	/*if(document.forms["frmLogin"].SSL_Login.checked ){
					//location.href = D_HTTPS_URL+D_ACTIVE_URL;
					location.href = D_HTTPS_URL+(getCookie('pulseK_callback')==null?D_ACTIVE_URL:getCookie('pulseK_callback'));
				}else{*/
				/*
					//location.href = D_HTTP_URL+D_ACTIVE_URL;
					if(objJson._State == '0'){
						location.href = D_HTTP_URL+D_VBANK_URL+"&vi="+objJson._VBankId;
					}
					else{
						location.href = D_HTTP_URL+(getCookie('pulseK_callback')==null?D_ACTIVE_URL:getCookie('pulseK_callback'));
					}
				//}*/
				
				if(document.forms["frmLogin"].SSL_Login.checked ){

					
					if(objJson._State == '0'){
						location.href = D_HTTPS_URL+D_VBANK_URL+"&vi="+objJson._VBankId;
					}
					else{
						//location.href = D_HTTPS_URL+(getCookie('pulseK_callback')==null?D_ACTIVE_URL:getCookie('pulseK_callback'));
						location.href = D_HTTPS_URL+((strCallBackUrl==null || strCallBackUrl== "")?D_ACTIVE_URL:strCallBackUrl);
					}

				}else{
					if(objJson._State == '0'){
						location.href = D_HTTP_URL+D_VBANK_URL+"&vi="+objJson._VBankId;
					}
					else{
						//location.href = D_HTTP_URL+(getCookie('pulseK_callback')==null?D_ACTIVE_URL:getCookie('pulseK_callback'));
						location.href = D_HTTP_URL+((strCallBackUrl==null || strCallBackUrl== "")?D_ACTIVE_URL:strCallBackUrl);
					}

				}

			}
			//무료사용일이 지났다면 서비스 종료 페이지 이동
			else{ 
			 	/*if(document.forms["frmLogin"].SSL_Login.checked ){ 
					location.href = D_HTTPS_URL+D_EXPIRATION_URL;
				}else{
					location.href = D_HTTP_URL+D_EXPIRATION_URL; 
				}*/
				if(document.forms["frmLogin"].SSL_Login.checked ){
					if(objJson._State == '0'){
						location.href = D_HTTPS_URL+D_VBANK_URL+"&vi="+objJson._VBankId;
					}
					else{
						location.href = D_HTTPS_URL+D_EXPIRATION_URL;
					}

				}else{
					if(objJson._State == '0'){
						location.href = D_HTTP_URL+D_VBANK_URL+"&vi="+objJson._VBankId;
					}
					else{
						location.href = D_HTTP_URL+D_EXPIRATION_URL;
					}
				}
			}

		}

		//유료이용자일 경우
		else if(objJson._IsCharge == 1){ 
			//사용기간 만료가 안됐다면 로그인 이동
			if(objJson._ExpireTime > getTimeStamp()){ 
				/*if(document.forms["frmLogin"].SSL_Login.checked ){
        			//location.href = D_HTTPS_URL+D_ACTIVE_URL;
					location.href = D_HTTPS_URL+(getCookie('pulseK_callback')==null?D_ACTIVE_URL:getCookie('pulseK_callback'));
				}else{*/
					//location.href = D_HTTP_URL+D_ACTIVE_URL;
					//location.href = D_HTTP_URL+(getCookie('pulseK_callback')==null?D_ACTIVE_URL:getCookie('pulseK_callback'));
				//}
				//
				if(document.forms["frmLogin"].SSL_Login.checked ){
					//location.href = D_HTTPS_URL+(getCookie('pulseK_callback')==null?D_ACTIVE_URL:getCookie('pulseK_callback'));
					location.href = D_HTTPS_URL+( (strCallBackUrl==null|| strCallBackUrl== "")?D_ACTIVE_URL:strCallBackUrl);
				}else{
					//location.href = D_HTTP_URL+(getCookie('pulseK_callback')==null?D_ACTIVE_URL:getCookie('pulseK_callback'));
					location.href = D_HTTP_URL+((strCallBackUrl==null|| strCallBackUrl== "")?D_ACTIVE_URL:strCallBackUrl);
				}
			}
			//사용기간 만료가 지났다면 tblpaymeny의 IsUsed 필드 값 변경 후 서비스 종료 페이지 이동
			else{
				updateIsUsed();	 
			}
		}
	}else if(parseInt(objJson._intErr) == 2){ 
		$('.error_msg').html('<img src="m_images/ico_error2.gif" width="12" height="14" alt="" />이메일 또는 비밀번호가 올바르지 않습니다.');
		showErrorMsg();
		//$('.error_msg').removeClass('hidden');
	}else if(parseInt(objJson._intErr) == 3){ 
		$('.error_msg').html('<img src="m_images/ico_error2.gif" width="12" height="14" alt="" />등록하신 메일을 확인하신 후 계정을 활성화 해 주시기 바랍니다.');
		showErrorMsg();
		//alert("등록하신 메일을 확인하신 후 계정을 활성화 해 주시기 바랍니다");
	}else{
		$('.error_msg').html('<img src="m_images/ico_error2.gif" width="12" height="14" alt="" />이메일 또는 비밀번호가 올바르지 않습니다.');
		showErrorMsg();
	}

}

function loginAjax(strId, strPwd, intChk, isSns)
{
	var strUrl = "";
	if(document.forms["frmLogin"].SSL_Login.checked ){
		strUrl = D_LOGIN_URL_S;
	}else{
		strUrl = D_LOGIN_URL;
	}
	

    $.ajax({
							  url:strUrl,
                              //url: D_LOGIN_URL,
                              global: false,
                              type: "POST",
                              cache:false,
                              data: ({id: strId, pwd: strPwd, chk:intChk, s:isSns}),
                              dataType: "json",
                              async:true,
                              success: function(data){
                                    moveActiveUrl(data);
                              },
                              error: function(data){
							  	showErrorMsg();
                                //$('.error_msg').removeClass('hidden');
                                return;
                              }
                           });

}

function updateIsUsed()
{
	var strUrl = "";
	if(document.forms["frmLogin"].SSL_Login.checked ){
		strUrl = D_UPDATE_ISUSED_URL_S;
	}else{
		strUrl = D_UPDATE_ISUSED_URL;
	}
				$.ajax({
							  url:strUrl,
                              //url: D_UPDATE_ISUSED_URL,
                              global: false,
                              type: "POST",
                              cache:false,
                              data: ({}),
                              dataType: "json",
                              async:false,
                              success: function(data){
                    			if(document.forms["frmLogin"].SSL_Login.checked ){
			                        location.href =  D_HTTPS_URL+D_EXPIRATION_URL;
            			        }else{
                        			location.href = D_HTTP_URL+D_EXPIRATION_URL;
			                    }
                              },
                              error: function(){
                                return;
                              }
                           });
	
}

function printGetSnsName(objJson){
    
	if(objJson.error == 0)
    {
        return objJson;
    }else{
        //alert(objJson.errormsg);
        return -1;
    }

}

function getSnsName(targetId)
{
	var strUrl = "";
	if(document.forms["frmLogin"].SSL_Login.checked ){
		strUrl = GET_SNS_PROFILE_URL_S;
	}else{
		strUrl = GET_SNS_PROFILE_URL;
	}
    var strJson = $.ajax({
							  url:strUrl,	
                              //url: GET_SNS_PROFILE_URL,
                              global: false,
                              type: "POST",
                              cache:false,
                              data: ({t:1, tid:targetId}),
                              dataType: "json",
                              async:true,
							  success:function(data){
								printGetSnsName(data);
							  },
                              error: function(){
                                return -1;
                              }
                           }).responseText;
}

function cancelPwd()
{
	$("#inputNewPwdEmail").val("");
//	$("#divErrorMsgNewPwdEmail").addClass("hidden");
	$("#divErrorMsgNewPwdEmail").hide();;
}

function newPwd()
{
	showTotLoading();
	var strEmail = $("#inputNewPwdEmail").val();
	var isValidEmail = false;
	//$("#divErrorMsgNewPwdEmail").addClass("hidden");
	$("#divErrorMsgNewPwdEmail").hide();

	isValidEmail = isValidEmailCheck(strEmail);
	if(strEmail == "" || isValidEmail == false){
		//$("#divErrorMsgNewPwdEmail").removeClass("hidden");
		$("#divErrorMsgNewPwdEmail").show();
		hideTotLoading();
		return;
	}

	var strUrl = "";
	if(document.forms["frmLogin"].SSL_Login.checked ){
		strUrl = SEND_NEW_PWD_URL_S;
	}else{
		strUrl = SEND_NEW_PWD_URL;
	}

	$.ajax({
					url:strUrl,
                    //url:SEND_NEW_PWD_URL,
                    global: false,
                    type: "POST",
                    cache:false,
                    data :({em:strEmail}),
                    dataType: "json",
                    async:true,
                    success:function(data){
						hideTotLoading();
						if(data.error == 3){
							alert('이미 등록되어 있는 계정입니다. 등록하신 메일을 확인하신 후 계정을 활성화 해 주시기 바랍니다');
							return;
						}else if(data.error == 2){
							alert("가입된 이메일이 아닙니다.");
							return;
						}else if(data.error == 1){
							printErrorMsg(1);
							//alert('mail send error');
						}
						$("#ly_findpw").css('display', 'none');
						$("#inputNewPwdEmail").val("");
                    	alert(strEmail+'로 임시 비밀번호를 발송하였습니다.');

					},
                    error:function(){
						hideTotLoading();
						printErrorMsg(1);
						return;
                    }
            });

}

function isValidEmailCheck(str) {

    var at="@"
    var dot="."
    var lat=str.indexOf(at)
    var lstr=str.length
    var ldot=str.indexOf(dot)
    if (str.indexOf(at)==-1){
       return false;
    }

    if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
       return false;
    }

    if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
        return false;
    }

     if (str.indexOf(at,(lat+1))!=-1){
        return false;
     }

     if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
        return false;
     }

     if (str.indexOf(dot,(lat+2))==-1){
        return false;
     }

     if (str.indexOf(" ")!=-1){
        return false;
     }

     return true;
}

function copyPaste()
{
    return false;
}

function disableCntrls(e)
{
    if(window.event) {
        if(e.keyCode == 17  || e.keyCode==93){
            return false;
        }else if(e.keyCode ==13){ 
    			login();
	   		return false;
		}
    }else{
        if(e.ctrlKey){
            return false;
        }else if(e.which == 13){
			login();	
			return false;
		}
    }
    return true;
}

function disContextMenu(e)
{
    $(e).bind("contextmenu", function(e){
        return false;
    });
}
