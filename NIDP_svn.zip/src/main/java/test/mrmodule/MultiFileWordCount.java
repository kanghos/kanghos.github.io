/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package test.mrmodule;

import java.io.BufferedReader;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.ArrayList;
import java.util.StringTokenizer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hdfs.DistributedFileSystem;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.InputSplit;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.MultiFileInputFormat;
import org.apache.hadoop.mapred.MultiFileSplit;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.RecordReader;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.lib.LongSumReducer;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import test.mrmodule.InputFormatter.MyInputFormat;
import test.mrmodule.InputFormatter.WordOffset;

import com.ntels.nidp.common.utils.ApiHdfs;
import com.ntels.nidp.common.utils.DBAccessUtil;



/**
 * MultiFileWordCount is an example to demonstrate the usage of 
 * MultiFileInputFormat. This examples counts the occurrences of
 * words in the text files under the given input directory.
 */
public class MultiFileWordCount extends Configured implements Tool {

	private static Log log = LogFactory.getLog(MultiFileWordCount.class);
	
	
	private static Configuration conf = null;
	private FileSystem fs = null;
	private DistributedFileSystem hdfs = null;
	public static Configuration getHrwpHdfsConf() {
		if (conf == null) {
			try {
				conf = new Configuration();
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else
			return conf;
		return conf;
	}
	
	public MultiFileWordCount() {
		try {
			/*if (hdfsPropertiesService != null) {

			} else {
				hdfsPropertiesService = HdfsPropertyManager
						.getMapReduceModuleProperties();
			}
			
			kmaRtInputPath = hdfsPropertiesService.getString("KMA_SRC_RT");
			skpRtInputPath = hdfsPropertiesService.getString("SKP_SRC_RT");
			intpRtInputPath = hdfsPropertiesService.getString("INTP_SRC_RT");
			
			kmaNrtInputPath = hdfsPropertiesService.getString("KMA_SRC_NRT");
			skpNrtInputPath = hdfsPropertiesService.getString("SKP_SRC_NRT");
			intpNrtInputPath = hdfsPropertiesService.getString("INTP_SRC_NRT");
			
			nasMroutRootURI =  hdfsPropertiesService.getString("MR_OUTPUT_FILE_REPO");
			mrLibRepo = hdfsPropertiesService.getString("MRMODULE_REPO"); 
			
			hdfsNameKey = hdfsPropertiesService.getString("HDFS_NAME");
			
			jobTrackerNameKey = hdfsPropertiesService.getString("MAPRED_JOB_TRACKER");
			hdfsNameVal = "hdfs://"
					+ hdfsPropertiesService.getString("HADOOP_MAIN_HOST") + ":"
					+ hdfsPropertiesService.getString("HDFS_PORT");
			
			jobTrackerNameVal = hdfsPropertiesService.getString("HADOOP_MAIN_HOST")  + ":"
					+ hdfsPropertiesService.getString("JOBTRACKER_PORT");
		
			mrOutPath = hdfsPropertiesService.getString("MROUT_PATH");
			conf = new Configuration();
			
			if (fs == null)
				fs = FileSystem.get(URI.create(hdfsNameVal), conf);

			if (hdfs == null)
				hdfs = (DistributedFileSystem) fs;
			
			fs = FileSystem.get(URI.create(hdfsNameVal), conf);
			hdfs = (DistributedFileSystem) fs;*/
			
			conf = new Configuration();
			if (fs == null)
				fs = FileSystem.get(URI.create("hdfs://218.239.45.37:9000"), conf);

			if (hdfs == null)
				hdfs = (DistributedFileSystem) fs;
			
			fs = FileSystem.get(URI.create("hdfs://218.239.45.37:9000"), conf);
			hdfs = (DistributedFileSystem) fs;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	

  /**
   * This Mapper is similar to the one in {@link WordCount.MapClass}.
   */
  public static class MapClass extends MapReduceBase
    implements Mapper<WordOffset, Text, Text, LongWritable> {

    private final static LongWritable one = new LongWritable(1);
    private Text word = new Text();
    
    public void map(WordOffset key, Text value,
        OutputCollector<Text, LongWritable> output, Reporter reporter)
        throws IOException {
      
      String line = value.toString();
      StringTokenizer itr = new StringTokenizer(line);
      while (itr.hasMoreTokens()) {
        word.set(itr.nextToken());
        output.collect(word, one);
      }
    }
  }
  
  
  private void printUsage() {
    System.out.println("Usage : multifilewc <input_dir> <output>" );
  }

  public int run(String[] args) throws Exception {

	  boolean dbOn = false;
    if(args.length < 2) {
      printUsage();
      return 1;
    }
    
    int mode = 1;		// 분석 모드
    
    DBAccessUtil dbA ;
	dbA = DBAccessUtil.getInstance();
	dbA.initialize();
	
    try{	
    	//String moduleName = "d:/nidp-testmr.jar";
    	String moduleName = "d:/nidp_twitter0.9.jar";
    
    JobConf job = new JobConf(getConf(), MultiFileWordCount.class);
    job.set("fs.default.name", "hdfs://218.239.45.37:9000");
    job.set("mapred.job.tracker", "218.239.45.37:9001");
    fs = FileSystem.get(job);
	fs.delete(new Path(args[1]), true);
	
    job.setJobName("MultiFileWordCount");
    job.setJar(moduleName);
    job.setJarByClass(MultiFileWordCount.class);
    //set the InputFormat of the job to our InputFormat
    job.setInputFormat(MyInputFormat.class);
    
    // the keys are words (strings)
    job.setOutputKeyClass(Text.class);
    // the values are counts (ints)
    job.setOutputValueClass(LongWritable.class);

    //use the defined mapper
    job.setMapperClass(MapClass.class);
    //use the WordCount Reducer
    job.setCombinerClass(LongSumReducer.class);
    job.setReducerClass(LongSumReducer.class);

    if(mode == 1) 
    	args[0] = "/data/twitter/out/stem/part-00000";
    else if(mode == 2) 
    	args[0] = "/data/twitter/out/url/part-00000";
    
    FileInputFormat.addInputPaths(job, args[0]);
    FileOutputFormat.setOutputPath(job, new Path(args[1]));

    System.out.println("MultiFile Word Count Process Start!!");
    JobClient.runJob(job);
    String tmpStr = "", tmpUrlStr = "";
    
    ArrayList readList = (ArrayList)ApiHdfs.getInstance().readFileStream( args[1]+"/part-00000" ) ;
    StringTokenizer tStr = null; 
    String[] strlist = null, tknList = null;
	//lineStr = null;
	for(int i = 0; i<readList.size();i++) {
		//lineStr = new String( (String)readList.get(i).getBytes("UTF-8"), "UTF-8"); 
		//System.out.println((String)readList.get(i));
		tmpStr = new String(((String)readList.get(i)).toString().getBytes("UTF-8"), "UTF-8");
		//System.out.println("str:"+tmpStr);
		if(mode == 1) {
			if(tmpStr.contains("+0900"))
			{	
				strlist = tmpStr.split("\\+0900,");
				/*for(int j = 0; j< strlist.length; j++) {
					System.out.println("tokens["+j+"]:"+strlist[j]);
				}*/
				
				//dbA.insertTwitterHit(strlist[0], Integer.parseInt(strlist[1].trim()), Integer.parseInt(DateUtils.getCurrentTime("yyyyMMdd")));
			}
		
			
			if(tmpStr.contains("[NG]")) {
				tmpStr = tmpStr.replace("[NG]","");
				//System.out.println("str:"+tmpStr);
				strlist = tmpStr.split("\t");
				if(Integer.parseInt(strlist[1].trim()) >= 3)
					dbA.insertTwtWord( strlist[0], Integer.parseInt(strlist[1].trim()), 1);
				
			} else 
				if(tmpStr.contains("[NP]")) {
					tmpStr = tmpStr.replace("[NP]","");
					//System.out.println("str:"+tmpStr);
					strlist = tmpStr.split("\t");
					if(Integer.parseInt(strlist[1].trim()) >= 3)
						dbA.insertTwtWord( strlist[0], Integer.parseInt(strlist[1].trim()), 2);				
				}
			else 
				if(tmpStr.contains("[SL]")) {
					tmpStr = tmpStr.replace("[SL]","");
					//System.out.println("str:"+tmpStr);
					strlist = tmpStr.split("\t");
					if(Integer.parseInt(strlist[1].trim()) > 2)
						dbA.insertTwtWord( strlist[0], Integer.parseInt(strlist[1].trim()), 3);
			}
			
		} else 
			if(mode == 2){
				strlist = tmpStr.split(",");
				//strlist[0].substring(0, strlist[0].indexOf("\"") )
				if(strlist[0].contains("\"")) {
					tmpUrlStr = strlist[0].substring(0, strlist[0].indexOf("\"") ) ;
					//System.out.println( "str:"+strlist[1]);
					
				} else {
					tmpUrlStr = strlist[0].trim();
				}
				tknList = strlist[1].split("\t");
				
				if(tknList.length > 1) {
					System.out.println( "str:"+tknList[0]);
					tmpStr = tknList[0].trim();
					if(tknList[1].length() != 0) {
						if(tmpStr.contains("[NG]")) {
							tmpStr = tmpStr.replace("[NG]","");
							//System.out.println("str:"+tmpStr);
							strlist = tmpStr.split("\t");
							if(Integer.parseInt(tknList[1].trim()) >= 5)
								dbA.insertTwtWordUrl(tmpStr, tmpUrlStr, Integer.parseInt(tknList[1].trim()));
							
						} else 
							if(tmpStr.contains("[NP]")) {
								tmpStr = tmpStr.replace("[NP]","");
								//System.out.println("str:"+tmpStr);
								strlist = tmpStr.split("\t");
								if(Integer.parseInt(tknList[1].trim()) >= 5)
									dbA.insertTwtWordUrl(tmpStr, tmpUrlStr, Integer.parseInt(tknList[1].trim()));		
							}
						else 
							if(tmpStr.contains("[SL]")) {
								tmpStr = tmpStr.replace("[SL]","");
								//System.out.println("str:"+tmpStr);
								strlist = tmpStr.split("\t");
								if(Integer.parseInt(tknList[1].trim()) >= 5)
									dbA.insertTwtWordUrl(tmpStr, tmpUrlStr, Integer.parseInt(tknList[1].trim()));
						}
					
					}
				}
				//if(Integer.parseInt(strlist[1].trim()) >= 5)
				//	dbA.insertTwtWordUrl( strlist[0], Integer.parseInt(strlist[1].trim()));
		}
	}
    
    } catch (Exception ex) {
		
		log.error(ex.getMessage());
		ex.printStackTrace();
	} finally {
		dbA.closeConnection();
		return 0;
	}
   // return 0;
  }

  public static void main(String[] args) throws Exception {
	  //args[0] = "URL";
    int ret = ToolRunner.run(new Configuration(), new MultiFileWordCount(), args);
    System.exit(ret);
  }

}
