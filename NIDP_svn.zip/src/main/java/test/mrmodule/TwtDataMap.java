package test.mrmodule;

import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

import com.ntels.nidp.common.utils.DateTimeUtils;

import java.util.regex.*;
/**
 * twitter data Mapper
 * 
 * @author hskang
 */
public class TwtDataMap extends MapReduceBase implements
		Mapper<Object, Text, Text, Text> {
	
	private static String startDt;
	private static String endDt;
	private int termsCd;
	
	private final Text awskey = new Text();
	
	private static String[] fixAwsList = null;
	
	public void configure(JobConf job) {
		double meanVal = 0;
		String awsListStr = "";
		
		super.configure(job);
		
		awsListStr = job.get("awsList", awsListStr);
		
		startDt = job.get("startDt");
		endDt = job.get("endDt");
		termsCd = job.getInt("terms", termsCd);
		
		fixAwsList = awsListStr.split(",");
	}

	@Override
	public void map(Object key, Text value,
			OutputCollector<Text, Text> output, Reporter reporter)
			throws IOException {
		try {

			String lineStr = "";
			String tkKey; 
			String dateTimeStr;
					
			String[] strList, lineList;
			
			
			//Pattern pp = Pattern.compile("[|EOL]+");
			
			//ArrayList<String> strList = new ArrayList<String>();
			//StringTokenizer itr = new StringTokenizer(value.toString(), "\f");
			//StringTokenizer itr = new StringTokenizer(value.toString(), ":EOL");
			
			lineList = value.toString().split(":EOL");

			//StringTokenizer linetoken = null;
			//linetoken = new StringTokenizer(value.toString(), "\n");
			//Regex r = new Regex("shells");
			//Pattern p = Pattern.compile("[|,]+");
			
			for(int i=0; i<lineList.length;i++) {
			//while (itr.hasMoreTokens()) {
				//lineStr = itr.nextToken();
				lineStr = lineList[i].toString();
				//lineStr = new String( itr.nextToken().getBytes("UTF-8"), "MS949");
				//lineStr = new String( itr.nextToken().getBytes(), "UTF-8"); 
				//linetoken = new StringTokenizer(itr.nextToken(), "|,");
				
				//strList = p.split(itr.nextToken());
				//strList = p.split(lineList[i]);
				strList = lineStr.split(":,");
				if (strList.length <= 1) {
					return;
				}
				/*int i = 0;
				if (linetoken.countTokens() >= 1) {
					while(linetoken.hasMoreTokens()){
						  strList.add(i,(String)linetoken.nextToken());
						  i++;
				    }
				}*/
				//tkKey = linetoken.
				
				tkKey = strList[0].trim();// +":"+ DateTimeUtils.getStringDateFormat12(strList[1].trim(), "yyyyMMddHH" );
				//tkKey = strList.get(0);
				
				awskey.set(tkKey);
				output.collect(awskey, new Text(" "+strList[3].trim()) );
				//output.collect(awskey, new Text(strList.get(0)) );
				//output.collect(awskey, awsId = new AwsDataWritable(strList) );
				
				/*if(termsCd == 1) {
					//tkKey = strList[0].trim() +":"+ strList[1].trim();
					tkKey = strList[0].trim() +":"+ DateTimeUtils.getStringDateFormat12(strList[1].trim(), "yyyyMMddHHmm" );
					awskey.set(tkKey);
					
					if( (Long.parseLong(DateTimeUtils.getStringDateFormat12(startDt, "yyyyMMddHHmm")) <= Long.parseLong(DateTimeUtils.getStringDateFormat12(strList[1].trim(), "yyyyMMddHHmm")) )
							&& (Long.parseLong(DateTimeUtils.getStringDateFormat12(endDt, "yyyyMMddHHmm")) >= Long.parseLong(DateTimeUtils.getStringDateFormat12(strList[1].trim(), "yyyyMMddHHmm")) ) ) {
						//output.collect(awskey, awsId = new AwsDataWritable(strList) );
					} else {
						break;
					}
					
				} else 
				
				if(termsCd == 2) {
					//tkKey = strList[0].trim() +":"+ strList[1].trim();
					tkKey = strList[0].trim() +":"+ DateTimeUtils.getStringDateFormat12(strList[1].trim(), "yyyyMMddHH" );
					awskey.set(tkKey);
					
					if( (Long.parseLong(DateTimeUtils.getStringDateFormat12(startDt, "yyyyMMddHH")) <= Long.parseLong(DateTimeUtils.getStringDateFormat12(strList[1].trim(), "yyyyMMddHH")) )
							&& (Long.parseLong(DateTimeUtils.getStringDateFormat12(endDt, "yyyyMMddHH")) >= Long.parseLong(DateTimeUtils.getStringDateFormat12(strList[1].trim(), "yyyyMMddHH")) ) ) {
					
						;
					} else {
						break;
					}
					//output.collect(awskey, awsId = new AwsDataWritable(strList) );
				} 
				else {
					tkKey = strList[0].trim() +":"+ DateTimeUtils.getStringDateFormat12(strList[1].trim(), "yyyyMMdd" );
					awskey.set(tkKey);
					if(Integer.parseInt(DateTimeUtils.getStringDateFormat12(startDt, "yyyyMMdd")) <= Integer.parseInt(DateTimeUtils.getStringDateFormat12(strList[1].trim(), "yyyyMMdd"))
							&& Integer.parseInt(DateTimeUtils.getStringDateFormat12(startDt, "yyyyMMdd")) >= Integer.parseInt(DateTimeUtils.getStringDateFormat12(strList[1].trim(), "yyyyMMdd"))  ) {
						//output.collect(awskey, awsId = new AwsDataWritable(strList) );
					} else {
						break;
					}
				}
				//output.collect(awskey, awsId = new AwsDataWritable(strList) );
				
				if(fixAwsList.length != 1) {
					for(int i = 0; i < fixAwsList.length; i++) {
						if(fixAwsList[i].equals(strList[0].trim())) {
							//genKeyVal(startDt, endDt, strList[0], strList[1], termsCd);
							output.collect(awskey, awsId = new AwsDataWritable(strList) );
						}
					} 
				}
				else {
					if("".equals(fixAwsList[0])) {
						output.collect(awskey, awsId = new AwsDataWritable(strList) );
					}else {
						if(fixAwsList[0].equals(strList[0].trim())) {
							output.collect(awskey, awsId = new AwsDataWritable(strList) );
						}
					}
					//
				}
			*/	//
			}

		} catch (Exception e) {

		}
	}
	
	
	private String genKeyVal(String startDt, String endDt, String awsId, String timeStamp, int termsCd) {
		String keyStr="";
		if(termsCd == 1) {
			//tkKey = strList[0].trim() +":"+ strList[1].trim();
			keyStr = awsId.trim() +":"+ DateTimeUtils.getStringDateFormat12(timeStamp.trim(), "yyyyMMddHHmm" );
			//awskey.set(tkKey);
			
			if( (Long.parseLong(startDt) <= Long.parseLong(DateTimeUtils.getStringDateFormat12(timeStamp.trim(), "yyyyMMddHHmm")) )
					&& (Long.parseLong(endDt) >= Long.parseLong(DateTimeUtils.getStringDateFormat12(timeStamp.trim(), "yyyyMMddHHmm")) ) ) {
				//output.collect(awskey, awsId = new AwsDataWritable(strList) );
			} else {
				keyStr = "";
			//	break;
			}
			
		} else if(termsCd == 2) {
			//tkKey = strList[0].trim() +":"+ strList[1].trim();
			keyStr = awsId.trim() +":"+ DateTimeUtils.getStringDateFormat12(timeStamp.trim(), "yyyyMMddHH" );
			//awskey.set(tkKey);
			
			if(Integer.parseInt(startDt) <= Integer.parseInt(DateTimeUtils.getStringDateFormat12(timeStamp.trim(), "yyyyMMddHH"))
					&& Integer.parseInt(endDt) >= Integer.parseInt(DateTimeUtils.getStringDateFormat12(timeStamp.trim(), "yyyyMMddHH"))  ) {
				//output.collect(awskey, awsId = new AwsDataWritable(strList) );
			} else {
				keyStr = "";
			//	break;
			}
		}
		
		return keyStr;
	}
}
