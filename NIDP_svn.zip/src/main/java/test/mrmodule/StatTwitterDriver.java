/**
 * 엔텔스(주) | http://ntels.com
 * Copyright (c)2007-2013, nTels Co., Ltd.
 * All rights reserved.
 */
package test.mrmodule;

import java.io.BufferedReader;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.ResourceBundle;
import java.util.StringTokenizer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hdfs.DistributedFileSystem;

import test.mrmodule.InputFormatter.MyInputFormat;
import test.mrmodule.TwtDataMap;
import test.mrmodule.MultiFileWordCount.MapClass;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.InputSplit;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;


import org.apache.hadoop.mapred.JobStatus;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.MultiFileInputFormat;
import org.apache.hadoop.mapred.MultiFileSplit;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.RecordReader;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.RunningJob;
import org.apache.hadoop.mapred.TextInputFormat;
import org.apache.hadoop.mapred.TextOutputFormat;
import org.apache.hadoop.mapred.lib.LongSumReducer;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import com.ntels.nidp.common.config.HdfsPropertyManager;
import com.ntels.nidp.common.log.LogManager;
import com.ntels.nidp.common.utils.ApiHdfs;
import com.ntels.nidp.common.utils.DBAccessUtil;
import com.ntels.nidp.common.utils.DateUtils;
import com.ntels.nidp.common.utils.StringUtil;



/**
 *  Driver
 * 
 * @author
 */
public class StatTwitterDriver extends Configured implements Tool {

	//static LogManager log = new LogManager("ntels.nidp");
	private static Log log = LogFactory.getLog(StatTwitterDriver.class);
	//private static Log log = LogFactory.getLog(StatTwitterDriver.class);
	int debugFlag = 99;
	DBAccessUtil dbA = null;
	
	//@Autowired
	//HwcManService hwcManSvc;
	
	private ResourceBundle hdfsPropertiesService;
	static enum AwsCounters { INPUT_AWSRECORDS } 
	
	private static Configuration conf = null;
	
	private FileSystem fs = null;
	private DistributedFileSystem hdfs = null;
	
	private static String hdfsNameVal, jobTrackerNameVal;
	private static String hdfsNameKey, jobTrackerNameKey;
	
	private static String MRRootURI = null;
	private static String mrLibRepo = null;
	
	private static String mrOutPath;

	public StatTwitterDriver() {
		super();
		try {
			if (hdfsPropertiesService != null) {
				ResourceBundle.clearCache();
			} else {
				hdfsPropertiesService = HdfsPropertyManager.getMapReduceModuleProperties();
			}
			
			MRRootURI =  hdfsPropertiesService.getString("MR_OUTPUT_FILE_REPO");
			mrLibRepo = hdfsPropertiesService.getString("MRMODULE_REPO"); 
			
			hdfsNameKey = hdfsPropertiesService.getString("HDFS_NAME");
			
			jobTrackerNameKey = hdfsPropertiesService.getString("MAPRED_JOB_TRACKER");
			hdfsNameVal = "hdfs://"
					+ hdfsPropertiesService.getString("HADOOP_MAIN_HOST") + ":"
					+ hdfsPropertiesService.getString("HDFS_PORT");
			
			jobTrackerNameVal = hdfsPropertiesService.getString("HADOOP_MAIN_HOST")  + ":"
					+ hdfsPropertiesService.getString("JOBTRACKER_PORT");
		
			mrOutPath = hdfsPropertiesService.getString("MROUT_PATH");
			conf = new Configuration();
			System.out.println(hdfsNameVal);
			/*if (fs == null)
				fs = FileSystem.get(URI.create(hdfsNameVal), conf);

			if (hdfs == null)
				hdfs = (DistributedFileSystem) fs;
			
			fs = FileSystem.get(URI.create(hdfsNameVal), conf);
			hdfs = (DistributedFileSystem) fs;*/
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static Configuration getHrwpHdfsConf() {
		if (conf == null) {
			try {
				conf = new Configuration();
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else
			return conf;
		return conf;
	}

	@Override
	public int run(String[] args) throws Exception {
		
		//String moduleName = "d:/NIDP_twitter.jar";
		String moduleName = hdfsPropertiesService.getString("MOD_TWEET_ANALYZER_NAME");//"d:/nidp_twitter0.9.jar";
		
		String kmaStep1Out = "";
		String skpkmaStep1Out = "";
		String intpStep1Out = "";
		
		int dbInsKeys[] = {0,0,0,0,0,0,0,0};
		dbA = DBAccessUtil.getInstance();
		dbA.initialize();
		//System.out.println(args[5]);
	try{	
	//	System.out.println("Run mod");		
	//	new JarClassLoader("d:/NIDP_twitter.jar");
		//100,12,101"; //awsList.toString();
		RunningJob jobs1_1=null, jobs1_2=null, jobs1_3=null, jobs2_1=null, jobs2_2=null, job3_1=null, job3_2=null,  job4_1=null, job4_2=null;
		JobConf step1_twitter_JobConf, step2_wordCnt_JobConf, step3_abstUrl_jobConf;
		RunningJob[] job2 = {null,null,null};
		
		String stepOut = "/data/twitter/out/stem/"+args[3];
		String stepUrlOut = "/data/twitter/out/url/"+args[3];
		//String stepIn = "/data/twitter/2013111412/*";
		//String stepIn = "/data/twitter/2013111509/tweets_20131115093708";
		//String stepIn = "/data/twitter/2013111518/tweets_20131115185725";
		//String stepIn = "/data/twitter/2013112616/tweets_20131126162128";
		//String stepInList = "/data/twitter/20131202*/tweets_2013120212*";
		String stepInList = "/data/twitter/"+args[0]+"/tweets_"+args[1]+"*";
		String stepIn1MinList = "/data/twitter/"+args[0]+"/tweets_"+args[2]+"*";
		String stepInFiles = "";
		//Path twitterStep1Path = new Path(kmaStep1Out);
		System.out.println("step-1Min :"+stepInList);
		System.out.println("step-2Min :"+stepIn1MinList);
		//Path twitterDataIn = new Path(stepIn);
		Path twitterDataOut = new Path(stepOut);
		Path twitterUrlOut = new Path(stepUrlOut);
		Path twitterDataInNow = new Path(stepInList);
		Path twitterDataIn1Min = new Path(stepIn1MinList);
		//twitterDataIn = twitterDataInList;
		
		
		//System.out.println("File Count :"+ApiHdfs.getInstance().checkPathGlobStaus("/data/twitter/2013121813/tweets_2013121813*"));
		
		if(!"".equals(stepInList) && !"".equals(stepIn1MinList)) {
			System.out.println("checkFileExist[stepInList]:"+ApiHdfs.getInstance().checkPathGlobStaus(stepInList));
			if(ApiHdfs.getInstance().checkPathGlobStaus(stepInList)) {
				
				stepInFiles = stepInList;
				if(ApiHdfs.getInstance().checkPathGlobStaus(stepIn1MinList)) {
					System.out.println("checkFileExist:"+stepIn1MinList);
					stepInFiles += "," + stepIn1MinList;
				}
			} else {
				System.out.println("checkFileExist[stepIn1MinList]:"+ApiHdfs.getInstance().checkPathGlobStaus(stepIn1MinList));
				
				if(ApiHdfs.getInstance().checkPathGlobStaus(stepIn1MinList)) {
					System.out.println("checkFileExist:"+stepIn1MinList);
					stepInFiles = stepIn1MinList;
				} else {
					stepInFiles = "none";
				}
			}
		}
		System.out.println("File stepInFiles :"+stepInFiles);
		
		// -------------------------
		//step1 Job 설정
		// ----------------------------------------------
		step1_twitter_JobConf = new JobConf(getConf(), StatTwitterDriver.class);
		step1_twitter_JobConf.set(hdfsNameKey, hdfsNameVal);
		step1_twitter_JobConf.set(jobTrackerNameKey, jobTrackerNameVal);
		
		step1_twitter_JobConf.setJobName("locality_Twitterdata-Stat(1)");
		// output 초기화
		try{
			fs = FileSystem.get(step1_twitter_JobConf);
		} catch(IOException e) {
			e.printStackTrace();
		}

		System.out.println("RUN2"+fs.getUsed());
		fs.delete(twitterDataOut, true);
		fs.delete(twitterUrlOut, true);
		
		///////
		//jobConf.set("awsListSize", locMeanList.size());
		//step1_twitter_JobConf.set("awsList", fixAwsList);
		//System.out.println("awsSz="+ fixAwsList.split(",").length);
		
		/*
		System.out.println("startDt:"+startDt);
		System.out.println("endDt:"+endDt);
		System.out.println("kmaInPaths:"+kmaInPaths);
		
		step1_kma_JobConf.setStrings("startDt", startDt);
		step1_kma_JobConf.setStrings("endDt", endDt);
		*/
		/*for(int i=0; i < locMeanList.size(); i++) {
			jobConf.set("row"+i, locMeanList.get(i));	
			//System.out.println("locality Means="+"row"+i+ "    " +locMeanList.get(i));
		}*/
		//-----------------------------------------------------------
		// Set Tweet data steming
		///////////////////////
		step1_twitter_JobConf.setJarByClass(StatTwitterDriver.class);
		//conf.setJarByClass(skp.hrwp.hdfs.mr.analyzer.locality.awscomp.AwsDataWritable.class);
		step1_twitter_JobConf.setOutputKeyClass(Text.class);
		step1_twitter_JobConf.setOutputValueClass(Text.class);
		step1_twitter_JobConf.setMapperClass(TwtDataMap.class);
		// conf.setCombinerClass(AwsDataCombine.class);
		//step1_twitter_JobConf.setReducerClass(AwsDataReduce.class);

		step1_twitter_JobConf.setInputFormat(TextInputFormat.class);
		step1_twitter_JobConf.setOutputFormat(TextOutputFormat.class);
		step1_twitter_JobConf.setJar(moduleName);
		FileInputFormat.setInputPaths(step1_twitter_JobConf, stepInFiles);//twitterDataInNow, twitterDataIn1Min);
		FileOutputFormat.setOutputPath(step1_twitter_JobConf, twitterDataOut);
		step1_twitter_JobConf.setBoolean("statawsdata.case.sensitive", false);
		step1_twitter_JobConf.set("mapred.textoutputformat.separator", ",");
		//-----------------------------------------------------------
		// Set Tweet extract URL
		///////////////////////
		step3_abstUrl_jobConf = new JobConf(getConf(), StatTwitterDriver.class);
		step3_abstUrl_jobConf.set(hdfsNameKey, hdfsNameVal);
		step3_abstUrl_jobConf.set(jobTrackerNameKey, jobTrackerNameVal);
		step3_abstUrl_jobConf.setJarByClass(StatTwitterDriver.class);
		 		//conf.setJarByClass(skp.hrwp.hdfs.mr.analyzer.locality.awscomp.AwsDataWritable.class);
		step3_abstUrl_jobConf.setOutputKeyClass(Text.class);
		step3_abstUrl_jobConf.setOutputValueClass(Text.class);
		step3_abstUrl_jobConf.setMapperClass(TwtUrlDataMap.class);
		// conf.setCombinerClass(AwsDataCombine.class);
		//step1_twitter_JobConf.setReducerClass(AwsDataReduce.class);

		step3_abstUrl_jobConf.setInputFormat(TextInputFormat.class);
		step3_abstUrl_jobConf.setOutputFormat(TextOutputFormat.class);
		step3_abstUrl_jobConf.setJar(moduleName);
		FileInputFormat.setInputPaths(step3_abstUrl_jobConf, stepInFiles);
		FileOutputFormat.setOutputPath(step3_abstUrl_jobConf, twitterUrlOut);
		step3_abstUrl_jobConf.setBoolean("statawsdata.case.sensitive", false);
		step3_abstUrl_jobConf.set("mapred.textoutputformat.separator", ",");
		
		if(debugFlag >= 1) {
//				//log.info("Start Twitter Analyzing Job");
				//System.out.println(step1_twitter_JobConf.getWorkingDirectory().getName());
			if(!"none".equals(stepInFiles)) {
				jobs1_1 = JobClient.runJob(step1_twitter_JobConf);			// step1 job run
				jobs1_2 = JobClient.runJob(step3_abstUrl_jobConf);			// step1 job run
			}
			else System.out.println("[NIDP_Tweet] NonData which NoT RUN!!");
		}
		if(!"none".equals(stepInFiles)) {
			if(jobs1_1.getJobState() == JobStatus.SUCCEEDED) {
				System.out.println("Step1-1 Process End!!");
			}
			if(jobs1_2.getJobState() == JobStatus.SUCCEEDED) {
				System.out.println("Step1-2 Process End!!");
			}
		}
		
		//------------------------------- MultiWordCnt
		int mode = 1;		// 분석 모드
		
		String step2In ="/data/twitter/out/stem/"+args[3]+"/part-00000";
		
		for(int i=0; i<2; i++) {
			System.out.println("2nd["+mode+"] Process Start!!");
			mode = i+1;
		String step2Out = "/data/twitter/result";
		if(mode == 1) {
			step2In = stepOut;//"/data/twitter/out/stem/part-00000";
			step2Out = "/data/twitter/stem/result"+args[3];
		}
	    else if(mode == 2) {
	    	step2In = stepUrlOut;//"/data/twitter/out/url/part-00000";
	    	step2Out = "/data/twitter/url/result/"+args[3];
	    }
	    
		//step2In = args[0];
	//	Path twitterData2In = new Path(step2In);
	//	Path twitterData2Out = new Path(step2Out);
		Path twitterData2In = new Path(step2In);
		Path twitterData2Out = new Path(step2Out);
		//Path twitterDataInList = new Path(stepInList);
		
		step2_wordCnt_JobConf = new JobConf(getConf(), StatTwitterDriver.class);
		step2_wordCnt_JobConf.set(hdfsNameKey, hdfsNameVal);
		step2_wordCnt_JobConf.set(jobTrackerNameKey, jobTrackerNameVal);
		
		//if(statCode==1)
		step1_twitter_JobConf.setJobName("locality_Twitterdata-WordCount(["+mode+"])");
		
	    fs = FileSystem.get(step2_wordCnt_JobConf);
		fs.delete(new Path(step2Out), true);
		
		step2_wordCnt_JobConf.setJobName("MultiFileWordCount["+mode+"]");
		step2_wordCnt_JobConf.setJar(moduleName);
		step2_wordCnt_JobConf.setJarByClass(StatTwitterDriver.class);
	    //set the InputFormat of the job to our InputFormat
		step2_wordCnt_JobConf.setInputFormat(MyInputFormat.class);
	    
	    // the keys are words (strings)
		step2_wordCnt_JobConf.setOutputKeyClass(Text.class);
	    // the values are counts (ints)
		step2_wordCnt_JobConf.setOutputValueClass(LongWritable.class);

	    //use the defined mapper
		step2_wordCnt_JobConf.setMapperClass(MapClass.class);
	    //use the WordCount Reducer
		step2_wordCnt_JobConf.setCombinerClass(LongSumReducer.class);
		step2_wordCnt_JobConf.setReducerClass(LongSumReducer.class);
	    
	    FileInputFormat.addInputPaths(step2_wordCnt_JobConf, step2In);
	    FileOutputFormat.setOutputPath(step2_wordCnt_JobConf, twitterData2Out);
	    if(!"none".equals(stepInFiles)) {
	    	job2[mode] = JobClient.runJob(step2_wordCnt_JobConf);
	    	if( job2[mode].getJobState() == JobStatus.SUCCEEDED) {
	    		System.out.println("2nd-["+mode+"] Process End!!");
	    	}
	     insertDBData(step2Out, mode);	// Analyze data DBInsert Process
	    }
	   // insertDBData(step2Out, 2);	// Analyze data DBInsert Process
	    fs.delete(new Path(step2Out+""), true);
	    fs.delete(new Path(step2In+""), true);
	    
		}	//for end
	    //----------------------------------------------------------------
		//-------------------------------------------------
		job2[mode].cleanupProgress();
		//cleanupStagingDir();
		log.info("[NIDP_Twitter Data] Tweet Analytic Process End!!");
		//--------
	} catch (Exception ex) {
		
		//log.error(ex.getMessage());
		ex.printStackTrace();
	} finally {
		return 0;
	}
		

	}

	// static Configuration conf;

	public static void main(String[] args) throws Exception {
		//args = new String[4];
		args = new String[3];

		final String startDate = DateUtils.getCurrentTime("yyyyMMddHH");
		final String startTime = DateUtils.getCurrentTime("mm");
		Calendar cal1 = Calendar.getInstance();
		
		cal1.add(Calendar.MINUTE, -1); // 현재의 1분전 데이터가 대상
		String tm_1m_ago = StringUtil.getMinFormat(cal1.getTime()); // yyyyMMddHHmm
		String ago1mDate = StringUtil.getHourFormat(cal1.getTime());
		//call.clear();
		cal1.add(Calendar.MINUTE, -1); // 현재의 1분전 데이터가 대상
		String tm_2m_ago = StringUtil.getMinFormat(cal1.getTime()); // yyyyMMddHHmm
		//startDate = DateUtil.formatDate(DateUtil)
		
		//final String inputPath = "/user/test/aws/rt/20120801";
		//final String inputPath = "/hrwp/aws/kma/src/rt/";				// 성용 환경 적용
		//final String inputPath2 = "/user/hadoop/aws/test/201208/";      //상용PCS
		
		//final String inputPath = "/user/hadoop/test/aws/2012/AWS_MIN_";
		
		//final String outputPath = "/user/test/step1/out/";
		//final String outputPath2 = "/user/test/step2/out";
		//final String outputPath3 = "/user/test/step3/deviation/out";
		
		//final String outputPath = "/hrwp/mrout/step1/";
//System.out.println("ddddd="+ "s8427#201302240100#37.58583450317383#126.90055847167969#0.0#2050.64#15.23#-17.00#317.69#10186.38#10296.45#0.36#0.00#0.00#0.00#0.00#1986.39#25.39#0.00#0.00#0.01#=".split("#").toString());
		System.out.println(startDate);
		args[0] = ago1mDate;		// statCode 통계 항목 코드(module_cd)
		args[1] = tm_1m_ago;		// 기간단위  통계 항목 코드(termsCd)
		args[2] = tm_2m_ago;	// 1분전
		/*args[3] = "201303120104"; //enddate
		
		args[4] = "";//"서울 종로구";
		args[5] = startDate;
		args[6] = startTime;*/
		
		int res = 0;
		try {		
			res = ToolRunner.run(new Configuration(), new StatTwitterDriver(), args);
			System.out.println("res="+res);
		} catch (Exception ex)	{
			ex.printStackTrace();
		}
		//System.exit(res);
		
		 //cleanupStagingDir();
	}
	
	
	public void insertDBData(String output, int mode) throws Exception {
		String tmpStr = "", tmpUrlStr = "";
		 System.out.println("Insert to DB starting!");
		DBAccessUtil dbA = null;
		int insertCnt = 0;
		try {
			dbA = DBAccessUtil.getInstance();
			dbA.initialize();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		
	    ArrayList readList = (ArrayList)ApiHdfs.getInstance().readFileStream( output+"/part-00000" ) ;
	    log.info("DFS URL:"+output);
	    StringTokenizer tStr = null; 
	    String[] strlist = null, tknList = null;
		//lineStr = null;
	   
		for(int i = 0; i<readList.size();i++) {
			//lineStr = new String( (String)readList.get(i).getBytes("UTF-8"), "UTF-8"); 
			//System.out.println((String)readList.get(i));
			tmpStr = new String(((String)readList.get(i)).toString().getBytes("UTF-8"), "UTF-8");
			
			if(mode == 1) {
				
				if(tmpStr.contains("+0900"))
				{	
					strlist = tmpStr.split("\\+0900,");
					/*for(int j = 0; j< strlist.length; j++) {
						System.out.println("tokens["+j+"]:"+strlist[j]);
					}*/
					//System.out.println("str:"+strlist);
					if(insertCnt == 0) {
						dbA.updatetTwitterHit(strlist[0], Integer.parseInt(strlist[1].trim()), DateUtils.getCurrentTime("yyyyMMdd"));
						insertCnt++;
					}
					else {
						if(strlist[1] == null) {
							dbA.insertTwitterHit(strlist[0], 0, DateUtils.getCurrentTime("yyyyMMdd"));
							insertCnt++;
						} else {
							//System.out.println("str:"+Integer.parseInt(strlist[1].trim()));
							dbA.insertTwitterHit(strlist[0], Integer.parseInt(strlist[1].trim()), DateUtils.getCurrentTime("yyyyMMdd"));
							insertCnt++;
						}
					}
				}
			
				
				if(tmpStr.contains("[NG]")) {
					tmpStr = tmpStr.replace("[NG]","");
					//System.out.println("str[NG]:"+tmpStr);
					strlist = tmpStr.split("\t");
					if(Integer.parseInt(strlist[1].trim()) >= 3)
						dbA.insertTwtWord( strlist[0], Integer.parseInt(strlist[1].trim()), 1);
					
				} else 
					if(tmpStr.contains("[NP]")) {
						tmpStr = tmpStr.replace("[NP]","");
						//System.out.println("str[NP]:"+tmpStr);
						strlist = tmpStr.split("\t");
						if(Integer.parseInt(strlist[1].trim()) >= 3)
							dbA.insertTwtWord( strlist[0], Integer.parseInt(strlist[1].trim()), 2);				
					}
				else 
					if(tmpStr.contains("[SL]")) {
						tmpStr = tmpStr.replace("[SL]","");
						//System.out.println("str:"+tmpStr);
						strlist = tmpStr.split("\t");
						if(Integer.parseInt(strlist[1].trim()) > 2)
							dbA.insertTwtWord( strlist[0], Integer.parseInt(strlist[1].trim()), 3);
				}
				
			} else 
				if(mode == 2){
					strlist = tmpStr.split(",");
					//strlist[0].substring(0, strlist[0].indexOf("\"") )
					if(strlist[0].contains("\"")) {
						tmpUrlStr = strlist[0].substring(0, strlist[0].indexOf("\"") ) ;
						//System.out.println( "str:"+strlist[1]);
						
					} else {
						tmpUrlStr = strlist[0].trim();
					}
					tknList = strlist[1].split("\t");
					
					if(tknList.length > 1) {
					//	System.out.println( "str:"+tknList[0]);
						tmpStr = tknList[0].trim();
						if(tknList[1].length() != 0) {
							if(tmpStr.contains("[NG]")) {
								tmpStr = tmpStr.replace("[NG]","");
								//System.out.println("str:"+tmpStr);
								strlist = tmpStr.split("\t");
								if(Integer.parseInt(tknList[1].trim()) >= 5)
									dbA.insertTwtWordUrl(tmpStr, tmpUrlStr, Integer.parseInt(tknList[1].trim()));
								
							} else 
								if(tmpStr.contains("[NP]")) {
									tmpStr = tmpStr.replace("[NP]","");
									//System.out.println("str:"+tmpStr);
									strlist = tmpStr.split("\t");
									if(Integer.parseInt(tknList[1].trim()) >= 5)
										dbA.insertTwtWordUrl(tmpStr, tmpUrlStr, Integer.parseInt(tknList[1].trim()));		
								}
							else 
								if(tmpStr.contains("[SL]")) {
									tmpStr = tmpStr.replace("[SL]","");
									//System.out.println("str:"+tmpStr);
									strlist = tmpStr.split("\t");
									if(Integer.parseInt(tknList[1].trim()) >= 5)
										dbA.insertTwtWordUrl(tmpStr, tmpUrlStr, Integer.parseInt(tknList[1].trim()));
							}
						
						}
					}
					//if(Integer.parseInt(strlist[1].trim()) >= 5)
					//	dbA.insertTwtWordUrl( strlist[0], Integer.parseInt(strlist[1].trim()));
			}
		} // for End;
		dbA.closeConnection();
		
	}
		
}