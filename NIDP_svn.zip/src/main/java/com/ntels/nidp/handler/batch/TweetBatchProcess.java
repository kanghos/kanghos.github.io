package com.ntels.nidp.handler.batch;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.util.ToolRunner;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;

import test.mrmodule.StatTwitterDriver;

import com.ntels.nidp.common.loader.CompilationClassLoader;
import com.ntels.nidp.common.log.LogManager;
import com.ntels.nidp.common.thread.action.Work;
import com.ntels.nidp.common.utils.DateUtils;
import com.ntels.nidp.common.utils.StringUtil;

	
	public class TweetBatchProcess extends QuartzJobBean {
		static LogManager log = new LogManager("ntels.nidp");
		private ResourceBundle hdfsPropertiesService;
		
		private Configuration hadoopConfiguration;
		
		private int[] jobList = new int[9];
		private int taskCnt = 0;
		
		/**
		 * @return the hadoopConfiguration
		 */
		public Configuration getHadoopConfiguration() {
			return hadoopConfiguration;
		}

		/**
		 * @param hadoopConfiguration the hadoopConfiguration to set
		 */
		public void setHadoopConfiguration(Configuration hadoopConfiguration) {
			this.hadoopConfiguration = hadoopConfiguration;
		}

		/* (non-Javadoc)
		 * @see org.springframework.scheduling.quartz.QuartzJobBean#executeInternal(org.quartz.JobExecutionContext)
		 */
		protected void executeInternal(JobExecutionContext ctx) throws JobExecutionException {
			
			//*****************************************************//
			//*****************  설정 매일 갱신  ******************//
			//*****************************************************//
			
			log.debug("Twitter Data Analyzer Called !! " );
			
			//System.out.println("Tweet Batch Service Called !! ");
			String[] args = new String[3];
			//String taskid = "";
			Map map = new HashMap();
			map = ctx.getMergedJobDataMap();
			map.put("return_code", 1);
			map.put("return_msg", "");
			System.out.println(jobList.length);
			int taskid = 0;
			
			/*if(taskCnt == 0) {
				//taskCnt = 0;
				jobList[1] = 1;
				taskid = 1;
				taskCnt = 1;
			} else {
				//if(jobList.length 
				for(int i=1; i < 9; i++) {
					if(jobList[i] == 0) {
						taskid = i;
						jobList[i] = 1;
						taskCnt++;
						break;
					} else {
						break;
					}
				}
			}*/
			
			String currDateTime = DateUtils.getCurrentTime("yyyyMMddHHmm");
			Calendar cal1 = Calendar.getInstance();
			//cal1.setTime(cal.getTime());
			cal1.add(Calendar.MINUTE, -1); // 현재의 1분전 데이터가 대상
			String tm_1m_ago = StringUtil.getMinFormat(cal1.getTime()); // yyyyMMddHH
			
			args[0] = tm_1m_ago;
			args[1] = currDateTime;
			args[2] = currDateTime;
			map.put("tm_1m_ago",  tm_1m_ago);
			map.put("currDateTime",  currDateTime);
			
			//Work.getInstance().
			map.put("command",  "TWITTER_BATCH_HANDLER");
			Work.getInstance().makeRequest(map);
			
		}
		
		public boolean urlConnection(String httpUrl) {
			URL url;//URL 주소 객체
	        URLConnection connection;//URL접속을 가지는 객체
	        InputStream is;//URL접속에서 내용을 읽기위한 Stream
	        InputStreamReader isr;
	        BufferedReader br;

	        try{
	            //URL객체를 생성하고 해당 URL로 접속한다..
	            url = new URL(httpUrl);
	            connection = url.openConnection();

	            //내용을 읽어오기위한 InputStream객체를 생성한다..
	            is = connection.getInputStream();
	            isr = new InputStreamReader(is);
	            br = new BufferedReader(isr);

	            //내용을 읽어서 화면에 출력한다..
	            String buf = null;
	            while(true){
	                buf = br.readLine();
	                if(buf == null) break;
	                System.out.println(buf);
	            }
	            return true;
	        }catch(MalformedURLException mue){
	            System.err.println("잘못되 URL입니다. 사용법 : java URLConn http://hostname/path]");
	            return false;

	        }catch(IOException ioe){
	            System.err.println("IOException " + ioe);
	            ioe.printStackTrace();
	            return false;
	        }
	    }


		
		/**
		 * @param args
		 */
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
		}

		 public static String decimalFormat(String format, Object value){
		    	DecimalFormat df = new DecimalFormat(format);
		    	return df.format(value);
		   }
		 
		 
	}
