package com.ntels.nidp.analyzer.invoker;

import java.io.File;
import java.io.FileWriter;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import com.ntels.nidp.analyzer.loader.RuntimeJarLoader;
import com.ntels.nidp.common.handler.AbstractHandler;
import com.ntels.nidp.common.log.LogManager;
import com.ntels.nidp.common.utils.DateUtils;
import com.ntels.nidp.common.utils.StringUtil;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.util.ToolRunner;

import test.mrmodule.StatTwitterDriver;

/**

 * @author 
 *
 */
public class TwitterBatchHandler extends AbstractHandler {
	
	/**
	 * 로깅 클래스
	 */
	private static LogManager log = new LogManager(LogManager.NTELS_NIDP_ANALYZER);
	
	/** 
	 * 국별 정보 () key : src_addr
	 **/
	private static HashMap<String, Integer> wordMap;
	

	/**
	 * 배치 시작 시간
	 */
	private long batchStartTime;
	
	/**
	 * 배치 종료 시간
	 */
	private long batchEndTime;
	
	/**
	 * 결과 DB 등록 DAO	
	 */ 
	//private TwitterDAO twtDAO;
	
	/**
	 * TwitterDAO
	 * @return QcDAO
	 */
	/*public TwitterDAO getTwitterDAO() {
		return twtDAO;
	}*/

	/**
	 * TwitterDAO 설정
	 * @param twtDAO
	 */
	/*public void setTwitterDAO(TwitterDAO twtDAO) {
		this.twtDAO = twtDAO;
	}*/
	
	/**
	 * 스케줄러에서 정해진 시간에 호출하는 메소드<br>
	 * <br>
	 * 비실시간으로(일배치) 데이터에 대한  처리한다.<br>
	 * 멀티쓰레드로 처리하기 위해 "command"를 "TWITTER_BATCH_HANDLER"으로 설정하여 TASK를 구동하면 TwitterBatchHandler가 실행된다.<br>
	 *   
	 * @param map Job을 수행하기 위한 인자값 Map
	 * @return 결과값 Map
	 */
	/* (non-Javadoc)
	 * @see com.ntels.nidp.common.handler.AbstractHandler#doHandle(java.util.Map)
	 */
	@Override
	public Map doHandle(Map map) {
		System.out.println("Start!");
		log.info("MapReduceHandler doHandle....");
		if (map != null) {
			log.debug("Twitter Batch (map size:" + map.size() + ")");
		}
		else {
			log.debug("Twitter Batch (map size: 0)");
		}
		System.out.println(map.get("tm_1m_ago"));
		
		try {
			
			//map.put("return_code", 1);
			//map.put("return_msg", "");
			
			String[] args = new String[4];
			this.batchStartTime = System.currentTimeMillis();
			
			/*if (twtDAO == null) {
				qcDAO = QCConfiguration.cmmn_dao;
			}*/
			
			log.info("******** Twitter Analyzer Handler Batch Started *********");
			log.info("(map:" + map + ", twtDAO:" + 00 + ")");
			
			
			//*****************************************************//
			//****************  데이터 수집  변환    *******************//
			//*****************************************************//
			/*Calendar cal = Calendar.getInstance();
			cal.add(Calendar.MINUTE, -2); // 현재의 2분전 데이터가 대상
			 */			
			String currDateTime = DateUtils.getCurrentTime("yyyyMMddHHmm");
			Calendar cal1 = Calendar.getInstance();
			
			cal1.add(Calendar.MINUTE, -1); // 현재의 1분전 데이터가 대상
			String tm_1m_ago = StringUtil.getMinFormat(cal1.getTime()); // yyyyMMddHH
			String ago1mDate = StringUtil.getHourFormat(cal1.getTime());
			//log.info("[RUNNING TASKID]: now TaskID: " +this
					
			cal1.add(Calendar.MINUTE, -1); // 현재의 1분전 데이터가 대상
			String tm_2m_ago = StringUtil.getMinFormat(cal1.getTime()); // yyyyMMddHHmm
			
			log.info("[ELAPED PER SEC]2min Elapsed : NowTime: " +currDateTime + "      1min ago:" + tm_1m_ago + "(msec)");
			//for (int i=0; i<24; i++) {  // 00시부터 23시까지
			
			
			
			long analStartTime = System.currentTimeMillis();
			
			//RuntimeJarLoader.getInstance().loadJarIndDir("d:/", "testmr.jar" , args);
			
			//----------------------------
	

			final String startDate = DateUtils.getCurrentTime("yyyyMMddHH");
			final String startTime = DateUtils.getCurrentTime("mm");
			String nowDate = StringUtil.getHourFormat(cal1.getTime());
			//
			System.out.println(startDate);
			args[0] = ago1mDate;		// s
			args[1] = tm_1m_ago;		// 1
			args[2] = tm_2m_ago;	// 2분전
			args[3] = startDate+startTime;	// 2분전
			//args[3] = aa;	// 2분전
			//----------------------------
			
			int res = 0;
			try {		
				// MapReduce 구동
				res = ToolRunner.run(new Configuration(), new StatTwitterDriver(), args);
			} catch (Exception ex)	{
				ex.printStackTrace();
			}
			
			long analEndTime = System.currentTimeMillis();
			log.info("[ELAPED PER SEC]Analyzing Elapsed : " + (analEndTime - analStartTime) + "(msec)");
			
			this.batchEndTime = System.currentTimeMillis();
			log.info("[ELAPED 2Min TWEET ANALYZE BATCH TOTAL] " + (batchEndTime - batchStartTime) + "(msec)");
			map.put("return_code", res);
		} catch (Exception e) {
			log.recordException(e);
		}
		
		return map;
	}
		
}
