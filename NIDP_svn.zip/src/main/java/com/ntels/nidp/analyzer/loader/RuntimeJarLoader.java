package com.ntels.nidp.analyzer.loader;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
 
/**
 * RuntimeJarLoader
 * @author hskang
 */
public class RuntimeJarLoader {
	public static final String BIGDATA_LOG_NAME_COMMON = "nidp.bigdata.common";
	public static final String BIGDATA_LOG_NAME_DAEMON = "nidp.bigdata.daemon";
	
	public static String CLASS_LOADER_METHOD_NAME;
	
	static final Logger log = Logger.getLogger(BIGDATA_LOG_NAME_COMMON);
	
	private volatile static RuntimeJarLoader instance;
	
	public RuntimeJarLoader(Singleton singleton) throws IOException {
	}
	
	public static RuntimeJarLoader getInstance() {
		if(instance == null)
			synchronized (RuntimeJarLoader.class) {
				if(instance == null)
					try {
						instance = new RuntimeJarLoader(new Singleton());
					} catch (IOException e) {
						e.printStackTrace();
					}
			}
		return instance;
	}
	
	private static class Singleton {
		public Singleton() {}
	}
	
    public void loadJarIndDir(String dir, final String startJar, final String[] params) {
    	log.debug("RuntimeJarLoader loadJarIndDir() loader dir : " + dir + "\t startJar : " + startJar + "\t params : " + params.toString());
    	final List<String> jarName = new ArrayList<String>();
    	final String dirStr = dir;
    	
        try{
            final URLClassLoader loader = (URLClassLoader)ClassLoader.getSystemClassLoader();
            final Method method = URLClassLoader.class.getDeclaredMethod("addURL", new Class[]{URL.class});
            method.setAccessible(true);
             
            new File(dir).listFiles(new FileFilter() {
                public boolean accept(File jar) {
                    if( jar.toString().toLowerCase().contains(".jar") ){
                        try{
                        	if(jar.getName().equals(startJar) || startJar == null) {
	                            method.invoke(loader, new Object[]{jar.toURI().toURL()});
	                            log.debug("RuntimeJarLoader loadJarIndDir() jar name : " + (dirStr + jar.getName()) + " is loaded."  + " method :" + method.getName());
	                            jarName.add(jar.getName());
	                            
	                            log.debug("loading Startttt:" + jar.getName());
	                            System.out.println("loading Startttt:" + dirStr + jar.getName());
	            				JarClassLoader jcl = new JarClassLoader(dirStr + jar.getName());
	            				System.out.println("loading enddd:" + jar.getName());
	            				Class<?> startObject = null;
	            				Class<?> classObject = null;
	            				String startClasses = "";
	            				String classes = "";
	            				
	            				int classSize = jcl.getLoadedClasses().size();
	            				//System.out.println("loading Startttt:" + classes);
	            				log.debug("loading start:" + classSize);
	            				for(int i = 0; i < classSize; i++) {
	            					classes = jcl.getLoadedClasses().get(i);
	            					System.out.println("loading Startttt:" + classes);
	            					log.debug("RuntimeJarLoader loadJarIndDir() classes : " + classes);
	            					
	            					
	            					//if(classObject.isLocalClass()) {
	            						classObject = loader.loadClass(classes);
	            						
	            						classObject.newInstance();
	            					//}
	            					if(classes.indexOf("$") <= 0) {
	            						startObject = classObject;
	            						startClasses = classes;
	            					}
	            				}
	            				
	            				invokeClass(loader, startObject, startClasses, params);
                        	}
                        }catch(Exception e){
                        	e.printStackTrace();
                        	log.debug("RuntimeJarLoader loadJarIndDir() " + jar.getName()+ " can't load.");
                        }
                    }
                    return false;
                }
            });
        } catch(Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    private void invokeClass(URLClassLoader loader, Class<?> startClasses, String classes, String[] params) {
    	log.debug("RuntimeJarLoader loadJarIndDir() invokeClass classes : " + classes);
    	try {
			Method m = startClasses.getMethod(CLASS_LOADER_METHOD_NAME, new Class[] { String[].class });
			m.setAccessible(true);
		    int mods = m.getModifiers();
		    
		    if (m.getReturnType() != void.class || !Modifier.isStatic(mods) ||
		        !Modifier.isPublic(mods)) {
		        throw new NoSuchMethodException(CLASS_LOADER_METHOD_NAME);
		    }
		    
		    String[] args = params;
			m.invoke(loader, new Object[] {args});
			
    	} catch(Exception e) {
    		e.printStackTrace();
    	}
    }
}