package com.ntels.nidp.analyzer.loader;


import java.io.BufferedInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Enumeration;
import java.util.LinkedList;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

import org.apache.log4j.Logger;

/**
 * JarClassLoader
 * @author hskang
 */
public class JarClassLoader extends ClassLoader {
	public static final String BIGDATA_LOG_NAME_COMMON = "nidp.bigdata.common";
	static final Logger log = Logger.getLogger(BIGDATA_LOG_NAME_COMMON);
	
	private List<String> loadedClasses;

	public JarClassLoader(String jarPath) throws FileNotFoundException, IOException {
		loadedClasses = new LinkedList<String>();
		System.out.println("JarClassLoader loadClasses() JARpath : " + jarPath);
		loadClasses(jarPath);
	}

	public List<String> getLoadedClasses() {
		return loadedClasses;
	}

	private void loadClasses(String jarFilePath) throws FileNotFoundException, IOException {
		log.debug("JarClassLoader loadClasses() loader jarFilePath : " + jarFilePath);
		JarFile jarFile = null;
		BufferedInputStream jarInputStream = null;
		Class klass = null;
        
        // 클래스를 로드할 때, 캐시를 사용할 수 있다.
       // klass = (Class) cache.get(className);
        
		try {
			jarFile = new JarFile(jarFilePath);

			Enumeration<JarEntry> entries = jarFile.entries();
			JarEntry entry = null;

			while (entries.hasMoreElements()) {
				entry = entries.nextElement();
				
				if (entry.getName().endsWith(".class")) {
					try {
						String className = getClassName(entry);
						
						jarInputStream = new BufferedInputStream(jarFile.getInputStream(entry));
						byte[] data = new byte[(int) entry.getSize()];
						log.info("JarClassLoader loadClasses() name : " + className);
						jarInputStream.read(data);
						System.out.println("className="+data.toString());
						try {
							/*try {
								klass = super.findSystemClass(className);
							}catch (ClassNotFoundException  ex) {
								
							}
							*/
							 if(klass == null) {        
							 try {           
								//klass = defineClass(data, 0, data.length);
									 //c = getParent().loadClass(className);
								klass =	 defineClass(className, data, 0, data.length);
									} catch (ClassFormatError e) {
										
									}   
								 if(klass == null)  
									 klass = findClass(className);    
							 }
							 //if (resolve)
						     resolveClass(klass);
						      //   cache.put(className, klass); // 캐시에 추가
							
						//if(!this.loadedClasses.contains(className)) {
							//defineClass(className, data, 0, data.length);
						//}
							System.out.println("!!!!!!!="+data.length);
						this.loadedClasses.add(className);
						} catch (Exception ex) {ex.getMessage();}
					} finally {
						if (null != jarInputStream) {
							try {
								jarInputStream.close();
							} catch (Exception e) {
							} finally {
								jarInputStream = null;
							}
						}
					}
				}
			} 
		} finally {
			if (jarFile != null) {
				try {
					jarFile.close();
				} catch (Exception e) {
				} finally {
					jarFile = null;
				}
			}
		}
	}

	private String getClassName(JarEntry classEntry) {
		return classEntry.getName().replace(".class", "").replace("/", ".");
	}
		
}
