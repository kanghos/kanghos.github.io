package com.ntels.nidp.mvc.comp.hive.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.ntels.nidp.mvc.comp.hive.domain.AnalyzermetaVo;

public class AnalyzermetaDaoImpl implements AnalyzermetaDao {

	private SqlSession sqlSession;
	
	public void setSqlSession(SqlSession sqlSess) {
		this.sqlSession = sqlSess; 
	}
	
	@Override
	public List<AnalyzermetaVo> getListAll() {
		return sqlSession.selectList("getAnalyzermetaListAll");
	}

	@Override
	public AnalyzermetaVo getById(AnalyzermetaVo analyzermetaVo) {
		return sqlSession.selectOne("getAnalyzermetaById", analyzermetaVo);
	}

	@Override
	public int insert(AnalyzermetaVo analyzermetaVo) {
		return sqlSession.insert("insertAnalyzermeta", analyzermetaVo);
	}

	@Override
	public int update(AnalyzermetaVo analyzermetaVo) {
		return sqlSession.update("update", analyzermetaVo);
	}

	public int deleteAnalyzerMetaByDataId(int dataId) {
		return sqlSession.delete("deleteAnalyzerMetaByDataId", dataId);
	}

}
