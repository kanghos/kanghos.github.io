package com.ntels.nidp.mvc.comp.hive.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.ntels.nidp.mvc.comp.hive.domain.HiveqlVo;

public class HiveqlDaoImpl implements HiveqlDao{
	
	private SqlSession sqlSession;
	
	public void setSqlSession(SqlSession sqlSess) {
		this.sqlSession = sqlSess; 
	}
		
	public List<HiveqlVo> getListAll(){
		return  sqlSession.selectList("getHiveqlListAll");
	}

	public HiveqlVo getById(HiveqlVo hiveqlVo){
		return  sqlSession.selectOne("getHiveqlById", hiveqlVo);
	}

	public int insert(HiveqlVo hiveqlVo){
		return sqlSession.insert("insertHiveql", hiveqlVo);	
	}

	public int update(HiveqlVo hiveqlVo){
		return sqlSession.update("updateHiveqlVo", hiveqlVo);
	}

	public List<HiveqlVo> getListById(HiveqlVo hiveqlVo) {
		return sqlSession.selectList("getHiveqlListById", hiveqlVo);
	}

	public int delete(HiveqlVo hiveqlVo) {
		return sqlSession.delete("delHiveqlVo", hiveqlVo);
	}

	public int deleteHiveqlByDataId(int dataId) {
		return sqlSession.delete("deleteHiveqlByDataId", dataId);
	}

}
