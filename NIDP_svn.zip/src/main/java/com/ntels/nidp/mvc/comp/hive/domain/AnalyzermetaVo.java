package com.ntels.nidp.mvc.comp.hive.domain;

public class AnalyzermetaVo {

	private int analyzeseq;
	private String modname;
	private String classpath;
	private int dataid;
	private int dataifid;
	private int indexid;
	private int useyn;
	private int createid;
	private String createdt;
	private int moduleid;
	private String anlmodtype;
	
	public int getAnalyzeseq() {
		return analyzeseq;
	}
	public void setAnalyzeseq(int analyzeseq) {
		this.analyzeseq = analyzeseq;
	}
	public String getModname() {
		return modname;
	}
	public void setModname(String modname) {
		this.modname = modname;
	}
	public String getClasspath() {
		return classpath;
	}
	public void setClasspath(String classpath) {
		this.classpath = classpath;
	}
	public int getDataid() {
		return dataid;
	}
	public void setDataid(int dataid) {
		this.dataid = dataid;
	}
	public int getDataifid() {
		return dataifid;
	}
	public void setDataifid(int dataifid) {
		this.dataifid = dataifid;
	}
	public int getIndexid() {
		return indexid;
	}
	public void setIndexid(int indexid) {
		this.indexid = indexid;
	}
	public int getUseyn() {
		return useyn;
	}
	public void setUseyn(int useyn) {
		this.useyn = useyn;
	}
	public int getCreateid() {
		return createid;
	}
	public void setCreateid(int createid) {
		this.createid = createid;
	}
	public String getCreatedt() {
		return createdt;
	}
	public void setCreatedt(String createdt) {
		this.createdt = createdt;
	}
	public int getModuleid() {
		return moduleid;
	}
	public void setModuleid(int moduleid) {
		this.moduleid = moduleid;
	}
	public String getAnlmodtype() {
		return anlmodtype;
	}
	public void setAnlmodtype(String anlmodtype) {
		this.anlmodtype = anlmodtype;
	}
	@Override
	public String toString() {
		return "Analyzermeta [analyzeseq=" + analyzeseq + ", modname="
				+ modname + ", classpath=" + classpath + ", dataid=" + dataid
				+ ", dataifid=" + dataifid + ", indexid=" + indexid
				+ ", useyn=" + useyn + ", createid=" + createid + ", createdt="
				+ createdt + ", moduleid=" + moduleid + ", anlmodtype="
				+ anlmodtype + "]";
	}
}
