package com.ntels.nidp.mvc.comp.hive.dao;

import java.util.List;

import com.ntels.nidp.mvc.comp.hive.domain.JobexehisVo;

public interface JobexehisDao {

	public List<JobexehisVo> getListAll();
	public JobexehisVo getById(JobexehisVo jobexehisVo);
	public int insert(JobexehisVo jobexehisVo);
	public int update(JobexehisVo jobexehisVo);
}
