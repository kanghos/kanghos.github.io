package com.ntels.nidp.mvc.comp.hive.domain;

/**
 * @author in-3
 *
 */
public class HiveqlVo {

	private int hivemoduleid;
	private String modulenm;
	private String script;
	private String qltype;
	private int createid;
	private String createdt;
	private int useyn = 0;
	private int dataid = 0;
	private int analyzeseq;
	
	public int getHivemoduleid() {
		return hivemoduleid;
	}
	public void setHivemoduleid(int hivemoduleid) {
		this.hivemoduleid = hivemoduleid;
	}
	public String getModulenm() {
		return modulenm;
	}
	public void setModulenm(String modulenm) {
		this.modulenm = modulenm;
	}
	public String getScript() {
		return script;
	}
	public void setScript(String script) {
		this.script = script;
	}
	public String getQltype() {
		return qltype;
	}
	public void setQltype(String qltype) {
		this.qltype = qltype;
	}
	public int getCreateid() {
		return createid;
	}
	public void setCreateid(int createid) {
		this.createid = createid;
	}
	public String getCreatedt() {
		return createdt;
	}
	public void setCreatedt(String createdt) {
		this.createdt = createdt;
	}
	public int getUseyn() {
		return useyn;
	}
	public void setUseyn(int useyn) {
		this.useyn = useyn;
	}
	public int getDataid() {
		return dataid;
	}
	public void setDataid(int dataid) {
		this.dataid = dataid;
	}
	public int getAnalyzeseq() {
		return analyzeseq;
	}
	public void setAnalyzeseq(int analyzeseq) {
		this.analyzeseq = analyzeseq;
	}
	@Override
	public String toString() {
		return "HiveQL [hivemoduleid=" + hivemoduleid + ", modulenm="
				+ modulenm + ", script=" + script + ", qltype=" + qltype
				+ ", createid=" + createid + ", createdt=" + createdt
				+ ", useyn=" + useyn + ", dataid=" + dataid + ", analyzeseq="
				+ analyzeseq + "]";
	}
}
