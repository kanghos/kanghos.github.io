package com.ntels.nidp.mvc.comp.agent.controller;

import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ntels.nidp.mvc.comp.agent.dao.AgentDaoImpl;
import com.ntels.nidp.mvc.comp.agent.domain.AgentVo;

@Controller
public class AgentController {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired(required = false)
	private AgentDaoImpl agentDaoImpl;
	
	// 입력,수정,조회 페이지를 호출할때...
	@RequestMapping(value = "/agent/{pageName}", method = RequestMethod.GET)
	public String loadAgentPage(
			@PathVariable(value = "pageName") String pageName,
			@RequestParam(value = "agentId", required = false) String agentId,
			Locale locale, Model model) {
		logger.debug("loadAgentPage() path : " + pageName);
		logger.debug("loadAgentPage() param : " + agentId);
		
		String url = "/agent/" + pageName;
		
		try {
			switch(pageName) {
			case "regi": 
				AgentVo agentVo = new AgentVo();
				model.addAttribute("agentInfo", agentVo);
				break;
			case "edit":
				
			case "detail":	
				AgentVo paramInfo = new AgentVo();
				paramInfo.setAgentId(Integer.parseInt(agentId));
				
				agentVo = agentDaoImpl.selectAgentbyId(paramInfo);
				logger.debug("selectAgentbyId() return : " + agentVo);
				model.addAttribute("agentInfo", agentVo);
				break;
			case "list":
				List<AgentVo> agentList = agentDaoImpl.selectAgentAll();
				logger.debug("selectAgentAll() return : " + agentList);
				model.addAttribute("agentList", agentList);
				break;
			default:
				url = "/agent";
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return url;
	}

	// 입력,수정,삭제 데이터를 처리할때...
	@RequestMapping(value = "/agent/{procName}", method = RequestMethod.POST)
	public String procAgentData(
			@PathVariable(value = "procName") String procName,
			@ModelAttribute(value = "agentInfo") AgentVo agentVo, 
			Locale locale, Model model) {
		logger.debug("procAgentData() path : " + procName);
		logger.debug("procAgentData() params : " + agentVo);
		
		String url = "redirect:/agent/list";

		try {
			int result = 0;
			
			switch(procName) {
			case "insert": 
				result = agentDaoImpl.insertAgent(agentVo);
				logger.debug("insertAgent() return : " + result);
				break;
			case "update":
				result = agentDaoImpl.updateAgent(agentVo);
				logger.debug("updateAgent() return : " + result);
				break;
			case "delete":
				result = agentDaoImpl.deleteAgent(agentVo);
				logger.debug("deleteAgent() return : " + result);
				break;
			default:
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return url;
	}

	/*
	@RequestMapping(value = "/insert", method = RequestMethod.POST)
	public String insert(Locale locale, Model model,@ModelAttribute AgentInfo agentInfo) {
		try {
			int result = agentDaoImpl.insertAgent(agentInfo);
			System.out.println("result" + result);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return "/agent/list";
	}

	@RequestMapping(value="/update" , method=RequestMethod.POST) 
	public String update(Locale locale, Model model, @ModelAttribute AgentInfo agentInfo) {
		try {
			int result = agentDaoImpl.updateAgent(agentInfo);
			System.out.println("result" + result);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "/agent/list";
	}
	
	@RequestMapping(value="/delete", method=RequestMethod.POST) 
	public String delete(Locale locale, Model model, @ModelAttribute AgentInfo agentInfo) {
		try {
			int result = agentDaoImpl.deleteAgent(agentInfo);
			System.out.println("result" + result);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "/agent/list";
	}
	
	@RequestMapping(value="/select" , method=RequestMethod.GET)
	public String selectAll(Locale locale, Model model) {
		try{
			List<AgentInfo> agentList = agentDaoImpl.selectAgentAll();
			System.out.println("agentList" + agentList);
			
			Gson gson = new Gson();
			String outStr = gson.toJson(agentList);

			model.addAttribute("agentList" , outStr);
			System.out.println("agentList" + outStr);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return "/agent/list";
	}
	*/
}
