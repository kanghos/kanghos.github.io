package com.ntels.nidp.mvc.comp.collect.service;

import java.util.List;

import com.ntels.nidp.mvc.comp.collect.domain.CollectVo;

public interface CollectService {

	public int insert(CollectVo collectInfo);
	public CollectVo getInfoById(CollectVo collectInfo);
	public List<CollectVo> selectCollectAll();
	public int updateCollectDataName(CollectVo collectInfo);
	
	/**
	 * hive ql 을 이용하여 table을 삭제하고,
	 * T_NIDP_COLLECTDATA_INFO, T_FILEMASTER, T_ANALYZERMETA, T_HIVEQL 테이블에서 dataid로 모두 삭제.
	 * @param collectVo
	 * @return
	 */
	public int deleteCollect(CollectVo collectVo);
}
