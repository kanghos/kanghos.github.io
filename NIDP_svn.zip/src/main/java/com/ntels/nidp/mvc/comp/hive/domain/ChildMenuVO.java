package com.ntels.nidp.mvc.comp.hive.domain;

public class ChildMenuVO {

	String chmenu;

	public String getChmenu() {
		return chmenu;
	}

	public void setChmenu(String chmenu) {
		this.chmenu = chmenu;
	}

	@Override
	public String toString() {
		return "ChildMenuVO [chmenu=" + chmenu + "]";
	}
}
