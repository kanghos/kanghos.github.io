package com.ntels.nidp.mvc.comp.agent.domain;

public class AgentVo {

	private int agentId;
	private String agentName;
	private String agentType;
	private String ipAddr;
	private int port;
	private String authKey;
	private String suspendYn;
	private String statusYn;
	private int retCode;
	private String createId;
	private String createDt;
	private String updateId;
	private String updateDt;
	public int getAgentId() {
		return agentId;
	}
	public void setAgentId(int agentId) {
		this.agentId = agentId;
	}
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public String getAgentType() {
		return agentType;
	}
	public void setAgentType(String agentType) {
		this.agentType = agentType;
	}
	public String getIpAddr() {
		return ipAddr;
	}
	public void setIpAddr(String ipAddr) {
		this.ipAddr = ipAddr;
	}
	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		this.port = port;
	}
	public String getAuthKey() {
		return authKey;
	}
	public void setAuthKey(String authKey) {
		this.authKey = authKey;
	}
	public String getSuspendYn() {
		return suspendYn;
	}
	public void setSuspendYn(String suspendYn) {
		this.suspendYn = suspendYn;
	}
	public String getStatusYn() {
		return statusYn;
	}
	public void setStatusYn(String statusYn) {
		this.statusYn = statusYn;
	}
	public int getRetCode() {
		return retCode;
	}
	public void setRetCode(int retCode) {
		this.retCode = retCode;
	}
	public String getCreateId() {
		return createId;
	}
	public void setCreateId(String createId) {
		this.createId = createId;
	}
	public String getCreateDt() {
		return createDt;
	}
	public void setCreateDt(String createDt) {
		this.createDt = createDt;
	}
	public String getUpdateId() {
		return updateId;
	}
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}
	public String getUpdateDt() {
		return updateDt;
	}
	public void setUpdateDt(String updateDt) {
		this.updateDt = updateDt;
	}
	@Override
	public String toString() {
		return "AgentInfo [agentId=" + agentId + ", agentName=" + agentName
				+ ", agentType=" + agentType + ", ipAddr=" + ipAddr + ", port="
				+ port + ", authKey=" + authKey + ", suspendYn=" + suspendYn
				+ ", statusYn=" + statusYn + ", retCode=" + retCode
				+ ", createId=" + createId + ", createDt=" + createDt
				+ ", updateId=" + updateId + ", updateDt=" + updateDt + "]";
	}
	
}
