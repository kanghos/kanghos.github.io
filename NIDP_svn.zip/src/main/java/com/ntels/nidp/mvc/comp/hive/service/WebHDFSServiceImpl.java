package com.ntels.nidp.mvc.comp.hive.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONObject;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.params.ClientPNames;
import org.apache.http.conn.HttpHostConnectException;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.ntels.nidp.mvc.comp.hive.domain.FileStatus;
import com.ntels.nidp.mvc.comp.hive.domain.FileStatuses;

@Service
public class WebHDFSServiceImpl {

	@Autowired HiveServiceImpl hiveServiceImpl;
	
	static final String URL_PRE="http://218.239.45.37:50070/webhdfs/v1/";
	static final String URL_SUB="?op=LISTSTATUS";
	private final String NODE_NAME_1_IP="218.239.45.37"; 
	private final String NODE_NAME_2_IP="218.239.45.36"; 
	private final String NODE_NAME_1="nidpdata1";
	private final String NODE_NAME_2="nidpdata2"; 
	
	public ModelAndView downFile(String url){
		String getUrl = getRedirectUrl(url);
		String redirectUrl = replaceNodeNameToIP(getUrl);
		String outputFilePath = getOutputFilePath(getUrl);
		
		Map<String, Object> result = createFile(redirectUrl, outputFilePath);
		System.out.println("*** reuslt="+result.get("success")+"_ msg="+result.get("msg"));
		int count = 0;
		if((boolean)result.get("success")){
			File dnFile = new File(outputFilePath);
			return new ModelAndView("downloadView", "downloadFile", dnFile);
		}else {
			if("org.apache.http.conn.HttpHostConnectException".equals(result.get("msg")) && count < 1){
				File dnFile = new File(outputFilePath);
				count = count + 1;
				return new ModelAndView("downloadView", "downloadFile", dnFile);
			}else{
				return new ModelAndView("/hive/webhdfs", "error", "다운로드에 실패했습니다.");
			}
		}
	}

	private String getOutputFilePath(String getUrl) {
		String[] temp = getUrl.split("\\?")[0].split("/");
		String fileName = temp[temp.length-1];
		String filePath = hiveServiceImpl.getOutputFolderPath()+fileName;
		System.out.println("***filePath="+filePath);
		return filePath;
	}

	private String replaceNodeNameToIP(String getUrl) {
		String nodeName = getUrl.substring(7).toString().split(":")[0].toString();
		System.out.println("***nodeName="+nodeName);
		String reMakeUrl = null;
		if(NODE_NAME_1.equals(nodeName)){
			reMakeUrl = getUrl.replace(NODE_NAME_1, NODE_NAME_1_IP);
		}else if(NODE_NAME_2.equals(nodeName)){
			reMakeUrl = getUrl.replace(NODE_NAME_2, NODE_NAME_2_IP);
		}
		System.out.println("***reMakeUrl="+reMakeUrl);
		return reMakeUrl;
	}
	
	/**
	 * @param url : request url to open and read a file
	 * @param outputFilePath : fullpath : output folder and file path
	 * @return Map&lt;String, Object> - key:success (value : boolean / true is success. false is fail ) 
	 * , key:msg (value:string) 
	 */
	private Map<String, Object> createFile(String url, String outputFilePath){
		Map<String, Object> map = new HashMap<String, Object>();
		
		HttpClient httpclient = new DefaultHttpClient();
		try {
			// HttpGet생성
			HttpGet httpget = new HttpGet(url);
			HttpResponse response = httpclient.execute(httpget);
			HttpEntity entity = response.getEntity();
			
			//System.out.println("----------------------------------------");
			// 응답 결과
			if (entity != null) {
				//System.out.println("Response content length: "+ entity.getContentLength());
				BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
 
				FileWriter fileWriter = new FileWriter(outputFilePath);
				String line = "";
				while ((line = rd.readLine()) != null) {
					String lines = line+"\n";
					fileWriter.write(lines);
				}
				fileWriter.close();
				rd.close();
			}
			httpget.abort();
			//System.out.println("----------------------------------------");
			httpclient.getConnectionManager().shutdown();
 
			map.put("success", true);
			map.put("msg", "success");
			
		}catch (HttpHostConnectException e){
			map.put("success", false);
			map.put("msg", e.getClass().getName());
		}catch (ClientProtocolException e) {
			map.put("success", false);
			map.put("msg", e.getClass().getName());
			e.printStackTrace();
		} catch (IOException e) {
			map.put("success", false);
			map.put("msg", e.getClass().getName());
			e.printStackTrace();
		} finally {
			httpclient.getConnectionManager().shutdown();
		}
		return map;
	}
	
	private String getRedirectUrl(String url){
		HttpClient httpclient = new DefaultHttpClient();
		// HTTP parameters stores header etc.
		HttpParams params = new BasicHttpParams();
		params.setParameter(ClientPNames.HANDLE_REDIRECTS, Boolean.FALSE);
		//HttpGet생성
		HttpGet httpget = new HttpGet(url);
		httpget.setParams(params);
		String redirectLocation = null;
		
		try {
			HttpResponse response = httpclient.execute(httpget);
			org.apache.http.Header locationHeader = response.getFirstHeader("location");
			if (response.getStatusLine().getStatusCode() == 307 && locationHeader != null) {
			    redirectLocation = locationHeader.getValue();
			    System.out.println("loaction: " + redirectLocation);
			}
			httpget.abort();
			httpclient.getConnectionManager().shutdown();
		}catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return redirectLocation;
	}
	
	public FileStatuses getTree(){
		String urldept ="";
		String url =URL_PRE+URL_SUB;
		
		String json = getHttp(url);
		JSONObject jsonObject = JSONObject.fromObject( json ).getJSONObject("FileStatuses");
		FileStatuses fileStatuses = new FileStatuses();
		fileStatuses.setChildren((List<FileStatus>) jsonObject.get("FileStatus"));
		fileStatuses.setText(".");
		
		int dept1=fileStatuses.getChildren().size();
		for (int i = 0; i < dept1; i++) {
			urldept ="";
			JSONObject firstChild = JSONObject.fromObject(fileStatuses.getChildren().get(i));
			FileStatus firstObj = (FileStatus) JSONObject.toBean(firstChild, FileStatus.class);
			
			urldept +=firstObj.getPathSuffix();
			String json1 = getHttp(URL_PRE+urldept+URL_SUB);
			
			JSONObject jsonObject1 = JSONObject.fromObject( json1 ).getJSONObject("FileStatuses");
			firstObj.setChildren((List<FileStatus>) jsonObject1.get("FileStatus"));

			setLeafAndPath(firstObj, URL_PRE+urldept);
			
			fileStatuses.getChildren().set(i, firstObj);
			
			int dept2=firstObj.getChildren().size();
			for (int j = 0; j < dept2; j++) {
				String urldept2 = urldept;
				
				JSONObject secondChild = JSONObject.fromObject(firstObj.getChildren().get(j));
				//System.out.println("** ele2="+secondChild);
				FileStatus secondObj = (FileStatus) JSONObject.toBean(secondChild, FileStatus.class);
				urldept2 +="/"+secondObj.getPathSuffix();
				String json2 = getHttp(URL_PRE+urldept2+URL_SUB);
				JSONObject jsonObject2 = JSONObject.fromObject( json2 ).getJSONObject("FileStatuses");
				secondObj.setChildren((List<FileStatus>) jsonObject2.get("FileStatus"));
				
				setLeafAndPath(secondObj, URL_PRE+urldept2);
				
				firstObj.getChildren().set(j, secondObj);
				fileStatuses.getChildren().set(i, firstObj);
				
				int dept3=secondObj.getChildren().size();
				for (int k = 0; k < dept3; k++) {
					String urldept3 = urldept2;
					JSONObject thirdChild = JSONObject.fromObject(secondObj.getChildren().get(k));
					//System.out.println("** ele3="+ele3);
					FileStatus thirdObj = (FileStatus) JSONObject.toBean(thirdChild, FileStatus.class);
					
					urldept3 +="/"+thirdObj.getPathSuffix();
					if(urldept3.contains("WIUX")) {
						break;
					}else if(urldept3.contains("twitter")){
						break;
					}else if(urldept3.contains("weather")){
						break;
					}
					
					String json3 = getHttp(URL_PRE+urldept3+URL_SUB);
					JSONObject jsonObject3 = JSONObject.fromObject( json3 ).getJSONObject("FileStatuses");
					thirdObj.setChildren((List<FileStatus>) jsonObject3.get("FileStatus"));
					
					setLeafAndPath(thirdObj, URL_PRE+urldept3);
					
					secondObj.getChildren().set(k, thirdObj);
					firstObj.getChildren().set(j, secondObj);
					fileStatuses.getChildren().set(i, firstObj);
					
					int dept4=thirdObj.getChildren().size();
					for (int l = 0; l < dept4; l++) {
						String urldept4 = urldept3;
						JSONObject fourthChild = JSONObject.fromObject(thirdObj.getChildren().get(l));
						//System.out.println("** ele3="+ele3);
						FileStatus fourthObj = (FileStatus) JSONObject.toBean(fourthChild, FileStatus.class);
						
						urldept4 +="/"+fourthObj.getPathSuffix();
						/*if(urldept4.contains("WIUX")) {
							break;
						}else if(urldept4.contains("twitter")){
							break;
						}else if(urldept4.contains("weather")){
							break;
						}*/
						
						String json4 = getHttp(URL_PRE+urldept4+URL_SUB);
						JSONObject jsonObject4 = JSONObject.fromObject( json4 ).getJSONObject("FileStatuses");
						fourthObj.setChildren((List<FileStatus>) jsonObject4.get("FileStatus"));
						
						setLeafAndPath(fourthObj, URL_PRE+urldept4);
						
						thirdObj.getChildren().set(l, fourthObj);
						secondObj.getChildren().set(k, thirdObj);
						firstObj.getChildren().set(j, secondObj);
						fileStatuses.getChildren().set(i, firstObj);
					}
				}
			}
		}
		//System.out.println(fileStatuses.toString());
		
		return fileStatuses;
	}
	
	/**
	 * When type property is FILE, a leaf property set true and a path property set url  
	 * @param obj FileStatus class
	 * @param url
	 */
	private void setLeafAndPath(FileStatus obj, String url) {
		int thisObjLength = obj.getChildren().size();
		for (int m = 0; m < thisObjLength; m++) {
			JSONObject thisEle = JSONObject.fromObject(obj.getChildren().get(m));
			String type = thisEle.getString("type");
			String fileName = thisEle.getString("pathSuffix");
			
			if("FILE".equals(type)){
				thisEle.accumulate("leaf", true);
				thisEle.accumulate("path", url+"/"+fileName);
			}
			
			FileStatus thisObj = (FileStatus) JSONObject.toBean(thisEle, FileStatus.class);
			obj.getChildren().set(m, thisObj);
		}
	}
	
	private String getHttp(String url){
		HttpClient httpclient = new DefaultHttpClient();
		StringBuffer sb = new StringBuffer();
		try {
			// HttpGet생성
			HttpGet httpget = new HttpGet(url);
 
			httpget.setHeader("Accept", "application/json");
			//httpget.setHeader("Content-Type", "application/json");
			httpget.setHeader("Content-Type", "text/plain; charset=utf-8");
			HttpResponse response = httpclient.execute(httpget);
			HttpEntity entity = response.getEntity();
 
			// 응답 결과
			if (entity != null) {
				//System.out.println("Response content length: "+ entity.getContentLength());
				BufferedReader rd = new BufferedReader(new InputStreamReader(
						response.getEntity().getContent()));
 
				String line = "";
				while ((line = rd.readLine()) != null) {
					sb.append(line);
				}
			}
			httpget.abort();
			httpclient.getConnectionManager().shutdown();
 
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			httpclient.getConnectionManager().shutdown();
		}
		return sb.toString();
	}
}
