package com.ntels.nidp.mvc.comp.hive.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.ntels.nidp.mvc.comp.hive.domain.JobexehisVo;

public class JobexehisDaoImpl implements JobexehisDao{

	private SqlSession sqlSession;
	
	public void setSqlSession(SqlSession sqlSess) {
		this.sqlSession = sqlSess; 
	}
		
	public List<JobexehisVo> getListAll(){
		return  sqlSession.selectList("getJobexehisVoListAll");
	}
	
	public JobexehisVo getById(JobexehisVo jobexehisVo){
		return  sqlSession.selectOne("getJobexehisVoById", jobexehisVo);
	}
	
	public int insert(JobexehisVo jobexehisVo){
		return sqlSession.insert("insertJobexehisVo", jobexehisVo);	
	}
	
	public int update(JobexehisVo jobexehisVo){
		return sqlSession.update("updateJobexehisVo", jobexehisVo);
	}
}
