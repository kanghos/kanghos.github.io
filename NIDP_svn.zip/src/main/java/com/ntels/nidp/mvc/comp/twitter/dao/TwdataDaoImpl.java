/**
 * 
 */
package com.ntels.nidp.mvc.comp.twitter.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.ntels.nidp.mvc.comp.twitter.domain.HitSecVo;
import com.ntels.nidp.mvc.comp.twitter.domain.WordTrendVo;
import com.ntels.nidp.mvc.comp.twitter.domain.WordUrlVo;


/**
 * @author hskang
 *
 */
public class TwdataDaoImpl implements TwdataDao {

	
	private SqlSession sqlSession;
	
	public void setSqlSession(SqlSession sqlSess) {
		this.sqlSession = sqlSess; 
	}

	//@Override
	/*public List<UserInfo> selectAllUser() {
		//@SuppressWarnings("unckecked");
		List<UserInfo> userList = sqlSession.selectList("selectAllUserList");
		// TODO Auto-generated method stub
		return userList;
	}*/
	
	public List<WordTrendVo> selectAllWordList() {
		//@SuppressWarnings("unckecked");
		List<WordTrendVo> wordList = sqlSession.selectList("selectAllWordList");
		// TODO Auto-generated method stub
		return wordList;
	}
	
	public List<WordTrendVo> select5minWordList(String startTime) {
		//@SuppressWarnings("unckecked");
		List<WordTrendVo> wordList = sqlSession.selectList("select5MinWordList", startTime );
		// TODO Auto-generated method stub
		return wordList;
	}
	
	public List<WordUrlVo> select5minUrlList(String startTime) {
		//@SuppressWarnings("unckecked");
		List<WordUrlVo> urlList = sqlSession.selectList("select5MinUrlList", startTime );
		// TODO Auto-generated method stub
		return urlList;
	}
	
	public List<HitSecVo> select30SecHitList(HitSecVo dateTime) {
		List<HitSecVo> hitList = sqlSession.selectList("select30SecHitList", dateTime);
		return hitList;
	}
}
