package com.ntels.nidp.mvc.comp.collect.dao;

import java.util.List;

import com.ntels.nidp.mvc.comp.collect.domain.CollectVo;

public interface CollectDao {

	public int insertCollect(CollectVo collectVo);
	
	public int updateCollect(CollectVo collectVo);
	
	public int deleteCollect(CollectVo collectVo);
	
	public List<CollectVo> selectCollectAll();
	
	public CollectVo selectCollectbyId(CollectVo collectVo);
	
	public int countByDataUrl(String dataUrl);

	public CollectVo selectByDataUrl(String dataUrl);

	public int updateCollectDataName(CollectVo collectVo);
}
