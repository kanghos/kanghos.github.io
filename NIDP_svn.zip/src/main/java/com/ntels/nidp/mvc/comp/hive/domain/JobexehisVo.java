package com.ntels.nidp.mvc.comp.hive.domain;

public class JobexehisVo {

	private int seq;
	private String statuscd;
	private String startdt;
	private String enddt;
	private String elementcd;
	private int modtype;
	private int termtype;
	private int moduleid;
	private String inputfile;
	private String outputpath;
	private String outputfilenm;
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public String getStatuscd() {
		return statuscd;
	}
	public void setStatuscd(String statuscd) {
		this.statuscd = statuscd;
	}
	public String getStartdt() {
		return startdt;
	}
	public void setStartdt(String startdt) {
		this.startdt = startdt;
	}
	public String getEnddt() {
		return enddt;
	}
	public void setEnddt(String enddt) {
		this.enddt = enddt;
	}
	public String getElementcd() {
		return elementcd;
	}
	public void setElementcd(String elementcd) {
		this.elementcd = elementcd;
	}
	public int getModtype() {
		return modtype;
	}
	public void setModtype(int modtype) {
		this.modtype = modtype;
	}
	public int getTermtype() {
		return termtype;
	}
	public void setTermtype(int termtype) {
		this.termtype = termtype;
	}
	public int getModuleid() {
		return moduleid;
	}
	public void setModuleid(int moduleid) {
		this.moduleid = moduleid;
	}
	public String getInputfile() {
		return inputfile;
	}
	public void setInputfile(String inputfile) {
		this.inputfile = inputfile;
	}
	public String getOutputpath() {
		return outputpath;
	}
	public void setOutputpath(String outputpath) {
		this.outputpath = outputpath;
	}
	public String getOutputfilenm() {
		return outputfilenm;
	}
	public void setOutputfilenm(String outputfilenm) {
		this.outputfilenm = outputfilenm;
	}
	@Override
	public String toString() {
		return "JobexehisVo [seq=" + seq + ", statuscd=" + statuscd
				+ ", startdt=" + startdt + ", enddt=" + enddt + ", elementcd="
				+ elementcd + ", modtype=" + modtype + ", termtype=" + termtype
				+ ", moduleid=" + moduleid + ", inputfile=" + inputfile
				+ ", outputpath=" + outputpath + ", outputfilenm="
				+ outputfilenm + "]";
	}
}
