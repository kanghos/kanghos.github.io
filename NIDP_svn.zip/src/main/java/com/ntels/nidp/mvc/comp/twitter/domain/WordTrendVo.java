package com.ntels.nidp.mvc.comp.twitter.domain;

/**
 * @author hskang
 *
 */
public class WordTrendVo {

	private String word;
	private int cnts;
	private int wType;
	private String dateTimes;
	private int rowSeq;
	
	
	/**
	 * @return the rowSeq
	 */
	public int getRowSeq() {
		return rowSeq;
	}
	/**
	 * @param rowSeq the rowSeq to set
	 */
	public void setRowSeq(int rowSeq) {
		this.rowSeq = rowSeq;
	}
	/**
	 * @return the word
	 */
	public String getWord() {
		return word;
	}
	/**
	 * @param word the word to set
	 */
	public void setWord(String word) {
		this.word = word;
	}
	
	/**
	 * @return the cnts
	 */
	public int getCnts() {
		return cnts;
	}
	/**
	 * @param cnts the cnts to set
	 */
	public void setCnts(int cnts) {
		this.cnts = cnts;
	}
	/**
	 * @return the wType
	 */
	public int getwType() {
		return wType;
	}
	/**
	 * @param wType the wType to set
	 */
	public void setwType(int wType) {
		this.wType = wType;
	}
	/**
	 * @return the wordType
	 */
	public int getWType() {
		return wType;
	}
	/**
	 * @param wordType the wordType to set
	 */
	public void setWType(int wordType) {
		this.wType = wType;
	}
	/**
	 * @return the dateTimes
	 */
	public String getDateTimes() {
		return dateTimes;
	}
	/**
	 * @param dateTimes the dateTimes to set
	 */
	public void setDateTimes(String dateTimes) {
		this.dateTimes = dateTimes;
	}
	
	
	
}
