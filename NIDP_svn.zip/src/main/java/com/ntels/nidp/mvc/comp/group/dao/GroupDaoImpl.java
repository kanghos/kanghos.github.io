package com.ntels.nidp.mvc.comp.group.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.ntels.nidp.mvc.comp.group.domain.GroupVo;

public class GroupDaoImpl implements GroupDao {

private SqlSession sqlSession;
	
	public void setSqlSession(SqlSession sqlSess) {
		this.sqlSession = sqlSess; 
	}
	
	public int insertGroup(GroupVo groupVo) {
		return sqlSession.insert("insertGroup", groupVo);
	}

	public int updateGroup(GroupVo groupVo) {
		return sqlSession.update("updateGroup", groupVo);
	}
	
	public int deleteGroup(GroupVo groupVo) {
		return sqlSession.delete("deleteGroup", groupVo);
	}
	
	public List<GroupVo> selectGroupAll() {
		return sqlSession.selectList("selectGroupAll");
	}
	
	public GroupVo selectGroupbyNo(GroupVo groupVo) {
		return sqlSession.selectOne("selectGroupbyNo", groupVo);
	}
	
	public List<GroupVo> selectGroupbyInput(GroupVo groupVo) {
		return sqlSession.selectList("selectGroupbyInput", groupVo);
	}
	
	public int selectTotalCount() {
		return sqlSession.selectOne("selectTotalCount");
	}
	
}
