package com.ntels.nidp.mvc.comp.twitter.controller;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Vector;






import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.ntels.nidp.common.thread.action.Work;
import com.ntels.nidp.common.utils.DateUtils;
import com.ntels.nidp.common.utils.MathUtils;
import com.ntels.nidp.common.utils.StringUtil;
import com.ntels.nidp.mvc.comp.twitter.dao.TwdataDaoImpl;
import com.ntels.nidp.mvc.comp.twitter.domain.HitSecVo;
import com.ntels.nidp.mvc.comp.twitter.domain.WordTrendVo;
import com.ntels.nidp.mvc.comp.twitter.domain.WordUrlVo;



@Controller
public class TwdataController {

	//@Autowired
	@Autowired(required = false)
	private TwdataDaoImpl twdataDaoImpl;
	
	@RequestMapping(value="/test", method=RequestMethod.GET)
	public String twtTest(Locale locale, Model model) {
		try{
		/*//List<UserInfo> userList = userDaoImpl.selectAllUser();
		
		Gson gson = new Gson();
		String outStr = gson.toJson(userList);
		model.addAttribute("data", outStr);
		System.out.println("Test!@");
		*/
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return "test/testData";
	}
	
	@RequestMapping(value="/twtWord", method=RequestMethod.GET)
	public String twtWordCloud(Locale locale, Model model) {
		try{
		/*//List<UserInfo> userList = userDaoImpl.selectAllUser();
		
		Gson gson = new Gson();
		String outStr = gson.toJson(userList);
		model.addAttribute("data", outStr);
		System.out.println("Test!@");
		*/
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return "twtWord";
	}
	
	@RequestMapping(value="/twtCloud", method=RequestMethod.GET)
	public String twtAwsWordCloud(Locale locale, Model model) {
		try{
			List<WordTrendVo> wordList = twdataDaoImpl.select5minWordList("");
			String tmpStr = "";//<span data-weight=\"200\">대장</span><span data-weight=\"27\">똥싸</span><span data-weight=\"38\">puru</span><span data-weight=\"43\">risu</span><span data-weight=\"20\">ultrici</span>";
			
			int maxCnt = wordList.get(0).getCnts();
			System.out.println("max:" + maxCnt);
			double thisRate = 0;
			int cnt = 0;
			for(WordTrendVo wordVo : wordList) {
			 	thisRate = (double)(wordVo.getCnts() / (double)maxCnt) * 170;
			 	//System.out.println("rate:" + thisRate );
			 	/*if(cnt == 0) {
			 		tmpStr += "<a href=\"www.naver.com\"><span data-weight=\""+MathUtils.round(thisRate,2)+"\">"+wordVo.getWord()+"</span></a>";
			 	} else */
			 		tmpStr += "<span data-weight=\""+MathUtils.round(thisRate,2)+"\">"+wordVo.getWord()+"</span>";
			 	cnt++;
			}
			
			Gson gson = new Gson();
			String outStr = gson.toJson(wordList);
			model.addAttribute("data", tmpStr);
			System.out.println("Test!@");

		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return "wordcloud/twtcloud";
	}
	
	
	@RequestMapping(value="/service/dashboard", method=RequestMethod.GET)
	public String makeTwtWordCloud(Locale locale, Model model) {
		try{
			String currDateTime = DateUtils.getCurrentTime("yyyyMMddHHmm");
			List<WordTrendVo> wordList = twdataDaoImpl.select5minWordList(currDateTime);
			List<WordUrlVo> urlList = twdataDaoImpl.select5minUrlList(currDateTime);
			String tmpStr = "";//<span data-weight=\"200\">대장</span><span data-weight=\"27\">똥싸</span><span data-weight=\"38\">puru</span><span data-weight=\"43\">risu</span><span data-weight=\"20\">ultrici</span>";
			String urlWordList = "";
			HashMap wordUrlMap = new HashMap();
			HashMap urlMap = new HashMap();
			
			//String[] urlRankList = new String[10]; 
			HashMap<Integer,String> urlRankList = new HashMap<Integer,String>();
			HashMap<Integer,String> cntRankList = new HashMap<Integer,String>();
			Vector<String>  urlStrList = new Vector<String>();
			
			if(wordList.size() == 0) {
				tmpStr += "<span data-weight=\"100\">None</span>";
			} else {
				int maxCnt = wordList.get(0).getCnts();
				System.out.println("max:" + maxCnt);
				String tmpStr2="",tmpUrlStr="";
				
				double thisRate = 0;
				int cnt = 0, idx = 1;
				for(WordUrlVo urlVo : urlList) { 
					wordUrlMap.put(urlVo.getWord(), urlVo.getUrls());
				}
				
				for(WordTrendVo wordVo : wordList) {
				 	thisRate = (double)(wordVo.getCnts() / (double)maxCnt) * 120;		//가중치
				 	//System.out.println("rate:" + thisRate );
				 	/*if(cnt == 0) {
				 		tmpStr += "<a href=\"www.naver.com\"><span data-weight=\""+MathUtils.round(thisRate,2)+"\">"+wordVo.getWord()+"</span></a>";
				 	} else */
				 	if(cnt < 80) {
				 		tmpUrlStr = ""; tmpStr2="";
				 		urlStrList = new Vector<String>();
				 		if(wordUrlMap.containsKey(wordVo.getWord())) {
				 		//	if()
				 			tmpUrlStr = (String) wordUrlMap.get(wordVo.getWord());
				 			if(urlMap.containsKey(tmpUrlStr)) {
				 				urlStrList = (Vector<String>) urlMap.get(tmpUrlStr);
				 				//tmpStr2 = (String) urlMap.get(tmpUrlStr);
				 				//urlRankList.add(tmpStr2);
				 				//tmpStr2 = (String) urlMap.get(tmpUrlStr);
				 				urlStrList.add(wordVo.getWord());
				 				//tmpStr2 += ","+wordVo.getWord();
				 			} else {
				 				//if(cnt > 0) {
				 					urlRankList.put(idx, tmpUrlStr);
				 					//cntRankList.put(idx, tmpUrlStr);
				 					System.out.println("urlRankList idx:"+idx+"\turlMap:"+tmpUrlStr);
				 					idx++;
				 				/*} else 
				 				{
					 				urlRankList.put(idx, urlMap);
					 				System.out.println("urlRankList idx:"+idx+"\turlMap:"+tmpUrlStr);
					 				idx++;
					 			}*/
				 				tmpStr2 = wordVo.getWord();
				 				urlStrList.add(tmpStr2);
				 			}
				 			
				 			//tmpStr2 = urlMap.get(key) + wordVo.getWord();
				 			urlMap.put(tmpUrlStr, urlStrList);
				 			
				 			System.out.println("tmpUrlStr:"+tmpUrlStr+"\turlRankList:"+urlStrList);
				 			
				 		} else {
				 			
				 		}
				 	}
				 	tmpStr += "<span data-weight=\""+MathUtils.round(thisRate,2)+"\">"+wordVo.getWord()+"</span>";
				 	cnt++;
				}
				
				
				
				//Gson gson = new Gson();
				//String outStr = gson.toJson(wordList);
			}
			Gson gson = new Gson();
			String urlRankListStr = gson.toJson(urlRankList);
			String outStr = gson.toJson(urlMap);
			
			JSONObject jsonObj = new JSONObject();
			
			
			
			jsonObj.put("ranklist", urlRankListStr);
			jsonObj.put("wordlist", outStr);
			//gson.
			
			model.addAttribute("data", tmpStr);
			//model.addAttribute("ranklist", urlRankListStr);
			model.addAttribute("rankdata", jsonObj);
			System.out.println("urlRankListStr:"+urlRankListStr);
			System.out.println("outStr:"+outStr);
			//System.out.println(urlRankList);
			

		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return "service/twitter/dashboard";
	}
	
	
	@RequestMapping(value="/execAnalyzer", method=RequestMethod.GET)
	public String execAnalyzer(Locale locale, Model model) {
		try{
			
			Map map = new HashMap();	
			//model.addAttribute("data", tmpStr);
		
			String currDateTime = DateUtils.getCurrentTime("yyyyMMddHHmm");
			Calendar cal1 = Calendar.getInstance();
			//cal1.setTime(cal.getTime());
			cal1.add(Calendar.MINUTE, -1); // 현재의 1분전 데이터가 대상
			String tm_1m_ago = StringUtil.getMinFormat(cal1.getTime()); // yyyyMMddHH
			
			/*args[0] = tm_1m_ago;
			args[1] = currDateTime;*/
			map.put("tm_1m_ago",  tm_1m_ago);
			map.put("currDateTime",  currDateTime);
			
			map.put("command",  "TWITTER_BATCH_HANDLER");
			System.out.println("Exec분석!");
			Work.getInstance().makeRequest(map);
			
			return "execAnalyzer";
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return "execAnalyzer";
	}
	
	@RequestMapping(value="/hitGraph", method=RequestMethod.GET)
	public String hitGraph(Locale locale, Model model) {
		try {
			HitSecVo hitSec = new HitSecVo();
			hitSec.setStartTime(DateUtils.getCurrentTime("yyyyMMddHHmmss"));
			hitSec.setLastTime("0");
			
			List<HitSecVo> hitList = twdataDaoImpl.select30SecHitList(hitSec);
			Gson gson = new Gson();
			String outStr = gson.toJson(hitList);
			
			System.out.println("hitList=" + outStr);
			model.addAttribute("hitList", outStr);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "hitGraph"; 
	}

	@RequestMapping(value = "/twtGraph30Sec", method = RequestMethod.GET)
	public @ResponseBody
	List<HitSecVo> twtGraph30Sec(
			@RequestParam(value = "lastTime", required = false) String lastTime,
			Locale locale, Model model) {
		List<HitSecVo> hitList = null;
		try {
			HitSecVo hitSec = new HitSecVo();
			hitSec.setStartTime(DateUtils.getCurrentTime("yyyyMMddHHmmss"));
			hitSec.setLastTime(lastTime);
			
			hitList = twdataDaoImpl.select30SecHitList(hitSec);
			System.out.println("hitList=" + hitList);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return hitList;
	}
	
	
}
