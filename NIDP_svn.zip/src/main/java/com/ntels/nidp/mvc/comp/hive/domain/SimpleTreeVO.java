package com.ntels.nidp.mvc.comp.hive.domain;

import java.util.List;

public class SimpleTreeVO {

	String menu;
	List<ChildMenuVO> childmemu;
	public String getMenu() {
		return menu;
	}
	public void setMenu(String menu) {
		this.menu = menu;
	}
	public List<ChildMenuVO> getChildmemu() {
		return childmemu;
	}
	public void setChildmemu(List<ChildMenuVO> childmemu) {
		this.childmemu = childmemu;
	}
	
	@Override
	public String toString() {
		return "SimpleTreeVO [menu=" + menu + ", childmemu=" + childmemu + "]";
	}
}
