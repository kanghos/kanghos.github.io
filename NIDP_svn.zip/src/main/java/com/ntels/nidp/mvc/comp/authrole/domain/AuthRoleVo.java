package com.ntels.nidp.mvc.comp.authrole.domain;

public class AuthRoleVo {
	private int roleNo;
	private String roleNm;
	private String roleDesc;
	private int useYn;
	private int createUser;
	private String createDt;
	private int updateUser;
	private String updateDt;
	public int getRoleNo() {
		return roleNo;
	}
	public void setRoleNo(int roleNo) {
		this.roleNo = roleNo;
	}
	public String getRoleNm() {
		return roleNm;
	}
	public void setRoleNm(String roleNm) {
		this.roleNm = roleNm;
	}
	public String getRoleDesc() {
		return roleDesc;
	}
	public void setRoleDesc(String roleDesc) {
		this.roleDesc = roleDesc;
	}
	public int getUseYn() {
		return useYn;
	}
	public void setUseYn(int useYn) {
		this.useYn = useYn;
	}
	public int getCreateUser() {
		return createUser;
	}
	public void setCreateUser(int createUser) {
		this.createUser = createUser;
	}
	public String getCreateDt() {
		return createDt;
	}
	public void setCreateDt(String createDt) {
		this.createDt = createDt;
	}
	public int getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(int updateUser) {
		this.updateUser = updateUser;
	}
	public String getUpdateDt() {
		return updateDt;
	}
	public void setUpdateDt(String updateDt) {
		this.updateDt = updateDt;
	}
	@Override
	public String toString() {
		return "AuthRoleVo [roleNo=" + roleNo + ", roleNm=" + roleNm
				+ ", roleDesc=" + roleDesc + ", useYn=" + useYn
				+ ", createUser=" + createUser + ", createDt=" + createDt
				+ ", updateUser=" + updateUser + ", updateDt=" + updateDt + "]";
	} 
	
}
