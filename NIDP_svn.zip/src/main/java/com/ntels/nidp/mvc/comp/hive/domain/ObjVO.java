package com.ntels.nidp.mvc.comp.hive.domain;

public class ObjVO {

	
}
