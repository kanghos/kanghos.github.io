package com.ntels.nidp.mvc.comp.hive.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.ntels.nidp.mvc.comp.hive.domain.FileMasterVo;

public class FileMasterDaoImpl implements FileMasterDao{

	private SqlSession sqlSession;
	
	public void setSqlSession(SqlSession sqlSess) {
		this.sqlSession = sqlSess; 
	}
	
	public List<FileMasterVo> getListById(int dataId) {
		return sqlSession.selectList("getListById", dataId);
	}

	public int insert(FileMasterVo fileMasterVo) {
		return sqlSession.insert("insertFileMaster", fileMasterVo);
	}

	public int deleteFileMasterByDataId(int dataId) {
		return sqlSession.delete("deleteFileMasterByDataId", dataId);
	}

	
}
