package com.ntels.nidp.mvc.comp.collect.domain;

public class CollectVo {
	
	private int dataId;
	private int agentId;
	private String dataCode;
	private String dataName;
	private String dataType;
	private String dataUrl;
	private String dataMimeType;
	private String dataHeader;
	private String dataDelimiter;
	private String lineDelimiter;
	private int itemCnt;
	private int period;
	private int maxSize;
	private String url;
	private String filePath;
	private String cltYn;
	private String cltCycle;
	private String cltDt;
	private String useYn;
	private String hdfsYn;
	private String hdfsCycle;
	private String dbYn;
	private String dbCycle;
	private String svcCycle;
	private String stgCycle;
	private String tpChgYn;
	private String etlYn;
	private String excepYn;
	private String ppsYn;
	private String epYn;
	private String stcanYn;
	private String currentBaseYn;
	private int retCode;
	private String clctDesc;
	private String createId;
	private String createDt;
	private String updateId;
	private String updateDt;
	public int getDataId() {
		return dataId;
	}
	public void setDataId(int dataId) {
		this.dataId = dataId;
	}
	public int getAgentId() {
		return agentId;
	}
	public void setAgentId(int agentId) {
		this.agentId = agentId;
	}
	public String getDataCode() {
		return dataCode;
	}
	public void setDataCode(String dataCode) {
		this.dataCode = dataCode;
	}
	public String getDataName() {
		return dataName;
	}
	public void setDataName(String dataName) {
		this.dataName = dataName;
	}
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public String getDataUrl() {
		return dataUrl;
	}
	public void setDataUrl(String dataUrl) {
		this.dataUrl = dataUrl;
	}
	public String getDataMimeType() {
		return dataMimeType;
	}
	public void setDataMimeType(String dataMimeType) {
		this.dataMimeType = dataMimeType;
	}
	public String getDataHeader() {
		return dataHeader;
	}
	public void setDataHeader(String dataHeader) {
		this.dataHeader = dataHeader;
	}
	public String getDataDelimiter() {
		return dataDelimiter;
	}
	public void setDataDelimiter(String dataDelimiter) {
		this.dataDelimiter = dataDelimiter;
	}
	public String getLineDelimiter() {
		return lineDelimiter;
	}
	public void setLineDelimiter(String lineDelimiter) {
		this.lineDelimiter = lineDelimiter;
	}
	public int getItemCnt() {
		return itemCnt;
	}
	public void setItemCnt(int itemCnt) {
		this.itemCnt = itemCnt;
	}
	public int getPeriod() {
		return period;
	}
	public void setPeriod(int period) {
		this.period = period;
	}
	public int getMaxSize() {
		return maxSize;
	}
	public void setMaxSize(int maxSize) {
		this.maxSize = maxSize;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public String getCltYn() {
		return cltYn;
	}
	public void setCltYn(String cltYn) {
		this.cltYn = cltYn;
	}
	public String getCltCycle() {
		return cltCycle;
	}
	public void setCltCycle(String cltCycle) {
		this.cltCycle = cltCycle;
	}
	public String getCltDt() {
		return cltDt;
	}
	public void setCltDt(String cltDt) {
		this.cltDt = cltDt;
	}
	public String getUseYn() {
		return useYn;
	}
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}
	public String getHdfsYn() {
		return hdfsYn;
	}
	public void setHdfsYn(String hdfsYn) {
		this.hdfsYn = hdfsYn;
	}
	public String getHdfsCycle() {
		return hdfsCycle;
	}
	public void setHdfsCycle(String hdfsCycle) {
		this.hdfsCycle = hdfsCycle;
	}
	public String getDbYn() {
		return dbYn;
	}
	public void setDbYn(String dbYn) {
		this.dbYn = dbYn;
	}
	public String getDbCycle() {
		return dbCycle;
	}
	public void setDbCycle(String dbCycle) {
		this.dbCycle = dbCycle;
	}
	public String getSvcCycle() {
		return svcCycle;
	}
	public void setSvcCycle(String svcCycle) {
		this.svcCycle = svcCycle;
	}
	public String getStgCycle() {
		return stgCycle;
	}
	public void setStgCycle(String stgCycle) {
		this.stgCycle = stgCycle;
	}
	public String getTpChgYn() {
		return tpChgYn;
	}
	public void setTpChgYn(String tpChgYn) {
		this.tpChgYn = tpChgYn;
	}
	public String getEtlYn() {
		return etlYn;
	}
	public void setEtlYn(String etlYn) {
		this.etlYn = etlYn;
	}
	public String getExcepYn() {
		return excepYn;
	}
	public void setExcepYn(String excepYn) {
		this.excepYn = excepYn;
	}
	public String getPpsYn() {
		return ppsYn;
	}
	public void setPpsYn(String ppsYn) {
		this.ppsYn = ppsYn;
	}
	public String getEpYn() {
		return epYn;
	}
	public void setEpYn(String epYn) {
		this.epYn = epYn;
	}
	public String getStcanYn() {
		return stcanYn;
	}
	public void setStcanYn(String stcanYn) {
		this.stcanYn = stcanYn;
	}
	public String getCurrentBaseYn() {
		return currentBaseYn;
	}
	public void setCurrentBaseYn(String currentBaseYn) {
		this.currentBaseYn = currentBaseYn;
	}
	public int getRetCode() {
		return retCode;
	}
	public void setRetCode(int retCode) {
		this.retCode = retCode;
	}
	public String getClctDesc() {
		return clctDesc;
	}
	public void setClctDesc(String clctDesc) {
		this.clctDesc = clctDesc;
	}
	public String getCreateId() {
		return createId;
	}
	public void setCreateId(String createId) {
		this.createId = createId;
	}
	public String getCreateDt() {
		return createDt;
	}
	public void setCreateDt(String createDt) {
		this.createDt = createDt;
	}
	public String getUpdateId() {
		return updateId;
	}
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}
	public String getUpdateDt() {
		return updateDt;
	}
	public void setUpdateDt(String updateDt) {
		this.updateDt = updateDt;
	}
	@Override
	public String toString() {
		return "CollectInfo [dataId=" + dataId + ", agentId=" + agentId
				+ ", dataCode=" + dataCode + ", dataName=" + dataName
				+ ", dataType=" + dataType + ", dataUrl=" + dataUrl
				+ ", dataMimeType=" + dataMimeType + ", dataHeader="
				+ dataHeader + ", dataDelimiter=" + dataDelimiter
				+ ", lineDelimiter=" + lineDelimiter + ", itemCnt=" + itemCnt
				+ ", period=" + period + ", maxSize=" + maxSize + ", url="
				+ url + ", filePath=" + filePath + ", cltYn=" + cltYn
				+ ", cltCycle=" + cltCycle + ", cltDt=" + cltDt + ", useYn="
				+ useYn + ", hdfsYn=" + hdfsYn + ", hdfsCycle=" + hdfsCycle
				+ ", dbYn=" + dbYn + ", dbCycle=" + dbCycle + ", svcCycle="
				+ svcCycle + ", stgCycle=" + stgCycle + ", tpChgYn=" + tpChgYn
				+ ", etlYn=" + etlYn + ", excepYn=" + excepYn + ", ppsYn="
				+ ppsYn + ", epYn=" + epYn + ", stcanYn=" + stcanYn
				+ ", currentBaseYn=" + currentBaseYn + ", retCode=" + retCode
				+ ", clctDesc=" + clctDesc + ", createId=" + createId
				+ ", createDt=" + createDt + ", updateId=" + updateId
				+ ", updateDt=" + updateDt + "]";
	}
	
}
