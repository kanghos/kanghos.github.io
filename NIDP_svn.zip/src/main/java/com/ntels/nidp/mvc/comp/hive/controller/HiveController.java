package com.ntels.nidp.mvc.comp.hive.controller;

import java.io.File;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ntels.nidp.common.config.HdfsPropertyManager;
import com.ntels.nidp.common.log.LogManager;
import com.ntels.nidp.mvc.comp.collect.domain.CollectVo;
import com.ntels.nidp.mvc.comp.hive.domain.AnalyzermetaVo;
import com.ntels.nidp.mvc.comp.hive.domain.FileMasterVo;
import com.ntels.nidp.mvc.comp.hive.domain.FileStatuses;
import com.ntels.nidp.mvc.comp.hive.domain.FileVo;
import com.ntels.nidp.mvc.comp.hive.domain.HiveqlVo;
import com.ntels.nidp.mvc.comp.hive.domain.JobexehisVo;
import com.ntels.nidp.mvc.comp.hive.domain.TableVo;
import com.ntels.nidp.mvc.comp.hive.service.HiveServiceImpl;
import com.ntels.nidp.mvc.comp.hive.service.WebHDFSServiceImpl;

@Controller
public class HiveController {
	private static LogManager log = new LogManager(LogManager.NTELS_NIDP_ANALYZER);

	@Autowired private HiveServiceImpl hiveServiceImpl;
	@Autowired private WebHDFSServiceImpl webHDFSServiceImpl;
	private static final String STATUS_START = "start";
	private static final String STATUS_END = "end";
	private static final String STATUS_FAIL = "failed";
	
	/**
	 * hive 메인 페이지
	 * @param tableVo
	 * @param fileVo
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/hive", method=RequestMethod.GET)
	public String hiveMain(TableVo tableVo, FileVo fileVo, Model model){
		return "hive/hive";
	}

	/**
	 * Hive로 table를 생성하고, T_NIDP_COLLECTDATA_INFO에 저장한다.
	 * @param tableVo
	 * @return
	 */
	@RequestMapping(value="/hive", method=RequestMethod.POST)
	public String createTable(TableVo tableVo, Model model, BindingResult errorResult){
		log.debug("tableVo : "+tableVo.toString());
		
		if(tableVo.getTableName() == "" || tableVo.getColumns() == ""){
			model.addAttribute("error", "테이블 이름, 컬럼을 입력하세요");
		} else{
			//테이블 생성
			boolean isCreateTable = hiveServiceImpl.createTable(tableVo);
			if(isCreateTable){
				//메타 정보 인서트
				CollectVo cInfo = hiveServiceImpl.insertCollectData(tableVo);
				
				//메타 정보 get data
				CollectVo result = hiveServiceImpl.getCollectInfoById(cInfo);
				model.addAttribute("mInfo", result);
			}else {
				model.addAttribute("error", "테이블 생성에 실패했습니다. 입력값을 확인하세요");
			}
		}
		
		return "hive/hive";
	}
	
	@RequestMapping(value="/hive/table/edit", method=RequestMethod.GET)
	public String editViewForTable(@RequestParam String name, @RequestParam int dataId, Model model){
		System.out.println("table name="+name);
		System.out.println("dataId="+dataId);
		String columns = hiveServiceImpl.getColumnsForTalble(name);
		TableVo tableVo = new TableVo();
		tableVo.setColumns(columns);
		tableVo.setTableName(name);
		model.addAttribute("tableVo", tableVo);
		model.addAttribute("dataId", dataId);
		return "hive/edittable";
	}
	
	@RequestMapping(value="/hive/table/edit", method=RequestMethod.POST)
	public String editTable(@ModelAttribute TableVo tableVo, @RequestParam int dataId, Model model ){
		if(tableVo.getNewTableName() == null || tableVo.getNewTableName().isEmpty()){
			model.addAttribute("error", "테이블 이름을 입력하세요");
			return "hive/edittable";
		} else if(tableVo.getColumns() == null || tableVo.getColumns().isEmpty()){
			model.addAttribute("error", "테이블 컬럼을 입력하세요");
			return "hive/edittable";
		} else {
			hiveServiceImpl.editHiveTable(tableVo);
			CollectVo collectVo = new CollectVo();
			collectVo.setDataId(dataId);
			collectVo.setDataName(tableVo.getNewTableName());
			hiveServiceImpl.updateCollectDataName(collectVo);
			return "redirect:/hive/uploadfile";
		}
	}
	
	/**
	 * 파일 업로드 페이지. Collect Data Info 리스트를 보여준다.
	 * @param fileVo
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/hive/uploadfile", method=RequestMethod.GET)
	public String uploadFileView(FileVo fileVo, Model model){
		List<CollectVo> collectList = hiveServiceImpl.getCollectInfoAll();
		model.addAttribute("collectList", collectList);
		return "/hive/uploadfile";
	}

	/**
	 * 파일 업로드를 위한 상세페이지
	 * @param dataId
	 * @param fileVo
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/hive/collect/detail", method=RequestMethod.GET)
	public String collectDetailView(@RequestParam int dataId, FileVo fileVo, Model model){
		log.debug("dataId = "+dataId);
		//dataId를 key로 하는 데이타 get
		CollectVo collectInfo = new CollectVo();
		collectInfo.setDataId(dataId);
		CollectVo result = hiveServiceImpl.getCollectInfoById(collectInfo);
		model.addAttribute("collectInfo", result);
		
		//dataId에 속한 업로드 파일 리스트 get
		List<FileMasterVo> fileList = hiveServiceImpl.getFileMasters(fileVo.getDataId());
		model.addAttribute("fileList", fileList);
		
		return "/hive/detail";
	}
	
	/**
	 * hive/collect/detail 페잊에서 
	 * 파일을 업로드하는 action으로 T_FILEMASTER 에 file meta data 저장
	 * @param fileVo
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/hive/collect/detail", method=RequestMethod.POST)
	public String uploadFile(FileVo fileVo, Model model){
		log.debug("fileVo : "+fileVo.toString());

		//file upload 한다.
		hiveServiceImpl.uploadFile(fileVo);
		
		//hdfs에 파일을 적재한다.
		hiveServiceImpl.dataLoadUsingHive(fileVo);
		
		//insert T_FILEMASTER 
		hiveServiceImpl.insertFileMaster(fileVo);
		
		//상세페이지를 위한 get data
		CollectVo collectInfo = new CollectVo();
		collectInfo.setDataId(fileVo.getDataId());
		CollectVo result = hiveServiceImpl.getCollectInfoById(collectInfo);
		model.addAttribute("collectInfo", result);
		
		//업로드한 파일리스트 get data
		List<FileMasterVo> fileList = hiveServiceImpl.getFileMasters(fileVo.getDataId());
		log.debug("fileList="+fileList.toString()); 
		model.addAttribute("fileList", fileList);
		
		return "/hive/detail";
	}
	
	/**
	 * 파일을 HDFS에 LOAD
	 * @param filePath
	 * @param tableName
	 * @return
	 */
	@RequestMapping(value="/hive/data/load", method=RequestMethod.POST)
	@ResponseBody
	public String dataLoad(@RequestParam String filePath, @RequestParam String tableName){
		hiveServiceImpl.dataLoadUsingHive(filePath, tableName);
		return "200";
	}
	
	@RequestMapping(value="/hive/analymeta", method=RequestMethod.GET)
	public String analymetaView(AnalyzermetaVo analyzermetaVo, Model model){
		List<AnalyzermetaVo> list = hiveServiceImpl.getAnalyzerListAll();
		model.addAttribute("list", list);
		return "hive/hiveql";
	}
	
	@RequestMapping(value="/hive/analymeta", method=RequestMethod.POST)
	public String analymetaAction(AnalyzermetaVo analyzermetaVo, Model model){
		if(analyzermetaVo.getModname() == "" || analyzermetaVo.getDataid() == 0){
			model.addAttribute("error", "데이타를 입력하세요");
		} else{
			hiveServiceImpl.insertAnalymeta(analyzermetaVo);
			
			List<AnalyzermetaVo> list = hiveServiceImpl.getAnalyzerListAll();
			model.addAttribute("list", list);
		}
		return "hive/hiveql";
	}

	@RequestMapping(value="/hive/analymeta/detail", method=RequestMethod.GET)
	public String analymetaDetailView(@RequestParam int analyzeseq, HiveqlVo hiveqlVo, Model model){
		log.debug("analyzeseq ="+analyzeseq);
		
		System.out.println("analyzeseq ="+analyzeseq);
		
		//analyzer 상세 정보
		AnalyzermetaVo vo = new AnalyzermetaVo();
		vo.setAnalyzeseq(analyzeseq);
		AnalyzermetaVo obj = hiveServiceImpl.getAnalyzer(vo);
		model.addAttribute("obj", obj);

		//hiveql
		HiveqlVo qlVo = new HiveqlVo();
		qlVo.setAnalyzeseq(analyzeseq);
		List<HiveqlVo> list =  hiveServiceImpl.getHiveqlByAnalyzeseq(qlVo);
		System.out.println("hiveql list="+list.toString());
		model.addAttribute("list", list);
		
		return "hive/hiveqldetail";
	}
	
	@RequestMapping(value="/hive/analymeta/detail", method=RequestMethod.POST)
	public String analymetaDetailView(HiveqlVo hiveqlVo, Model model){
		log.debug("analyzeseq ="+hiveqlVo.getAnalyzeseq());
		
		//analyzer 상세 정보
		AnalyzermetaVo vo = new AnalyzermetaVo();
		vo.setAnalyzeseq(hiveqlVo.getAnalyzeseq());
		AnalyzermetaVo obj = hiveServiceImpl.getAnalyzer(vo);
		model.addAttribute("obj", obj);

		//hiveql insert
		hiveServiceImpl.insertHiveql(hiveqlVo);
		
		//hiveql list
		List<HiveqlVo> list =  hiveServiceImpl.getHiveqlByAnalyzeseq(hiveqlVo);
		model.addAttribute("list", list);
		
		return "hive/hiveqldetail";
	}
	
	/**
	 * delete hive ql 
	 * @param hivemoduleid
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/hive/ql/del", method=RequestMethod.POST)
	@ResponseBody
	public String delHiveql(@RequestParam int hivemoduleid, Model model){
		log.debug("analyzeseq ="+hivemoduleid);
		HiveqlVo vo = new HiveqlVo();
		vo.setHivemoduleid(hivemoduleid);
		hiveServiceImpl.deleteHiveql(vo);
		return "200";
	}
	
	/**
	 * get hive ql by hivemoduleid
	 * @param hivemoduleid
	 * @param model
	 * @return HiveqlVo class
	 */
	@RequestMapping(value="/hive/get/ql", method=RequestMethod.GET)
	@ResponseBody
	public HiveqlVo getHiveqlById(@RequestParam int hivemoduleid, Model model){
		log.debug("hivemoduleid ="+hivemoduleid);
		HiveqlVo vo = new HiveqlVo();
		vo.setHivemoduleid(hivemoduleid);
		return hiveServiceImpl.getHiveqlById(vo);
	}
	
	/**
	 * edit Hive ql
	 * @param hiveqlVo
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/hive/ql/update", method=RequestMethod.POST)
	@ResponseBody
	public String updateHiveqlById(@ModelAttribute HiveqlVo hiveqlVo,
			Model model){
		log.debug("hiveqlVo ="+hiveqlVo.toString());
		hiveServiceImpl.updateHiveql(hiveqlVo);
		return "200";
	}
	
	@RequestMapping(value="/hive/select", method=RequestMethod.GET)
	public String selectTable(){
		return "hive/select";
	}
	
	/**
	 * execute hiveql and download result file
	 * @param query : hive ql
	 * @return
	 */
	@RequestMapping(value="/hive/ql/exec", method=RequestMethod.POST)
	public ModelAndView execHiveQLAndDownload(@RequestParam int hivemoduleid){
		String outputFilePath = hiveServiceImpl.getOutputFilePath(null);
		
		//hive ql select
		HiveqlVo hiveqlVo = new HiveqlVo();
		hiveqlVo.setHivemoduleid(hivemoduleid);
		String query = hiveServiceImpl.getHiveqlById(hiveqlVo).getScript();
		System.out.println("select query="+query);
		
		//jobexechis에 상태 기록
		int seq = hiveServiceImpl.insertStatusToJobexeHis(setStatusJobexehis(hivemoduleid, STATUS_START, 0, null));
		System.out.println("insert status and get seq="+seq);
		
		//쿼리실행 및 결과 파일 생성
		boolean result = hiveServiceImpl.execQueryAndOutputFileAsCSV(query, outputFilePath);
		System.out.println("query exec and create file ="+result);
		
		//파일 다운로드
		if(result){
			//jobexehis에 상태 업데이트
			hiveServiceImpl.updateStatusToJobexeHis(setStatusJobexehis(hivemoduleid, STATUS_END, seq, outputFilePath));
			System.out.println("update status end");

			File file = new File(outputFilePath);
			return new ModelAndView("downloadView", "downloadFile", file);
		}else {
			//jobexehis에 상태 업데이트
			hiveServiceImpl.updateStatusToJobexeHis(setStatusJobexehis(hivemoduleid, STATUS_FAIL, seq, null));
			System.out.println("update status failed");
			
			return new ModelAndView("hive/hiveqldetail", "error", "fail for creating file");
		}
	}
	
	/**
	 * Jobexehis class 에 상태값등록
	 * @param hivemoduleid conf가 시작(STATUS_START)인경우 필요 
	 * @param conf 시작 STATUS_START, 종료 STATUS_END, 실패 STATUS_FAIL
	 * @param id jobexehis 의 pk인 seq값 - conf가 종료(STATUS_END) 또는 실패(STATUS_FAIL)인경우 필요
	 * @param outputFilePath 
	 * @return Jobexehis class : set moduleid, statuscd, seq  
	 */
	private JobexehisVo setStatusJobexehis(int hivemoduleid, String conf, int id, String outputFilePath) {
		String outputFolderPath = HdfsPropertyManager.getHdfsPropertyStringValue("HIVE_OUTPUT_FILE_PATH");
		
		JobexehisVo jobexehisVo = new JobexehisVo();
		jobexehisVo.setOutputpath(outputFolderPath);
		System.out.println("jobexehis seq="+id);
		
		if(STATUS_START.equals(conf)){
			jobexehisVo.setModuleid(hivemoduleid);
			jobexehisVo.setStatuscd(STATUS_START);
			
		}else if(STATUS_END.equals(conf)){
			String fileName = FilenameUtils.getName(outputFilePath);
			jobexehisVo.setSeq(id);
			jobexehisVo.setOutputfilenm(fileName);
			jobexehisVo.setStatuscd(STATUS_END);
			
		}else{
			jobexehisVo.setSeq(id);
			jobexehisVo.setStatuscd(STATUS_FAIL);
		}
		return jobexehisVo;
	}

	@RequestMapping(value="/hive/webhdfs", method=RequestMethod.GET)
	public String webHdfsView(){
		return "hive/webhdfs";
	}
	
	@RequestMapping(value="/hive/webhdfs/menu", method=RequestMethod.GET)
	@ResponseBody
	public FileStatuses webHdfsFileTree(){
		return webHDFSServiceImpl.getTree();
	}
	
	@RequestMapping(value="/hive/webhdfs", method=RequestMethod.POST)
	public ModelAndView downFileFromWebHdfs(@RequestParam String path){
		return webHDFSServiceImpl.downFile(path);
	}
	
}
