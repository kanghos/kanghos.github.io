package com.ntels.nidp.mvc.comp.twitter.domain;

public class HitSecVo {
	
	private String dates;
	private String timeSec;
	private int hitCnt;
	
	private String dateTime; //dates + timeSec
	private String startTime;
	private String lastTime;
	public String getDates() {
		return dates;
	}
	public void setDates(String dates) {
		this.dates = dates;
	}
	public String getTimeSec() {
		return timeSec;
	}
	public void setTimeSec(String timeSec) {
		this.timeSec = timeSec;
	}
	public int getHitCnt() {
		return hitCnt;
	}
	public void setHitCnt(int hitCnt) {
		this.hitCnt = hitCnt;
	}
	public String getDateTime() {
		return dateTime;
	}
	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getLastTime() {
		return lastTime;
	}
	public void setLastTime(String lastTime) {
		this.lastTime = lastTime;
	}
	@Override
	public String toString() {
		return "HitSecVo [dates=" + dates + ", timeSec=" + timeSec
				+ ", hitCnt=" + hitCnt + ", dateTime=" + dateTime
				+ ", startTime=" + startTime + ", lastTime=" + lastTime + "]";
	}

	
}
