package com.ntels.nidp.mvc.comp.agent.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.ntels.nidp.mvc.comp.agent.domain.AgentVo;

public class AgentDaoImpl implements AgentDao {

	private SqlSession sqlSession;
	
	public void setSqlSession(SqlSession sqlSess) {
		this.sqlSession = sqlSess; 
	}
	
	public int insertAgent(AgentVo agentVo) {
		return sqlSession.insert("insertAgent", agentVo);
	}

	public int updateAgent(AgentVo agentVo) {
		return sqlSession.update("updateAgent", agentVo);
	}
	
	public int deleteAgent(AgentVo agentVo) {
		return sqlSession.delete("deleteAgent", agentVo);
	}
	
	public List<AgentVo> selectAgentAll() {
		return sqlSession.selectList("selectAgentAll");
	}
	
	public AgentVo selectAgentbyId(AgentVo agentVo) {
		return sqlSession.selectOne("selectAgentbyId", agentVo);
	}
	
	public int selectTotalCount() {
		return sqlSession.selectOne("selectTotalCount");
	}

}
