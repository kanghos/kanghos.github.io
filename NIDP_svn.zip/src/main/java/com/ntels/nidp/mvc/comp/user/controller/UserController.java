package com.ntels.nidp.mvc.comp.user.controller;

import java.util.List;
import java.util.Locale;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.google.gson.Gson;
import com.ntels.nidp.mvc.comp.group.dao.GroupDaoImpl;
import com.ntels.nidp.mvc.comp.group.domain.GroupVo;
import com.ntels.nidp.mvc.comp.user.dao.UserDaoImpl;
import com.ntels.nidp.mvc.comp.user.domain.UserVo;



@Controller
public class UserController {

	private final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired(required = false)
	private UserDaoImpl userDaoImpl;
	
	@Autowired(required = false)
	private GroupDaoImpl groupDaoImpl;
	
	/*@RequestMapping(value="/", method=RequestMethod.GET)
	public String home(Locale locale, Model model) {
		Date date = new Date();
		DateFormat df = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		String formattedData = df.format(date);
		
		System.out.println("Test!@");
		model.addAttribute("serverTime", formattedData);
		return "index";
	}
	
	@RequestMapping(value="/selectAllUser")
	public String selectAllUser(Locale locale, Model model) {
		try{
		List<UserInfo> userList = userDaoImpl.selectAllUser();
		
		Gson gson = new Gson();
		String outStr = gson.toJson(userList);
		model.addAttribute("data", outStr);
		System.out.println("Test!@"+outStr);
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return "test/testData";
	}
	*/
	
	// 입력,수정,조회 페이지를 호출할때...
	@RequestMapping(value = "/user/{pageName}", method = RequestMethod.GET)
	public String loadUserPage(
			@PathVariable(value = "pageName") String pageName,
			@RequestParam(value = "userNo", required = false) String userNo,
			Locale locale, Model model) {

		logger.debug("loadUserPage() path : " + pageName);
		logger.debug("loadUserPage() param : " + userNo);

		String url = "/user/" + pageName;

		try {
			
			List<GroupVo> groupList = groupDaoImpl.selectGroupAll();
			logger.debug("selectGroupAll() return : " + groupList);
			model.addAttribute("groupList", groupList);
			
			switch(pageName) {
			
			case "regi": 
				UserVo userVo = new UserVo();
				model.addAttribute("userInfo", userVo);
				break;
			case "edit":
				
			case "detail":
				UserVo paramVo = new UserVo();
				paramVo.setUserNo(Integer.parseInt(userNo));
				
				userVo = userDaoImpl.selectUserbyNo(paramVo);
				logger.debug("selectUserbyNo() return : " + userVo);
				model.addAttribute("userInfo", userVo);
				break;
			case "list":
				List<UserVo> userList = userDaoImpl.selectUserAll();
				logger.debug("selectUserAll() return : " + userList);
				model.addAttribute("userList", userList);

				GroupVo groupVo = new GroupVo();
				groupVo.setChildren(groupList);
				Gson gson = new Gson();
				String outStr = gson.toJson(groupVo);
				model.addAttribute("groupList", outStr);
				break;
			default:
				url = "/user";
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return url;
	}
	
	// 입력,수정,삭제 데이터를 처리할때...
	@RequestMapping(value = "/user/{procName}", method = RequestMethod.POST)
	public String processUserInfo(
			@PathVariable(value = "procName") String procName,
			@ModelAttribute(value = "userInfo") @Valid UserVo userVo, 
			BindingResult result,
			Locale locale, Model model) {
		logger.debug("processUserInfo() path : " + procName);
		logger.debug("processUserInfo() param : " + userVo);

		String url = "redirect:/user/list";
	
		try {
			int row = 0;

			switch (procName) {
			case "insert":
				if(result.hasErrors()) {
					url = "/user/regi";
					List<GroupVo> groupList = groupDaoImpl.selectGroupAll();
					model.addAttribute("groupList", groupList);
				} else {
					row = userDaoImpl.insertUser(userVo);
				}
				break;
			case "update":
				if(result.hasErrors()) {
					url = "/user/edit";
					List<GroupVo> groupList = groupDaoImpl.selectGroupAll();
					model.addAttribute("groupList", groupList);
				} else {
					row = userDaoImpl.updateUser(userVo);
				}
				break;
			case "delete":
				row = userDaoImpl.deleteUser(userVo);
				break;
			default:
				url = "/user";
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return url;
	}
	
	// 데이터를 검색할때...
	@RequestMapping(value = "/user/search", method = RequestMethod.GET)
	public String searchUserInfo(
			@RequestParam(value = "grpNo") String grpNo,
			@RequestParam(value = "conNo",  required = false) String conNo,
			@RequestParam(value = "conStr", required = false) String conStr,
			Locale locale, Model model) {
		logger.debug("searchUserInfo() params : " + grpNo + "," + conNo + "," + conStr);
		
		UserVo userVo = new UserVo();
		userVo.setGrpNo(Integer.parseInt(grpNo));
		
		if ((conNo != null) && (conStr != null)) {
			if (conNo.equals("1")) {
				userVo.setUserName(conStr);
			}
		}
		
		List<UserVo> userList = userDaoImpl.selectUserbyInput(userVo);
		logger.debug("selectUserbyInput() userList : " + userList);
		model.addAttribute("userList", userList);
		return "/user/listTable";
	}
	
}
