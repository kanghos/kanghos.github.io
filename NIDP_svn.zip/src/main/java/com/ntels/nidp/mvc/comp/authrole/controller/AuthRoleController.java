package com.ntels.nidp.mvc.comp.authrole.controller;

public class AuthRoleController {

}
