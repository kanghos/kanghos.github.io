package com.ntels.nidp.mvc.comp.hive.domain;

import org.springframework.web.multipart.MultipartFile;

public class FileVo {

	private String tableName;
	private MultipartFile file;
	private int dataId;
	private String desc;

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}
	public int getDataId() {
		return dataId;
	}

	public void setDataId(int dataId) {
		this.dataId = dataId;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	@Override
	public String toString() {
		return "FileVo [tableName=" + tableName + ", file=" + file
				+ ", dataId=" + dataId + ", desc=" + desc + "]";
	}
}
