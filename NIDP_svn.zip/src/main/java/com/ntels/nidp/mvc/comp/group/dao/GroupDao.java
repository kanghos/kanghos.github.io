package com.ntels.nidp.mvc.comp.group.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.ntels.nidp.mvc.comp.group.domain.GroupVo;

public interface GroupDao {
	public void setSqlSession(SqlSession sqlSess);
	
	public int insertGroup(GroupVo groupVo);

	public int updateGroup(GroupVo groupVo);
	
	public int deleteGroup(GroupVo groupVo);
	
	public List<GroupVo> selectGroupAll();

	public GroupVo selectGroupbyNo(GroupVo groupVo);
	
	public List<GroupVo> selectGroupbyInput(GroupVo groupVo);
	
	public int selectTotalCount();
}
