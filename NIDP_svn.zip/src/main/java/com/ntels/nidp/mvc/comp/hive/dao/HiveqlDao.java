package com.ntels.nidp.mvc.comp.hive.dao;

import java.util.List;

import com.ntels.nidp.mvc.comp.hive.domain.HiveqlVo;

public interface HiveqlDao {
	
	public List<HiveqlVo> getListAll();
	public HiveqlVo getById(HiveqlVo hiveqlvo);
	public int insert(HiveqlVo hiveqlvo);
	public int update(HiveqlVo hiveqlvo);
	public List<HiveqlVo> getListById(HiveqlVo hiveqlVo);
	public int delete(HiveqlVo hiveqlVo);
	public int deleteHiveqlByDataId(int dataId);
}
