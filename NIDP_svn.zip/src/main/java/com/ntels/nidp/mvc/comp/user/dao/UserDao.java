package com.ntels.nidp.mvc.comp.user.dao;

import java.util.List;

import com.ntels.nidp.mvc.comp.user.domain.UserInfo;
import com.ntels.nidp.mvc.comp.user.domain.UserVo;


public interface UserDao {

	//public List<UserInfo> selectAllUser();
	
	public int insertUser(UserVo userVo);
	
	public int updateUser(UserVo userVo);
	
	public int deleteUser(UserVo userVo);
	
	public List<UserVo> selectUserAll();
	
	public UserVo selectUserbyNo(UserVo userVo);
	
	public UserVo selectUserbyId(UserVo userVo);
	
	public List<UserVo> selectUserbyGrpNo(UserVo userVo);
	
	public List<UserVo> selectUserbyInput(UserVo userVo);
	
	public int selectTotalCount();
}
