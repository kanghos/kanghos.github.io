package com.ntels.nidp.mvc.comp.user.domain;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class UserVo {
	private int userNo;
	
	@NotNull
	@Size(min=3, max=50, message="3자리 이상 50자리 이하로 입력하세요.") 
	private String userId;
	
	@NotNull
	@Size(min=3, max=50, message="3자리 이상 50자리 이하로 입력하세요.")
	private String pwd;

	private String userType;
	private String userName;

	//@Pattern(regexp="^[_0-9a-zA-Z-]+@[0-9a-zA-Z]+(.[_0-9a-zA-Z-]+)*$", message="이메일 형식이 아닙니다.")
	private String email;
	
	private String phone;
	private String hp;
	private String useYn;
	private String sysAdmYn;
	private int grpNo;
	private String grpNameM;
	private int creUserNo;
	private String createDt;
	private int updUserNo;
	private String updateDt;
	public int getUserNo() {
		return userNo;
	}
	public void setUserNo(int userNo) {
		this.userNo = userNo;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getHp() {
		return hp;
	}
	public void setHp(String hp) {
		this.hp = hp;
	}
	public String getUseYn() {
		return useYn;
	}
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}
	public String getSysAdmYn() {
		return sysAdmYn;
	}
	public void setSysAdmYn(String sysAdmYn) {
		this.sysAdmYn = sysAdmYn;
	}
	public int getGrpNo() {
		return grpNo;
	}
	public void setGrpNo(int grpNo) {
		this.grpNo = grpNo;
	}
	public String getGrpNameM() {
		return grpNameM;
	}
	public void setGrpNameM(String grpNameM) {
		this.grpNameM = grpNameM;
	}
	public int getCreUserNo() {
		return creUserNo;
	}
	public void setCreUserNo(int creUserNo) {
		this.creUserNo = creUserNo;
	}
	public String getCreateDt() {
		return createDt;
	}
	public void setCreateDt(String createDt) {
		this.createDt = createDt;
	}
	public int getUpdUserNo() {
		return updUserNo;
	}
	public void setUpdUserNo(int updUserNo) {
		this.updUserNo = updUserNo;
	}
	public String getUpdateDt() {
		return updateDt;
	}
	public void setUpdateDt(String updateDt) {
		this.updateDt = updateDt;
	}
	@Override
	public String toString() {
		return "UserVo [userNo=" + userNo + ", userId=" + userId + ", pwd="
				+ pwd + ", userType=" + userType + ", userName=" + userName
				+ ", email=" + email + ", phone=" + phone + ", hp=" + hp
				+ ", useYn=" + useYn + ", sysAdmYn=" + sysAdmYn + ", grpNo="
				+ grpNo + ", grpNameM=" + grpNameM + ", creUserNo=" + creUserNo
				+ ", createDt=" + createDt + ", updUserNo=" + updUserNo
				+ ", updateDt=" + updateDt + "]";
	}
}
