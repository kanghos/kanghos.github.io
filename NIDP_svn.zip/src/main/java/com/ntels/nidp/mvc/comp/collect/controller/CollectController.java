package com.ntels.nidp.mvc.comp.collect.controller;

import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ntels.nidp.mvc.comp.agent.domain.AgentVo;
import com.ntels.nidp.mvc.comp.collect.dao.CollectDaoImpl;
import com.ntels.nidp.mvc.comp.collect.domain.CollectVo;
import com.ntels.nidp.mvc.comp.collect.service.CollectServiceImpl;

@Controller
public class CollectController {
	
	private final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired(required = false)
	private CollectDaoImpl collectDaoImpl;
	
	@Autowired CollectServiceImpl collectServiceImpl; 
	
	// 입력,수정,조회 페이지를 호출할때...
		@RequestMapping(value = "/collect/{pageName}", method = RequestMethod.GET)
		public String loadCollectPage(@PathVariable(value = "pageName") String pageName,
				@RequestParam(value = "dataId", required = false) String dataId,
				Locale locale, Model model) {
			logger.debug("loadCollectPage() path: " + pageName);
			logger.debug("loadCollectPage() param: " + dataId);
												 
			String url = "/collect/" + pageName;
			
			try {
				switch(pageName) {
				case "regi": 
					CollectVo collectVo = new CollectVo();
					model.addAttribute("collectInfo", collectVo);
					break;
				case "edit":
					
				case "detail":
					CollectVo paramInfo = new CollectVo();
					paramInfo.setDataId(Integer.parseInt(dataId));

					collectVo = collectDaoImpl.selectCollectbyId(paramInfo);
					logger.debug("selectCollectbyId() return: " + paramInfo);
					model.addAttribute("collectInfo", collectVo);
					break;
				case "list":
					List<CollectVo> collectList = collectDaoImpl.selectCollectAll();
					logger.debug("selectCollectAll() return: " + collectList);
					model.addAttribute("collectList", collectList);
					break;
				default:
					url = "/collect";
					break;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return url;
		}

		// 입력,수정,삭제 데이터를 처리할때...
		@RequestMapping(value = "/collect/{procName}", method = RequestMethod.POST)
		public String procCollectData(@PathVariable(value = "procName") String procName,
				@ModelAttribute(value = "collectInfo") CollectVo collectVo, 
				Locale locale, Model model) {
			logger.debug("procCollectData() path: " + procName);
			logger.debug("procCollectData() param: " + collectVo);
			
			String url = "redirect:/collect/list";
			
			try {
				int result = 0;
				
				switch(procName) {
				case "insert": 
					result = collectDaoImpl.insertCollect(collectVo);
					logger.debug("insertCollect() return: " + result);
					break;
				case "update":
					result = collectDaoImpl.updateCollect(collectVo);
					logger.debug("updateCollect() return: " + result);
					break;
				case "delete":
					//result = collectDaoImpl.deleteCollect(collectVo);
					System.out.println("collectVo = "+collectVo.toString());
					result = collectServiceImpl.deleteCollect(collectVo);
					logger.debug("deleteCollect() return: " + result);
					break;
				default:
					break;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return url;
		}
}
