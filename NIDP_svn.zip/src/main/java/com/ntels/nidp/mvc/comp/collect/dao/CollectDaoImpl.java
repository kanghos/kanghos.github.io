package com.ntels.nidp.mvc.comp.collect.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.ntels.nidp.mvc.comp.collect.domain.CollectVo;

public class CollectDaoImpl implements CollectDao {

	private SqlSession sqlSession;
	
	public void setSqlSession(SqlSession sqlSess) {
		this.sqlSession = sqlSess; 
	}

	public int insertCollect(CollectVo collectVo) {
		return sqlSession.insert("insertCollect", collectVo);
	}
	
	public int updateCollect(CollectVo collectVo) {
		return sqlSession.update("updateCollect", collectVo);
	}
	
	public int deleteCollect(CollectVo collectVo) {
		return sqlSession.delete("deleteCollect", collectVo);
	}
	
	public List<CollectVo> selectCollectAll() {
		return sqlSession.selectList("selectCollectAll");
	}
	
	public CollectVo selectCollectbyId(CollectVo collectVo) {
		return sqlSession.selectOne("selectCollectbyId", collectVo);
	}

	public int countByDataUrl(String dataUrl) {
		return sqlSession.selectOne("countbyDataUrl", dataUrl);
	}

	public CollectVo selectByDataUrl(String dataUrl) {
		return sqlSession.selectOne("selectbyDataUrl", dataUrl);
	}

	public int updateCollectDataName(CollectVo collectVo) {
		return sqlSession.update("updateCollectDataName", collectVo);
	}
}
