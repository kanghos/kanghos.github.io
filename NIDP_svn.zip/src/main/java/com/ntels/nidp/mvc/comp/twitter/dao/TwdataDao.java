package com.ntels.nidp.mvc.comp.twitter.dao;

import java.util.List;

import com.ntels.nidp.mvc.comp.twitter.domain.HitSecVo;
import com.ntels.nidp.mvc.comp.twitter.domain.WordTrendVo;
import com.ntels.nidp.mvc.comp.twitter.domain.WordUrlVo;


public interface TwdataDao {

	//List<UserInfo> selectAllUser();
	
	List<WordTrendVo> selectAllWordList();
	
	public List<WordTrendVo> select5minWordList(String startTime);
	
	public List<WordUrlVo> select5minUrlList(String startTime);
	
	public List<HitSecVo> select30SecHitList(HitSecVo dateTime);
}
