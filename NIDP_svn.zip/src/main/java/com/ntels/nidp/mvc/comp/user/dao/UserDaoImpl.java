/**
 * 
 */
package com.ntels.nidp.mvc.comp.user.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.ntels.nidp.mvc.comp.user.domain.UserInfo;
import com.ntels.nidp.mvc.comp.user.domain.UserVo;


/**
 * @author hskang
 *
 */
public class UserDaoImpl implements UserDao {

	
	private SqlSession sqlSession;
	
	public void setSqlSession(SqlSession sqlSess) {
		this.sqlSession = sqlSess; 
	}

/*	//@Override
	public List<UserInfo> selectAllUser() {
		//@SuppressWarnings("unckecked");
		List<UserInfo> userList = sqlSession.selectList("selectAllUserList");
		// TODO Auto-generated method stub
		return userList;
	}
	*/
	
	public int insertUser(UserVo userVo) {
		return sqlSession.insert("insertUser", userVo);
	}
	
	public int updateUser(UserVo userVo) {
		return sqlSession.update("updateUser", userVo);
	}
	
	public int deleteUser(UserVo userVo) {
		return sqlSession.delete("deleteUser", userVo);
	}
	
	public List<UserVo> selectUserAll() {
		return sqlSession.selectList("selectUserAll");
	}
	
	public UserVo selectUserbyNo(UserVo userVo) {
		return sqlSession.selectOne("selectUserbyNo", userVo);
	}
	
	public UserVo selectUserbyId(UserVo userVo) {
		return sqlSession.selectOne("selectUserbyId", userVo);
	}
	
	public List<UserVo> selectUserbyGrpNo(UserVo userVo) {
		return sqlSession.selectList("selectUserbyGrpNo", userVo);
	}
	
	public List<UserVo> selectUserbyInput(UserVo userVo) {
		return sqlSession.selectList("selectUserbyInput", userVo);
	}
	
	public int selectTotalCount() {
		return sqlSession.selectOne("selectTotalCount");
	}
}
