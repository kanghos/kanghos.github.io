package com.ntels.nidp.mvc.comp.twitter.domain;

/**
 * @author hskang
 *
 */
public class WordUrlVo {

	private String word;
	private int cnts;
	private int seq;
	private String dateTimes;
	private String urls;
	/**
	 * @return the word
	 */
	public String getWord() {
		return word;
	}
	/**
	 * @param word the word to set
	 */
	public void setWord(String word) {
		this.word = word;
	}
	/**
	 * @return the cnts
	 */
	public int getCnts() {
		return cnts;
	}
	/**
	 * @param cnts the cnts to set
	 */
	public void setCnts(int cnts) {
		this.cnts = cnts;
	}
	/**
	 * @return the seq
	 */
	public int getSeq() {
		return seq;
	}
	/**
	 * @param seq the seq to set
	 */
	public void setSeq(int seq) {
		this.seq = seq;
	}
	/**
	 * @return the dateTimes
	 */
	public String getDateTimes() {
		return dateTimes;
	}
	/**
	 * @param dateTimes the dateTimes to set
	 */
	public void setDateTimes(String dateTimes) {
		this.dateTimes = dateTimes;
	}
	/**
	 * @return the urls
	 */
	public String getUrls() {
		return urls;
	}
	/**
	 * @param urls the urls to set
	 */
	public void setUrls(String urls) {
		this.urls = urls;
	}
	
	
	
}
