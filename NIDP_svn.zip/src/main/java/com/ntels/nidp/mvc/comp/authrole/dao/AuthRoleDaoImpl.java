package com.ntels.nidp.mvc.comp.authrole.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.ntels.nidp.mvc.comp.authrole.domain.AuthRoleVo;

public class AuthRoleDaoImpl implements AuthRoleDao {
private SqlSession sqlSession;
	
	public void setSqlSession(SqlSession sqlSess) {
		this.sqlSession = sqlSess; 
	}
	
	public int insertAuthRole(AuthRoleVo authRolevo) {
		return sqlSession.insert("insertAuthRole", authRolevo);
	}

	public int updateAuthRole(AuthRoleVo authRolevo) {
		return sqlSession.update("updateAuthRole", authRolevo);
	}
	
	public int deleteAuthRole(AuthRoleVo authRolevo) {
		return sqlSession.delete("deleteAuthRole", authRolevo);
	}
	
	public List<AuthRoleVo> selectAuthRoleAll() {
		return sqlSession.selectList("selectAuthRoleAll");
	}
	
	public AuthRoleVo selectAgentbyId(AuthRoleVo authRolevo) {
		return sqlSession.selectOne("selectAuthRolebyId", authRolevo);
	}
}
