package com.ntels.nidp.mvc.comp.authrole.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.ntels.nidp.mvc.comp.authrole.domain.AuthRoleVo;

public interface AuthRoleDao {
	public void setSqlSession(SqlSession sqlSess);
	
	public int insertAuthRole(AuthRoleVo authRolevo);

	public int updateAuthRole(AuthRoleVo authRolevo);
	
	public int deleteAuthRole(AuthRoleVo authRolevo);
	
	public List<AuthRoleVo> selectAuthRoleAll();
	
	public AuthRoleVo selectAgentbyId(AuthRoleVo authRolevo);
}
