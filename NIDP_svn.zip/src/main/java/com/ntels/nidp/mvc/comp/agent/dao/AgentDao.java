package com.ntels.nidp.mvc.comp.agent.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ntels.nidp.mvc.comp.agent.domain.AgentVo;

public interface AgentDao {

	public int insertAgent(AgentVo agentVo);
	
	public int updateAgent(AgentVo agentVo);
	
	public int deleteAgent(AgentVo agentVo);
	
	public List<AgentVo> selectAgentAll();
	
	public AgentVo selectAgentbyId(AgentVo agentVo);
	
	public int selectTotalCount();
}
