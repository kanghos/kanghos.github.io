package com.ntels.nidp.mvc.comp.hive.service;

import java.io.File;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ntels.nidp.common.config.HdfsPropertyManager;
import com.ntels.nidp.common.utils.ApiHiveSQL;
import com.ntels.nidp.mvc.comp.collect.dao.CollectDaoImpl;
import com.ntels.nidp.mvc.comp.collect.domain.CollectVo;
import com.ntels.nidp.mvc.comp.collect.service.CollectServiceImpl;
import com.ntels.nidp.mvc.comp.hive.dao.AnalyzermetaDaoImpl;
import com.ntels.nidp.mvc.comp.hive.dao.FileMasterDaoImpl;
import com.ntels.nidp.mvc.comp.hive.dao.HiveqlDaoImpl;
import com.ntels.nidp.mvc.comp.hive.dao.JobexehisDaoImpl;
import com.ntels.nidp.mvc.comp.hive.domain.AnalyzermetaVo;
import com.ntels.nidp.mvc.comp.hive.domain.FileMasterVo;
import com.ntels.nidp.mvc.comp.hive.domain.FileVo;
import com.ntels.nidp.mvc.comp.hive.domain.HiveqlVo;
import com.ntels.nidp.mvc.comp.hive.domain.JobexehisVo;
import com.ntels.nidp.mvc.comp.hive.domain.TableVo;

@Service
public class HiveServiceImpl {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired(required = false)
	private CollectDaoImpl collectDaoImpl;
	@Autowired private CollectServiceImpl collectServiceImpl;
	@Autowired private FileMasterDaoImpl fileMasterDaoImpl; 
	@Autowired private AnalyzermetaDaoImpl analyzermetaDaoImpl; 
	@Autowired private HiveqlDaoImpl hiveqlDaoImpl; 
	@Autowired private JobexehisDaoImpl jobexehisDaoImpl; 
	

	public boolean createTable(TableVo tableVo) {
		boolean result = ApiHiveSQL.getInstance().createExternalTableForCSV(tableVo);
		return result;
	}

	/**
	 * 파일 업로드
	 * @param fileVo
	 */
	public void uploadFile(FileVo fileVo) {
		String filePath = getUploadFolderPath()+fileVo.getFile().getOriginalFilename();
		
		File dest = new File(filePath);
		
		try {
			fileVo.getFile().transferTo(dest);
		} catch (IllegalStateException | IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * insert data for hdfs
	 * @param filePath
	 * @param tableName
	 */
	public void dataLoadUsingHive(String filePath, String tableName){
		ApiHiveSQL.getInstance().dataLoad(tableName, filePath);
	}
	
	public void dataLoadUsingHive(FileVo fileVo){
		String filePath = getUploadFolderPath()+fileVo.getFile().getOriginalFilename();
		ApiHiveSQL.getInstance().dataLoad(fileVo.getTableName(), filePath);
	}
	
	public CollectVo insertMetaDataInfo(FileVo fileVo) {
		System.out.println("insertMetaDataInfo");
		String fileName = fileVo.getFile().getOriginalFilename();
		 if(!duplication(fileName)){
			 CollectVo collectInfo = new CollectVo();
			 collectInfo.setAgentId(0);
			 collectInfo.setDataCode("none");
			 collectInfo.setDataName("none");
			 collectInfo.setDataType("K");
			 collectInfo.setDataUrl(fileName);
			 collectInfo.setDataMimeType("CSV");
			 collectInfo.setCreateId("any");
			 collectInfo.setUpdateId("any");
			 int result;
			 result = collectDaoImpl.insertCollect(collectInfo);
			 logger.debug("-----insertCollect() return: " + result);
		 }
	
		 return collectDaoImpl.selectByDataUrl(fileName); 
	}

	/**
	 * dataurl이 존재하는지 체크
	 * @param fileName
	 * @return false 없다. true 있다.
	 */
	private boolean duplication(String fileName) {
		boolean isRows = false;
		int count = collectDaoImpl.countByDataUrl(fileName);
		if(count != 0){
			isRows = true;
		}
		return isRows;
	}

	/**
	 * 파일이 생성되는 경로 : output folder + file name 
	 * @param fileName : 생성할 파일 이름. 만약 null 이면 디폴트 파일 이름은 result_yyyy-MM-dd_HHmmss.csv 이다. 
	 * @return fullpath : output folder + file name
	 */
	public String getOutputFilePath(String fileName) {
		return ApiHiveSQL.getInstance().getOutputFilePath(fileName);
	}

	/**
	 * hive ql 을 실행고 결과 파일을 만든다.( csv파일 )
	 * @param query : 실행할 query
	 * @param outputFilePath : 결과파일이 생성되는 fullpath : folder path + file name
	 * @return
	 */
	public boolean execQueryAndOutputFileAsCSV(String query, String outputFilePath) {
		return ApiHiveSQL.getInstance().ouputFileAsCSV(query, outputFilePath);
		
	}

	public boolean isTable(String tableName) {
		return ApiHiveSQL.getInstance().isTable(tableName);
	}

	/**
	 * T_NIDP_COLLECTDATA_INFO에 저장한다.
	 * @param tableVo
	 * @return CollectInfo를 리턴한다. class안에는 인서트 후 생성된 dataId값이 저장되어 있다.
	 */
	public CollectVo insertCollectData(TableVo tableVo) {
		CollectVo collectInfo = new CollectVo();
		collectInfo.setAgentId(0);
		collectInfo.setDataCode("none");
		collectInfo.setDataName(tableVo.getTableName());
		collectInfo.setDataUrl("none");
		collectInfo.setDataType("K");
		collectInfo.setDataMimeType("CSV");
		collectInfo.setCreateId("any");
		collectInfo.setUpdateId("any");
		collectServiceImpl.insert(collectInfo);
		return collectInfo;
	}

	public CollectVo getCollectInfoById(CollectVo collectInfo) {
		return collectServiceImpl.getInfoById(collectInfo);
	}

	public List<CollectVo> getCollectInfoAll() {
		return collectServiceImpl.selectCollectAll();
	}

	public void insertFileMaster(FileVo fileVo) {
		String fileName = fileVo.getFile().getOriginalFilename();
		
		FileMasterVo fileMasterVo = new FileMasterVo();
		fileMasterVo.setFilenm(fileName);
		fileMasterVo.setDataid(fileVo.getDataId());
		fileMasterVo.setFiletype(fileName.split("\\.")[1]);
		fileMasterVo.setFileuri(getHDFSFileUri(fileVo));
		fileMasterVo.setSvrid("none");
		fileMasterVo.setDescription(fileVo.getDesc());
		fileMasterVo.setCreateid(0);
		fileMasterDaoImpl.insert(fileMasterVo);
	}
	
	private String getHDFSFileUri(FileVo fileVo) {
		return getHiveHDFSFolderPath()+fileVo.getTableName()+"/"+fileVo.getFile().getOriginalFilename();
	}

	public String getUploadFolderPath(){
		return HdfsPropertyManager.getHdfsPropertyStringValue("HIVE_UPLOAD_FILE_PATH");
	}

	public String getHiveHDFSFolderPath(){
		return HdfsPropertyManager.getHdfsPropertyStringValue("HIVE_HDFS_FOLDER");
	}
	
	public String getOutputFolderPath(){
		return HdfsPropertyManager.getHdfsPropertyStringValue("HIVE_OUTPUT_FILE_PATH");
	}

	public List<FileMasterVo> getFileMasters(int dataId) {
		return fileMasterDaoImpl.getListById(dataId);
	}

	public List<AnalyzermetaVo> getAnalyzerListAll() {
		return analyzermetaDaoImpl.getListAll();
	}

	public int insertAnalymeta(AnalyzermetaVo analyzermetaVo) {
		return analyzermetaDaoImpl.insert(analyzermetaVo);
	}

	public AnalyzermetaVo getAnalyzer(AnalyzermetaVo analyzermetaVo) {
		return analyzermetaDaoImpl.getById(analyzermetaVo);
	}

	public List<HiveqlVo> getHiveqlByAnalyzeseq(HiveqlVo hiveqlVo) {
		return hiveqlDaoImpl.getListById(hiveqlVo);
	}

	public int insertHiveql(HiveqlVo hiveqlVo) {
		return hiveqlDaoImpl.insert(hiveqlVo);
	}

	public int deleteHiveql(HiveqlVo hiveqlVo) {
		return hiveqlDaoImpl.delete(hiveqlVo);
	}

	public HiveqlVo getHiveqlById(HiveqlVo vo) {
		return hiveqlDaoImpl.getById(vo);
	}

	public int updateHiveql(HiveqlVo hiveqlVo) {
		return hiveqlDaoImpl.update(hiveqlVo);
	}

	public int insertStatusToJobexeHis(JobexehisVo jobexehisVo) {
		JobexehisVo obj = jobexehisVo;
		jobexehisDaoImpl.insert(obj);
		return obj.getSeq();
	}

	public int updateStatusToJobexeHis(JobexehisVo jobexehisVo) {
		return jobexehisDaoImpl.update(jobexehisVo); 
	}

	public String getColumnsForTalble(String tableName) {
		List<Map<String, String>> result = ApiHiveSQL.getInstance().describeTable(tableName);
		StringBuffer sb = new StringBuffer();
		int length = result.size();
		
		for (int i = 0; i < length; i++) {
			appendColumns(result, sb, length, i);
		}
		
		System.out.println("colums ="+sb);
		return sb.toString();
	}

	private void appendColumns(List<Map<String, String>> result, StringBuffer sb, int length, int i) {
		String  columnWithComment =	"{0} {1} comment ''{2}''";
		String  column = "{0} {1}";
		
		Map<String, String> map = result.get(i);
		String cName = map.get("columnName");
		String type = map.get("type");
		String comment = map.get("comment");

		if("None".equals(comment)){
			sb.append(MessageFormat.format(column, cName, type));
		}else {
			sb.append(MessageFormat.format(columnWithComment, cName, type, comment));
		}
		
		if(length != i+1){
			sb.append(", ");
		}
	}

	public void editHiveTable(TableVo tableVo) {
		ApiHiveSQL.getInstance().alterRenameTable(tableVo.getTableName(), tableVo.getNewTableName());
		ApiHiveSQL.getInstance().alterReplaceColumns(tableVo.getNewTableName(), tableVo.getColumns());
	}

	public int updateCollectDataName(CollectVo collectVo) {
		return collectServiceImpl.updateCollectDataName(collectVo);
	}

	public boolean deleteTableUsingHiveql(String dataName) {
		return ApiHiveSQL.getInstance().dropTable(dataName);
	}

	public int deleteFileMasterByDataId(int dataId) {
		return fileMasterDaoImpl.deleteFileMasterByDataId(dataId);
	}

	public int deleteHiveqlByDataId(int dataId) {
		return hiveqlDaoImpl.deleteHiveqlByDataId(dataId);
	}

	public int deleteAnalyzerMetaByDataId(int dataId) {
		return analyzermetaDaoImpl.deleteAnalyzerMetaByDataId(dataId);
	}
}
