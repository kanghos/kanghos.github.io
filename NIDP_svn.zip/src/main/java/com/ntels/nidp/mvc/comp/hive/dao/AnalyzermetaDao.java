package com.ntels.nidp.mvc.comp.hive.dao;

import java.util.List;

import com.ntels.nidp.mvc.comp.hive.domain.AnalyzermetaVo;

public interface AnalyzermetaDao {

	public List<AnalyzermetaVo> getListAll();
	public AnalyzermetaVo getById(AnalyzermetaVo analyzermetaVo);
	public int insert(AnalyzermetaVo analyzermetaVo);
	public int update(AnalyzermetaVo analyzermetaVo);
	public int deleteAnalyzerMetaByDataId(int dataId);
}
