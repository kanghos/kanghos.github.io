package com.ntels.nidp.mvc.comp.hive.dao;

import java.util.List;

import com.ntels.nidp.mvc.comp.hive.domain.FileMasterVo;


public interface FileMasterDao {

	public List<FileMasterVo> getListById(int dataId);
	public int insert(FileMasterVo fileMasterVo);
	public int deleteFileMasterByDataId(int dataId);
}
