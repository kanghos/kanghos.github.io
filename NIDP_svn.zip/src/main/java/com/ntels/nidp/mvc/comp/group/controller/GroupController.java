package com.ntels.nidp.mvc.comp.group.controller;

import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.ntels.nidp.mvc.comp.group.dao.GroupDaoImpl;
import com.ntels.nidp.mvc.comp.group.domain.GroupVo;
import com.ntels.nidp.mvc.comp.user.dao.UserDaoImpl;
import com.ntels.nidp.mvc.comp.user.domain.UserVo;

@Controller
public class GroupController {
	
	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired(required = false)
	private GroupDaoImpl groupDaoImpl;
	
	@Autowired(required = false)
	private UserDaoImpl userDaoImpl;
	
	// 입력,수정,조회 페이지를 호출할때...
	@RequestMapping(value = "/group/{pageName}", method = RequestMethod.GET)
	public String loadGroupPage(
			@PathVariable(value = "pageName") String pageName,
			@RequestParam(value = "grpNo", required = false) String grpNo,
			Locale locale, Model model) {
		
		logger.debug("loadGroupPage() path : " + pageName);
		logger.debug("loadGroupPage() param : " + grpNo);
		
		String url = "/group/" + pageName;
	
		try {
			switch(pageName) {
			case "regi": 
				GroupVo groupVo = new GroupVo();
				model.addAttribute("groupInfo", groupVo);
				break;
			case "edit":
				
			case "detail":
				GroupVo paramVo = new GroupVo();
				paramVo.setGrpNo(Integer.parseInt(grpNo));
				
				groupVo = groupDaoImpl.selectGroupbyNo(paramVo);
				logger.debug("selectGroupbyNo() return : " + groupVo);
				model.addAttribute("groupInfo", groupVo);
				break;
			case "list":
				List<GroupVo> groupList = groupDaoImpl.selectGroupAll();
				logger.debug("selectGroupAll() return : " + groupList);
				model.addAttribute("groupList", groupList);
				break;
			default:
				url = "/group";
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return url;
	}
	
	// 입력,수정,삭제 데이터를 처리할때...
	@RequestMapping(value = "/group/{procName}", method = RequestMethod.POST)
	public String processGroupInfo(
			@PathVariable(value = "procName") String procName,
			@ModelAttribute(value = "groupInfo") GroupVo groupVo,
			Locale locale, Model model) {
		logger.debug("processGroupInfo() path : " + procName);
		logger.debug("processGroupInfo() param : " + groupVo);

		String url = "redirect:/group/list";

		try {
			int result = 0;

			switch (procName) {
			case "insert":
				result = groupDaoImpl.insertGroup(groupVo);
				logger.debug("insertGroup() return : " + result);
				break;
			case "update":
				result = groupDaoImpl.updateGroup(groupVo);
				logger.debug("updateGroup() return : " + result);
				break;
			case "delete":
				result = groupDaoImpl.deleteGroup(groupVo);
				logger.debug("deleteGroup() return : " + result);
				break;
			default:
				url = "/group";
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return url;
	}
	
	// 데이터를 검색할때...
	@RequestMapping(value = "/group/search", method = RequestMethod.GET)
	public String searchGroupInfo(
			@RequestParam(value = "conNo") String conNo,
			@RequestParam(value = "conStr") String conStr,
			Locale locale, Model model) {
		logger.debug("searchGroupInfo() path : " + conNo + "," + conStr);
		
		GroupVo groupVo = new GroupVo();
		
		if(conNo.equals("1")) {
			int grpNo = Integer.parseInt(conStr);
			groupVo.setGrpNo(grpNo);
		} else if(conNo.equals("2")) {
			groupVo.setGrpNameM(conStr);
		} else if(conNo.equals("3")) {
			int parentGrpId = Integer.parseInt(conStr);
			groupVo.setParentGrpId(parentGrpId);
		} else if(conNo.equals("4")) {
			groupVo.setParentGrpName(conStr);
		} else if(conNo.equals("5")) {
			groupVo.setGrpDesc(conStr);
		}

		List<GroupVo> groupList = groupDaoImpl.selectGroupbyInput(groupVo);
		logger.debug("selectGroupbyIn() groupList : " + groupList);
		model.addAttribute("groupList", groupList);
		return "/group/listTable";
	}
	
	/*	
	@RequestMapping(value = "/group/getGroupList", method = RequestMethod.GET)
	public @ResponseBody String getGroupList(Locale locale, Model model) {
		List<GroupVo> groupList = groupDaoImpl.selectGroupAll();
		logger.debug("selectGroupAll() groupList : " + groupList);
		
		GroupVo groupVo = new GroupVo();
		groupVo.setChildren(groupList);
		
		Gson gson = new Gson();
		String outStr = gson.toJson(groupVo);
		return outStr;
	}
	*/
}
