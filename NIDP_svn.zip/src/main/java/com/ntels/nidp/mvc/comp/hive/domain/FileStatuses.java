package com.ntels.nidp.mvc.comp.hive.domain;

import java.util.List;



public class FileStatuses {

	private String text;
	private List<FileStatus> children;
	
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public List<FileStatus> getChildren() {
		return children;
	}
	public void setChildren(List<FileStatus> children) {
		this.children = children;
	}
	@Override
	public String toString() {
		return "FileStatuses [text=" + text + ", children=" + children + "]";
	}
}
