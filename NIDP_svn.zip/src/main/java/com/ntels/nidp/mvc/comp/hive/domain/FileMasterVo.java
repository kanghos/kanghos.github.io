package com.ntels.nidp.mvc.comp.hive.domain;

public class FileMasterVo {

	private int fileseq;
	private String filenm;
	private String svrid;
	private String fileuri;
	private String description;
	private int createid;
	private String createdt;
	private String filetype;
	private int dataid;
	
	
	public int getFileseq() {
		return fileseq;
	}
	public void setFileseq(int fileseq) {
		this.fileseq = fileseq;
	}
	public String getFilenm() {
		return filenm;
	}
	public void setFilenm(String filenm) {
		this.filenm = filenm;
	}
	public String getSvrid() {
		return svrid;
	}
	public void setSvrid(String svrid) {
		this.svrid = svrid;
	}
	public String getFileuri() {
		return fileuri;
	}
	public void setFileuri(String fileuri) {
		this.fileuri = fileuri;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getCreateid() {
		return createid;
	}
	public void setCreateid(int createid) {
		this.createid = createid;
	}
	public String getCreatedt() {
		return createdt;
	}
	public void setCreatedt(String createdt) {
		this.createdt = createdt;
	}
	public String getFiletype() {
		return filetype;
	}
	public void setFiletype(String filetype) {
		this.filetype = filetype;
	}
	public int getDataid() {
		return dataid;
	}
	public void setDataid(int dataid) {
		this.dataid = dataid;
	}
	@Override
	public String toString() {
		return "FileMasterVo [fileseq=" + fileseq + ", filenm=" + filenm
				+ ", svrid=" + svrid + ", fileuri=" + fileuri
				+ ", description=" + description + ", createid=" + createid
				+ ", createdt=" + createdt + ", filetype=" + filetype
				+ ", dataid=" + dataid + "]";
	}
}
