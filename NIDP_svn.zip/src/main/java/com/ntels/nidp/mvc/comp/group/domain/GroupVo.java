package com.ntels.nidp.mvc.comp.group.domain;

import java.util.List;

public class GroupVo {
	private int grpNo; // 사용자 그룹 ID
	private String grpNameM; // 사용자 그룹 명
	private int parentGrpId; // 상위 사용자 그룹 ID
	private String parentGrpName; // 상위 사용자 그룹 명
	private String grpDesc; // 사용자 그룹 설명
	private String useYn; // 사용 여부
	private int createUser; // 등록자
	private String createDt; // 등록 일시
	private int updateUser; // 수정자
	private String updateDt; // 수정 일시

	private String iconCls = "task-folder";
	private boolean expanded = false;
	private boolean leaf = true;
	private List<GroupVo> children = null;

	public int getGrpNo() {
		return grpNo;
	}

	public void setGrpNo(int grpNo) {
		this.grpNo = grpNo;
	}

	public String getGrpNameM() {
		return grpNameM;
	}

	public void setGrpNameM(String grpNameM) {
		this.grpNameM = grpNameM;
	}

	public int getParentGrpId() {
		return parentGrpId;
	}

	public void setParentGrpId(int parentGrpId) {
		this.parentGrpId = parentGrpId;
	}

	public String getParentGrpName() {
		return parentGrpName;
	}

	public void setParentGrpName(String parentGrpName) {
		this.parentGrpName = parentGrpName;
	}

	public String getGrpDesc() {
		return grpDesc;
	}

	public void setGrpDesc(String grpDesc) {
		this.grpDesc = grpDesc;
	}

	public String getUseYn() {
		return useYn;
	}

	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	public int getCreateUser() {
		return createUser;
	}

	public void setCreateUser(int createUser) {
		this.createUser = createUser;
	}

	public String getCreateDt() {
		return createDt;
	}

	public void setCreateDt(String createDt) {
		this.createDt = createDt;
	}

	public int getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(int updateUser) {
		this.updateUser = updateUser;
	}

	public String getUpdateDt() {
		return updateDt;
	}

	public void setUpdateDt(String updateDt) {
		this.updateDt = updateDt;
	}

	public String getIconCls() {
		return iconCls;
	}

	public void setIconCls(String iconCls) {
		this.iconCls = iconCls;
	}

	public boolean isExpanded() {
		return expanded;
	}

	public void setExpanded(boolean expanded) {
		this.expanded = expanded;
	}

	public boolean isLeaf() {
		return leaf;
	}

	public void setLeaf(boolean leaf) {
		this.leaf = leaf;
	}

	public List<GroupVo> getChildren() {
		return children;
	}

	public void setChildren(List<GroupVo> children) {
		this.children = children;
	}

	@Override
	public String toString() {
		return "GroupVo [grpNo=" + grpNo + ", grpNameM=" + grpNameM
				+ ", parentGrpId=" + parentGrpId + ", parentGrpName="
				+ parentGrpName + ", grpDesc=" + grpDesc + ", useYn=" + useYn
				+ ", createUser=" + createUser + ", createDt=" + createDt
				+ ", updateUser=" + updateUser + ", updateDt=" + updateDt
				+ ", iconCls=" + iconCls + ", expanded=" + expanded + ", leaf="
				+ leaf + ", children=" + children + "]";
	}
	
}
