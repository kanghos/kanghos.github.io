package com.ntels.nidp.mvc.comp.hive.domain;

public class TableVo {

	private String tableName;
	private String newTableName;
	private String columns;

	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getColumns() {
		return columns;
	}
	public void setColumns(String columns) {
		this.columns = columns;
	}
	public String getNewTableName() {
		return newTableName;
	}
	public void setNewTableName(String newTableName) {
		this.newTableName = newTableName;
	}

	@Override
	public String toString() {
		return "TableVo [tableName=" + tableName + ", newTableName="
				+ newTableName + ", columns=" + columns + "]";
	}
}
