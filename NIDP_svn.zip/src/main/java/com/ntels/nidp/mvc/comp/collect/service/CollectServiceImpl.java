package com.ntels.nidp.mvc.comp.collect.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ntels.nidp.mvc.comp.collect.dao.CollectDao;
import com.ntels.nidp.mvc.comp.collect.domain.CollectVo;
import com.ntels.nidp.mvc.comp.hive.service.HiveServiceImpl;

@Service
public class CollectServiceImpl implements CollectService{

	@Autowired CollectDao dao; 
	@Autowired HiveServiceImpl hiveServiceImpl;
	

	public int insert(CollectVo collectInfo) {
		return dao.insertCollect(collectInfo);
	}

	public CollectVo getInfoById(CollectVo collectInfo) {
		return dao.selectCollectbyId(collectInfo);
	}

	public List<CollectVo> selectCollectAll() {
		return dao.selectCollectAll();
	}

	public int updateCollectDataName(CollectVo collectInfo) {
		return dao.updateCollectDataName(collectInfo);
	}

	public int deleteCollect(CollectVo collectVo) {
		int deleteResult;
		int result = 0;
		boolean isDeleteTable = hiveServiceImpl.deleteTableUsingHiveql(collectVo.getDataName());
		System.out.println("is drop table ="+isDeleteTable);
		if(!isDeleteTable){
			return result;
		}else {
			deleteResult = hiveServiceImpl.deleteFileMasterByDataId(collectVo.getDataId());
			System.out.println("delete_FileMaster_ByDataId="+deleteResult);
			
			deleteResult = dao.deleteCollect(collectVo);
			System.out.println("delete_CollectInfo_ByDataId="+deleteResult);
			
			deleteResult = hiveServiceImpl.deleteHiveqlByDataId(collectVo.getDataId());
			System.out.println("delete_Hiveql_ByDataId="+deleteResult);
			
			deleteResult = hiveServiceImpl.deleteAnalyzerMetaByDataId(collectVo.getDataId());
			System.out.println("delete_AnalyzerMeta_ByDataId="+deleteResult);

			result = 1;
			return result;
		}
	}
}
