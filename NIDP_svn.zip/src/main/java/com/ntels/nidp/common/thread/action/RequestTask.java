package com.ntels.nidp.common.thread.action;

import java.util.*;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ntels.nidp.common.log.LogManager;
import com.ntels.nidp.common.thread.task.Task;

/**
 * 
 * Request Task call 
 * 
 * @author hskang
 *
 */
public class RequestTask extends Task {
	static LogManager log = new LogManager(LogManager.NTELS_NIDP_SYS);
	protected Map map;
	
	public RequestTask(Map map) {
		this.map = map;
	}
	
	public void execute() {
		
		try {
			if(map != null && map.size() > 0) {
				
				Request req = new Request();
				req.setRequestMap(map);
				Work.getInstance().makeExcute(req);
			}
		} catch(Exception e) {
			log.error("RequestTask execute ERROR:"+e.getMessage());
			log.recordException(e);
		}
	}
}
