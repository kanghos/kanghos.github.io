package com.ntels.nidp.common.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;


public class DateTimeUtils {

	public final static String DEFAULT_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS";

	
	/**
	 * 한글 년월일을 취득
	 * @param yyyyMMdd
	 * @return Date
	 */
	public static String getHangulYyyyMMdd(Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy년MM월dd일");
		return sdf.format(date);
	}

	/**
	 * 한글 년월일을 취득
	 * @param yyyyMMdd
	 * @return Date
	 */
	/*public static String getHangulYyyyMMdd(String yyyyMMdd) {
		Date date = getDateToString(yyyyMMdd);
		if (date != null) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy년MM월dd일");
			return sdf.format(date);
		} else {
			return StringUtils.EMPTY;
		}
	}*/

	/**
	 * 한글 년월을 취득
	 * @param yyyyMMdd
	 * @return Date
	 */
	public static String getHangulYyyyMM(String yyyyMM) {
		Date date = getDateToString(yyyyMM + "01");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy년MM월");
		if (date != null) {
			return sdf.format(date);
		} else {
			return null;
		}
	}
	
	/**
	 * 문자열 날짜를 데이트형으로 변환 
	 * @param yyyyMMdd
	 * @return Date
	 */
	public static Date getDateToString(String yyyyMMdd) {
		DateFormat df = new SimpleDateFormat("yyyyMMdd");
		try {
			return df.parse(yyyyMMdd);
		} catch (ParseException e) {
			return null;
		}
	}
	public static Date getDateToString2(String yyyyMM) {
		DateFormat df = new SimpleDateFormat("yyyyMM");
		try {
			return df.parse(yyyyMM);
		} catch (ParseException e) {
			return null;
		}
	}

	/**
	 * 시스템 현재 연도 취득
	 * @return 시스템 현재 연도
	 */
	public static String getSystemYear() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy");
		return sdf.format(new java.util.Date());
	}

	/**
	 * 시스템 현재 월 취득
	 * @return 시스템 현재 월
	 */
	public static String getSystemMonth() {
		SimpleDateFormat sdf = new SimpleDateFormat("MM");
		return sdf.format(new java.util.Date());
	}

	/**
	 * 시스템 현재 일 취득
	 * @return 시스템 현재 일
	 */
	public static String getSystemDay() {
		SimpleDateFormat sdf = new SimpleDateFormat("dd");
		return sdf.format(new java.util.Date());
	}
	
	/**
	 * 시스템 현재 년월 취득
	 * @return 시스템 현재 월
	 */
	public static String getSystemYearMonth() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
		return sdf.format(new java.util.Date());
	}
	
	/**
	 * 시스템 현재 년월일 취득
	 * @return 시스템 현재 월
	 */
	public static String getSystemYearMonthDay() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		return sdf.format(new java.util.Date());
	}

	/**
	 * 현재 날짜시간을 기준으로 해당 날짜포멧 문자열 취득
	 * @return 포멧 문자열
	 */
	public static String getCurrentDate(String formatter) {
		SimpleDateFormat sdf = new SimpleDateFormat(formatter);
		return sdf.format(new java.util.Date());
	}
	
	/**
	 * 특정 일 수만큼 날짜 이동하기.
	 * 
	 * @param orgDate
	 * @param moveDateCnt
	 * @return
	 */
	public static Date getMoveDate(Date orgDate, int moveDateCnt)
	{
		Date movedDate = new Date ( );
		movedDate.setTime ( orgDate.getTime ( ) + ( (long) moveDateCnt * 60 * 60 * 24 * 1000 ) );

		return movedDate;
	}

	public static Date getMoveMonth(Date orgDate, int moveDateCnt)
	{
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(orgDate);
		calendar.add(2, moveDateCnt);
		
		return calendar.getTime();
	}

	/**
	 * 날짜를 특정 format으로 String 변환.
	 * 
	 * @param orgDate
	 * @param formatter
	 * @return
	 */
	public static long getDateToLong(Date orgDate, String formatter) {
		SimpleDateFormat sdf = new SimpleDateFormat(formatter);
		return Long.parseLong(sdf.format(orgDate));
	}
	
	public static String addDateStr(int amount, String pattern) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new Date());
		calendar.add(2, amount);
		return date2str(pattern, calendar.getTime());
	}
	
	public static String date2str(String pattern, Date date) {
		SimpleDateFormat df = new SimpleDateFormat(pattern);
		return df.format(date);
	}
	
	public static String getDate2str(String pattern, String date) {
		return date2str(pattern,getDateToString(date));
	}
	
	
		public static String getDefaultFormat() {
			return DEFAULT_DATE_FORMAT;
		}

		public static TimeZone getTimeZone() {
			return TimeZone.getDefault();
		}

		public static String getCurrentTime() {
			return getCurrentTime(getDefaultFormat());
		}

		public static String getCurrentTime(String formatter) {
			SimpleDateFormat fmt = new SimpleDateFormat(formatter);
			fmt.setTimeZone(getTimeZone());

			return fmt.format(new java.util.Date(System.currentTimeMillis()));
		}

		public static java.util.Date getCurrentDate() {
			return new java.util.Date(System.currentTimeMillis());
		}

		public static java.util.Date getDate(String dt) {
			Calendar cal = Calendar.getInstance();
			cal.set(Integer.valueOf(dt.substring(0, 4)).intValue(), 
					Integer.valueOf(dt.substring(4, 6)).intValue() - 1,
					Integer.valueOf(dt.substring(6, 8)).intValue(), 
					Integer.valueOf(dt.substring(8, 10)).intValue(), 
					Integer.valueOf(dt.substring(10, 12)).intValue(), 
					Integer.valueOf(dt.substring(12, 14)).intValue());
			return cal.getTime();
		}
		
		public static java.util.Date getDate12(String dt) {
			Calendar cal = Calendar.getInstance();
			cal.set(Integer.valueOf(dt.substring(0, 4)).intValue(), 
					Integer.valueOf(dt.substring(4, 6)).intValue() - 1,
					Integer.valueOf(dt.substring(6, 8)).intValue(), 
					Integer.valueOf(dt.substring(8, 10)).intValue(), 
					Integer.valueOf(dt.substring(10, 12)).intValue()
					//, 
					//Integer.valueOf(dt.substring(12, 14)).intValue()
					);
			return cal.getTime();
		}
		
		
		public static String getStringDateFormat(String dt, String foramt) {
			return convertFormat(getDate(dt), foramt);
		}
		
		public static String getStringDateFormat12(String dt, String foramt) {
			return convertFormat(getDate12(dt), foramt);
		}
		
		public static String adSecond(String dt, long second) {
			Date tempDate = getDate(dt);
			return convertFormat(tempDate.getTime() - (second*1000), "yyyyMMddHHmmss");
		}
		
		public static String adSecondPlus(String dt, long second) {
			Date tempDate = getDate(dt);
			return convertFormat(tempDate.getTime() + (second*1000), "yyyyMMddHHmmss");
		}
		
		public static String adSecond(String dt, long second, String foramt) {
			Date tempDate = getDate(dt);
			return convertFormat(tempDate.getTime() - (second*1000), foramt);
		}
		
		public static String adSecondPlus(String dt, long second, String foramt) {
			Date tempDate = getDate(dt);
			return convertFormat(tempDate.getTime() + (second*1000), foramt);
		}
		
		public static long betweenSecond(String from, String to) {
			return betweenSecond(getDate(from), getDate(to));
		}

		public static long betweenSecond(java.util.Date from, java.util.Date to) {
			return new Double(Math.ceil((to.getTime() - from.getTime()) / 1000)).longValue();
		}

		public static String convertFormat(long dt, String formatter) {
			return convertFormat(toUtilDate(dt), formatter);
		}

		public static String convertFormat(java.util.Date dt, String formatter) {
			SimpleDateFormat sdf = new SimpleDateFormat(formatter);
			return sdf.format(dt);
		}

		public static java.util.Date toUtilDate(long dt) {
			return new java.util.Date(dt);
		}
		
		public static long diffOfSecond(String begin, String end) throws Exception {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmssSSS");
			Date beginDate = formatter.parse(begin);
		    Date endDate = formatter.parse(end);
		    long diff = endDate.getTime() - beginDate.getTime();
		    long diffSecond = diff / 1000;
		    return diffSecond;
		}
		
		public static List getTermIntoDateList(String start_date, String end_date) {
			List<Date> dates = new ArrayList<Date>();

			/*String str_date ="27/08/2010";
			String end_date ="02/09/2010";*/

			try {
				DateFormat formatter ; 
	
				formatter = new SimpleDateFormat("yyyyMMdd");
				Date  startDate = (Date)formatter.parse(start_date); 
				Date  endDate = (Date)formatter.parse(end_date);
				long interval = 24*1000 * 60 * 60; // 1 hour in millis
				long endTime =endDate.getTime() ; // create your endtime here, possibly using Calendar or Date
				long curTime = startDate.getTime();
				while (curTime <= endTime) {
				    dates.add(new Date(curTime));
				    curTime += interval;
				}
				for(int i=0;i<dates.size();i++){
				    Date lDate =(Date)dates.get(i);
				    String ds = formatter.format(lDate);    
				    System.out.println(" Date is ..." + ds);
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			return dates;
		}
		
		
		
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		DateTimeUtils dtUtils = new DateTimeUtils();
		//.getDate("20120806044900")
		
		//System.out.println("dt:"+dtUtils.getDefaultFormat());
		System.out.println("dt:"+dtUtils.getStringDateFormat12("201208060449", "yyyyMMddHHmm" ));
		String startDt = "201208040400";
		String endDt =   "201208060559";
		
		String startDate = startDt.substring(0,8);
		String startTime = startDt.substring(8);
		String endDate = endDt.substring(0,8);
		String endTime = endDt.substring(8);
		
		if( (Long.parseLong(DateTimeUtils.getStringDateFormat12(startDt, "yyyyMMddHH")) <= Long.parseLong(DateTimeUtils.getStringDateFormat12("201208050610", "yyyyMMddHH")) )
				&& (Long.parseLong(DateTimeUtils.getStringDateFormat12(endDt, "yyyyMMddHH")) >= Long.parseLong(DateTimeUtils.getStringDateFormat12("201208050610", "yyyyMMddHH")) ) ) {
			System.out.println("$$$dt:"+dtUtils.getStringDateFormat12(endDt, "yyyyMMddHH" ));
		} else {
			;
		}
		
		ArrayList<Date> dateList = new ArrayList<Date>();
		
		System.out.println("StartDate="+ startDate);
		System.out.println("StartTime="+ startTime);
		System.out.println("endDate="+ endDate);
		System.out.println("endTime="+ endTime);
		
		/*List<LocalDate> dates = new ArrayList<LocalDate>();
		int days = Days.daysBetween(startDate, endDate).getDays();
		for (int i=0; i < days; i++) {
		    LocalDate d = startDate.withFieldAdded(DurationFieldType.days(), i);
		    dates.add(d);
		}*/
		
		getTermIntoDateList(startDate, endDate);
		
		System.out.println(DateTimeUtils.getStringDateFormat12("201302061000", "yyyyMMddHH" ));
		
		
	}

}

