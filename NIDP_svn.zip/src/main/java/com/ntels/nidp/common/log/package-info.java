/**
 * Management Log 패키지.<br>
 * <br>
 * log4j를 보완하여 Exception발생시 StackTrace를 출력할 수 있도록 구현.<br>
 * 
 * @since 1.0
 */
package com.ntels.nidp.common.log;
