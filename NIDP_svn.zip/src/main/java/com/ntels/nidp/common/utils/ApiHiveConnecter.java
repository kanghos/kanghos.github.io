package com.ntels.nidp.common.utils;

import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.hive.ql.parse.SemanticException;

import au.com.bytecode.opencsv.CSVWriter;

import com.ntels.nidp.common.config.HdfsPropertyManager;
import com.ntels.nidp.common.log.LogManager;


/**
 * Hive JDBC
 * @author hskang
 */
public class ApiHiveConnecter/* extends BaseApi*/{
	private static LogManager log = new LogManager(LogManager.NTELS_NIDP_ANALYZER);
	private volatile static ApiHiveConnecter instance;

	public ApiHiveConnecter(Singleton singleton) {
	}
	
	public static ApiHiveConnecter getInstance() {
		if(instance == null)
			synchronized (ApiHiveConnecter.class) {
				if(instance == null)
					instance = new ApiHiveConnecter(new Singleton());
			}
		return instance;
	}
	
	static class Singleton {
		public Singleton() {}
	}
	
	static {
		;
		try {
			Class.forName(HdfsPropertyManager.getHdfsPropertyStringValue("HIVE_JDBC_DRIVE_NAME"));
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	} 
	
	/**
	 * getConnection
	 * @return
	 */
	private Connection getConnection() { 
		log.debug("ApiJDBCHiveBase getConnection()");
		Connection conn = null;
		try {
			log.debug("ApiJDBCHiveBase getConnection() " + HdfsPropertyManager.getHdfsPropertyStringValue("HIVE_JDBC_URL"));
			
			conn = DriverManager.getConnection(HdfsPropertyManager.getHdfsPropertyStringValue("HIVE_JDBC_URL")
					, HdfsPropertyManager.getHdfsPropertyStringValue("HIVE_JDBC_USER")
					, HdfsPropertyManager.getHdfsPropertyStringValue("HIVE_JDBC_PASS"));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}
	
	/**
	 * close
	 * @param conn
	 * @param stmt
	 * @param rs
	 */
	private void close(Connection conn, Statement stmt, ResultSet rs) {
		log.debug("ApiJDBCHiveBase close()");
		if(rs!=null) { 
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(stmt!=null) {
			try {
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(conn!=null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * getSQL
	 * @author 
	 * @param sql	ex) crete table test (key int, value string)
	 */
	protected boolean getSQL(String sql) {
		log.debug("ApiJDBCHiveBase getSQL()");
		Connection conn = null;
		Statement stmt = null;
		ResultSet res = null;
		boolean isSuccess;
		try {
			log.debug("ApiJDBCHiveBase getSQL() sql -------------------------------->" + sql);
			conn = getConnection();
			stmt = conn.createStatement();
			res = stmt.executeQuery(sql);			
			isSuccess = true;
		} catch(Exception e) {
			e.printStackTrace();
			log.error("ApiJDBCHiveBase getSQL() error -> " + e.getMessage());
			isSuccess = false;
		} finally {
			this.close(conn, stmt, res);
		}
		return isSuccess;
	}
	
	protected List<String> getSQLAsList(String sql) {
		log.debug("ApiJDBCHiveBase getSQL()");
		Connection conn = null;
		Statement stmt = null;
		ResultSet res = null;
		List<String> result = new ArrayList<String>();
		
		try {
			log.debug("ApiJDBCHiveBase getSQL() sql -------------------------------->" + sql);
			conn = getConnection();
			stmt = conn.createStatement();
			res = stmt.executeQuery(sql);
			
			while (res.next()) {
				result.add(res.getString(1));
			}
		} catch(Exception e) {
			//e.printStackTrace();
			log.error("ApiJDBCHiveBase getSQL() error -> " + e.getMessage());
		} finally {
			this.close(conn, stmt, res);
		}
		return result;
	}
	
	/**
	 * getSelectSQL
	 * @author
	 * @param sql	ex) select a, b, c from testTable where a = 1
	 * @param columnLabelList ex) a, b, c ... (List<String>)
	 */
	protected Map<String, String> getSQL(String sql, List<String> columnLabelList) {
		log.debug("ApiJDBCHiveBase getSelectSQL()");
		Map<String, String> map = new HashMap<String, String>();
		Connection conn = null;
		Statement stmt = null;
		ResultSet res = null;
		String column = "";

		try {
			log.debug("ApiJDBCHiveBase getSelectSQL() -------------- sql : " + sql);
			conn = getConnection();
			stmt = conn.createStatement();
			res = stmt.executeQuery(sql);
			int columnLabelListSize = columnLabelList.size();
			
			while (res.next()) {
				for(int i = 0; i < columnLabelListSize; i++) {
					column = columnLabelList.get(i);
					log.debug("HiveJDBCClient getSelectSQL() -------------- column : " + column);
					log.debug("HiveJDBCClient getSelectSQL() --------------  value : " + res.getString(column.trim()));
					
					String value = res.getString(column.trim());
					map.put(column, value == null ? "0" : value);
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			this.close(conn, stmt, res);
		}
		return map;
	}
	
	protected List<Map<String, String>> getSQLAsList(String sql, List<String> columnLabelList) {
		log.debug("ApiJDBCHiveBase getSQLAsList()");
		Connection conn = null;
		Statement stmt = null;
		ResultSet res = null;
		String column = "";

		List<Map<String, String>> result = new ArrayList<Map<String, String>>();
		
		try {
			log.debug("ApiJDBCHiveBase getSelectSQL() -------------- sql : " + sql);
			conn = getConnection();
			stmt = conn.createStatement();
			res = stmt.executeQuery(sql);
			int columnLabelListSize = columnLabelList.size();
			
			while (res.next()) {
				Map<String, String> map = new HashMap<String, String>();
				for(int i = 0; i < columnLabelListSize; i++) {
					column = columnLabelList.get(i);
					log.debug("HiveJDBCClient getSelectSQL() -------------- column : " + column);
					log.debug("HiveJDBCClient getSelectSQL() --------------  value : " + res.getString(i+1).trim());
					
					//String value = res.getString(column.trim());
					String value = res.getString(i+1).trim();
					map.put(column, value == null ? "0" : value);
				}
				result.add(map);
			}
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			this.close(conn, stmt, res);
		}
		return result;
	}
	
	/**
	 * select 한 결과를 csv 파일로 변환
	 * @param sql
	 * @param fileName : 생성할 파일이름으로, 확장자(csv)를 제외한 파일명 이어야함. <br>
	 * 					null 인 경우 default 로 result_yyyy-MM-dd_HHmmss.csv 생성. 생성위치는 propertis 파일에 명시.  
	 * @return
	 */
	protected boolean ouputFileAsCSV(String sql, String destOutputFilePath) {
		log.debug("ApiJDBCHiveBase ouputFileAsCSV()");
		Connection conn = null;
		Statement stmt = null;
		ResultSet res = null;
		boolean isSuccess = true;
		
		try {
			log.debug("ApiJDBCHiveBase getSelectSQL() -------------- sql : " + sql);
			conn = getConnection();
			stmt = conn.createStatement();
			res = stmt.executeQuery(sql);
			
			CSVWriter writer = 
					new CSVWriter(new FileWriter(destOutputFilePath)
					, ','
					, CSVWriter.NO_QUOTE_CHARACTER);
			writer.writeAll(res, false);
			writer.close();
			
		} catch(Exception e) {
			e.printStackTrace();
			isSuccess = false;
		} finally {
			this.close(conn, stmt, res);
		}
		return isSuccess;
	}
	
	/**
	 * output file path 생성
	 * @param fileName : file name이 null이면 디폴트 파일 이름은 result_yyyy-MM-dd_HHmmss.csv 이다.
	 * @return the output folder path + file name. 
	 */
	protected String getOutputFilePath(String fileName){
		String targetFileName;
		String outputFolderPath = HdfsPropertyManager.getHdfsPropertyStringValue("HIVE_OUTPUT_FILE_PATH");
		
		if(fileName != null){
			targetFileName = fileName+".csv";
		}else{
			DateFormat sdFormat = new SimpleDateFormat("yyyy-MM-dd_HHmmss");
			Date nowDate = new Date();
			String tempDate = sdFormat.format(nowDate);
			targetFileName = "result_"+tempDate+".csv";
		}
		String outputFilePath = outputFolderPath+targetFileName;
		log.debug("ApiJDBCHiveBase getOutputFilePath : " + outputFilePath);
		return outputFilePath;
	}

	protected boolean isTable(String tableName) {
		// TODO Auto-generated method stub
		return false;
	}
}
