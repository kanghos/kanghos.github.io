package com.ntels.nidp.common.config;

import java.io.File;

import org.apache.commons.digester.Digester;

import com.ntels.nidp.common.log.LogManager;
import com.ntels.nidp.common.thread.ThreadManager;

public class ThreadManagerConfigDigester {
	static LogManager log = new LogManager(LogManager.NTELS_NIDP_SYS);
	
	public ThreadManagerConfigDigester() {
	}
	
	public static ThreadManagerConfig digest() throws Exception {
		File file = new File(Thread.currentThread().getContextClassLoader().getResource("conf/handler/threadmanager.xml").getFile());
		
		return digest(file);
	}
	
	public static ThreadManagerConfig digest(File file) throws Exception {
		Digester digester = new Digester();
		digester.setValidating(false);
		
		digester.addObjectCreate("ThreadManagerConfig", ThreadManagerConfig.class);
		digester.addObjectCreate("ThreadManagerConfig/ThreadManager", ThreadManager.class);
		digester.addSetProperties("ThreadManagerConfig/ThreadManager", "id", "id");
		digester.addSetProperties("ThreadManagerConfig/ThreadManager", "count", "count");
		digester.addSetNext("ThreadManagerConfig/ThreadManager", "addThreadManager");
		
		try {
			ThreadManagerConfig dataconfig = (ThreadManagerConfig) digester.parse(file);
			return dataconfig;
		} catch(Exception e) {
			throw new Exception("CommandHandlerConfig Config Error : "+e.getMessage(), e);
		}
	}

	public static void main(String[] args) {
		try {
			ThreadManagerConfig threadManagerConfig = ThreadManagerConfigDigester.digest();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
