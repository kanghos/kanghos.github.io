package com.ntels.nidp.common.thread.task;

import java.util.*;

import com.ntels.nidp.common.log.LogManager;

/**
 * mod. 2013. 11. 20
 * @author hskang
 *
 */
public class TaskThreadPool {
	protected Vector taskThreads = new Vector();
	protected String name = "TaskThreadPool";
	protected volatile boolean stop = false;
	protected TaskQueueMan taskQueue = new TaskQueueMan();

	static LogManager log = new LogManager("ntels.nidp.platform");
	
	protected TaskThreadPool() {
	}

	public void addTask(Task task) {
		
		taskQueue.putTask(task);
	}
	
	protected String getTaskThreadName(String threadName, int index) {
		return threadName+"_"+index;
	}

	protected void init(String name, int size) {
		this.name = name;
		//log.info("name:"+getTaskThreadName(name, 0)+"\tsize:"+size);
		for (int i=0; i<size; i++) {
			TaskThreadMan tm = new TaskThreadMan(getTaskThreadName(name, i));
			tm.setTaskQueue(taskQueue);
			log.info("name:"+tm.getName()+"\tsize:"+i);
		//	
			taskThreads.add(tm);
			tm.start();
		}
	}

	public static TaskThreadPool create(String name, int size) {
		TaskThreadPool pool = new TaskThreadPool();
		
		pool.init(name, size);
		return pool;
	}

	public String getName() {
		return name;
	}

	public void stop() {
		List tms;
		synchronized (this) {
			stop = true;
			tms = (List) taskThreads.clone();
		}
		for (int i=0; i<tms.size(); i++) {
			TaskThreadMan tm = (TaskThreadMan) tms.get(i);
			tm.terminate();
			synchronized (tm) {
				tm.notify();
			}
			try {
				tm.join();
			}
			catch (InterruptedException ex) {
			}
		}
	}

	public synchronized void interrupt() {
		for (int i=0; i<taskThreads.size(); i++) {
			TaskThreadMan tm = (TaskThreadMan) taskThreads.get(i);
			tm.interrupt();
		}
	}

	public synchronized boolean isIdle() {
		for (int i=0; i<taskThreads.size(); i++) {
			TaskThreadMan tm = (TaskThreadMan) taskThreads.get(i);
			if (!tm.isIdle()) {
				return false;
			}
		}
		return true;
	}
}
