package com.ntels.nidp.common.handler;


/**
 * @author hskang
 *
 */
public  class CommandManager {
	public static final String SHUTDOWN = "shutdown";
	public static final String EXIT = "exit";
	protected String id;
	protected String handler;
	
	public CommandManager() {}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getHandler() {
		return handler;
	}
	
	public AbstractHandler getHandlerInstance() throws Exception {
		AbstractHandler abstractHandler = null;
		try {
			abstractHandler = (AbstractHandler) Class.forName(handler).newInstance();
		} catch(Exception e) {
			abstractHandler = new NullHandler();
		}
		
		return abstractHandler;
	}

	public void setHandler(String handler) {
		this.handler = handler;
	}
	
}
