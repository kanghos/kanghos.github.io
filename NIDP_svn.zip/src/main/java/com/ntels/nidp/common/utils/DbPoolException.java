package com.ntels.nidp.common.utils;

/**
 * @author hskang
 *
 */
public class DbPoolException extends Exception {

	@SuppressWarnings("serial")
	
	public DbPoolException(final String msg, Exception e) {
	         super(msg, e);
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
