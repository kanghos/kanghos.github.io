package com.ntels.nidp.common.thread.task;

import java.util.Calendar;

import com.ntels.nidp.analyzer.loader.RuntimeJarLoader;
import com.ntels.nidp.common.log.LogManager;
import com.ntels.nidp.common.utils.DateUtils;
import com.ntels.nidp.common.utils.StringUtil;

/**
 * 2013.11.19
 * @author hskang
 *
 */
public class TaskThreadMan extends Thread  {
	static LogManager log = new LogManager(LogManager.NTELS_NIDP_SYS);
	public static int STATUS = Status.READY;
	private Task task = null;
	private boolean run = true;
	private boolean stop = false;
	private TaskQueueMan taskQueue;

	public TaskThreadMan(String name) {
		super(name);
	}

	public void setTaskQueue(TaskQueueMan taskQueue) {
		if(taskQueue == null) {
			log.info("taskQueue null!");
		} else {
			//log.info("taskQueue :" +taskQueue.getTask().toString());
		}
		this.taskQueue = taskQueue;
	}
	
	public void run() {
		while ((!stop) && run) {
			STATUS = Status.READY;
			task = (Task) taskQueue.getTask();
			STATUS = Status.RUN;
			
			synchronized (this) {
				if (task != null) {
					try {
						/*String[] args = new String[3];
						String currDateTime = DateUtils.getCurrentTime("yyyyMMddHHmm");
						Calendar cal1 = Calendar.getInstance();
						//cal1.setTime(cal.getTime());
						cal1.add(Calendar.MINUTE, -1); // 현재의 1분전 데이터가 대상
						String tm_1m_ago = StringUtil.getMinFormat(cal1.getTime()); // yyyyMMddHH
						
						log.info("[ELAPED PER MIN]2min Elapsed : NowTime: " +currDateTime + "      2min ago:" + tm_1m_ago + "(msec)");
						//for (int i=0; i<24; i++) {  // 00시부터 23시까지
						args[0] = tm_1m_ago;
						args[1] = currDateTime;
						//RuntimeJarLoader.getInstance().loadJarIndDir("d:/", "nidp_twitter0.9.jar" , args);
						RuntimeJarLoader.getInstance().loadJarIndDir("d:/","nidp_twitter0.9.jar", args);
						*/
						task.execute();
					} catch(Exception e) {
						log.error("TaskThread["+super.getName()+"] Exception : "+e.getMessage());
						log.recordException(e);
					}
					task = null;
				} else {
					try {
						wait();
					} catch (InterruptedException ex) {
						run = false;
						break;
					}
				}
			}
		}
	}
	
	public int getTaskStatus() {
		return STATUS;
	}
	public boolean isIdle() {
		return ((task == null) && run && !stop);
	}
	
	public boolean isStopped() {
		return stop;
	}
	
	public void terminate() {
		stop = true;
	}
}
