package com.ntels.nidp.common.config;

import java.util.*;

import com.ntels.nidp.common.handler.CommandManager;

/**
 * @author hskang
 *
 */
public class CommandHandlerConfig {
	protected Map map = new HashMap();
	
	public CommandHandlerConfig() {}
	
	public void addCommand(CommandManager command) {
		map.put(command.getId(), command);
	}
	
	public Map getCommandMap() {
		return map;
	}
	
	public CommandManager getCommand(String id) {
		return (CommandManager) map.get(id);
	}
}
