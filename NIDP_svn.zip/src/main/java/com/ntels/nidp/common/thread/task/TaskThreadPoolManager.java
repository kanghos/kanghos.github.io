package com.ntels.nidp.common.thread.task;

import java.util.*;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ntels.nidp.common.config.ConfigurationLoader;
import com.ntels.nidp.common.config.ThreadManagerConfig;
import com.ntels.nidp.common.log.LogManager;
import com.ntels.nidp.common.thread.ThreadManager;


public class TaskThreadPoolManager {
	static LogManager log = new LogManager(LogManager.NTELS_NIDP_SYS);
	
	public static final String TASK_THREAD = "TASK_THREAD";
	
	private static HashMap threadManagerMap = new HashMap();
	private ConfigurationLoader configLoader;
	//private ThreadManager threadManager;
	
	public TaskThreadPoolManager() {
	}
	
	public void setConfigLoader(ConfigurationLoader configLoader) {
		this.configLoader = configLoader;
	}
	
	public void createTaskThreadPool() {
		ThreadManagerConfig threadManagerConfig = ConfigurationLoader.getThreadManagerConfig();
		List list = (List) threadManagerConfig.getThreadManager();
		Iterator itr = list.iterator();
		
		while(itr.hasNext()) {
			ThreadManager threadManager = (ThreadManager) itr.next();
			log.info("Set ConfigLoader!"+threadManager.getId());
			threadManagerMap.put(threadManager.getId(), TaskThreadPool.create(threadManager.getId(), threadManager.getCount()));
			log.info("Task ThreadPool create ["+threadManager.getId()+"] count["+threadManager.getCount()+"]");
		}
	}
	
	public static TaskThreadPool getTaskThreadPool(String name) {
		return (TaskThreadPool) threadManagerMap.get(name);
	}

	
	public void stop() {
		Iterator itr = threadManagerMap.entrySet().iterator();
		while(itr.hasNext()) {
			((TaskThreadPool) itr.next()).stop();
		}
	}
	
	public void interrupt() {
		Iterator itr = threadManagerMap.entrySet().iterator();
		while(itr.hasNext()) {
			((TaskThreadPool) itr.next()).interrupt();
		}
	}
}
