package com.ntels.nidp.common.thread.task;

public abstract class Task {
	public abstract void execute();
}
