package com.ntels.nidp.common.utils;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * 문자열 처리 공통 클래스
 * 
 * @author hskang
 *
 */
public class StringUtil {
	
	/**
	 * 분 포맷터
	 */
	private static SimpleDateFormat min_format  = new SimpleDateFormat("yyyyMMddHHmm");
	/**
	 * 시 포맷터
	 */
	private static SimpleDateFormat hour_format = new SimpleDateFormat("yyyyMMddHH");
	/**
	 * MySQL용 시 포맷터
	 */
	private static SimpleDateFormat hour_db_format = new SimpleDateFormat("yyyy-MM-dd HH");
	
	/**
	 * 줄바꿈 문자
	 */
	public static final String LF   = System.getProperty("line.separator");
	
	
	/**
	 * 관측시간(yyyyMMddHHmm) 형식으로 현재시간 얻기
	 * @return 현재시간 문자열
	 */
	public static String getCurrentTM() {
		Calendar cal = Calendar.getInstance();
		return min_format.format(cal.getTime());
	}
	
	/**
	 * 분 포맷으로 변환
	 * @param date Date객체
	 * @return 분 포맷 문자열
	 */
	public static String getMinFormat(Date date) {
		return min_format.format(date);
	}
	
	/**
	 * 시 포맷으로 변환
	 * @param date Date객체
	 * @return 시 포맷 문자열
	 */
	public static String getHourFormat(Date date) {
		return hour_format.format(date);
	}
	/**
	 * DB용 시 포맷으로 변환
	 * @param date Date객체
	 * @return 시 포맷 문자열
	 */
	public static String getHourDBFormat(Date date) {
		return hour_db_format.format(date);
	}
	

	/**
	 * 문자열 Null 제거
	 * @param val 문자열
	 * @return Null제거된 문자열
	 */
	public static String rmNullTrim(String val) {
		if (val == null) return "";
		return val.trim();
	}
	
	
	/**
	 * 숫자 필드 Null 제거
	 * @param val Object객체
	 * @return Null 제거된 Object 객체
	 */
	public static Object nullToZero(Object val) {
		if (val == null) return 0;
		return val;
	}
	
	
	/**
	 * int형 파싱
	 * @param val 문자열
	 * @return 파싱된 int
	 */
	public static int parseIntSafe(String val) {
		int ret = 0;
		if (val == null) return 0;
		
		try {
			ret = Integer.parseInt(val);
			
		} catch (NumberFormatException ne) {
			try {
				ret = new Double(Double.parseDouble(val)).intValue();
			} catch (Exception e) {}
		} catch (Exception e) {
			ret = 0;
		}
		return ret;
	}
	
	/**
	 * double형 파싱
	 * @param val 문자열
	 * @return 파싱된 double
	 */
	public static double parseDoubleSafe(String val) {
		double ret = 0;
		if (val == null) return 0.0d;
		
		try {
			ret = Double.parseDouble(val);
		} catch (Exception e) {
			ret = 0.0d;
		}
		return ret;
	}

	/**
	 * 문자열 분리
	 * @param strTarget 문자열
	 * @param strDelim 구분 문자열
	 * @return 문자열 배열
	 */
	public static String[] myToken(String strTarget, String strDelim){

		int index = 0;
		String[] resultStrArray = new String[search(strTarget,strDelim)+1];
		String strCheck = new String(strTarget);
		while(strCheck.length() != 0) {
			int begin = strCheck.indexOf(strDelim);
			if(begin == -1) {
				resultStrArray[index] = strCheck;
				break;
			} else {
				int end = begin + strDelim.length();
				resultStrArray[index++] = strCheck.substring(0, begin);
				strCheck = strCheck.substring(end);
				if(strCheck.length()==0){
					resultStrArray[index] = strCheck;
					break;
				}
			}
		}
		return resultStrArray;
	}

	/**
	 * 문자열 중에서 특정 문자열 위치 리턴
	 * @param strTarget 문자열
	 * @param strSearch 찾을 문자열
	 * @return 위치
	 */
	private static int search(String strTarget, String strSearch){
		int result=0;
		String strCheck = new String(strTarget);
		for(int i = 0; i < strTarget.length(); ){
			int loc = strCheck.indexOf(strSearch);		
			if(loc == -1) {
				break;
			} else {
				result++;
				i = loc + strSearch.length();
				strCheck = strCheck.substring(i);
			}		
		}
		return result;	
	}

	/**
	 * 지정한 포맷으로 숫자형 문자열 변환
	 * @param format 숫자포맷 (Java)
	 * @param value Object객체
	 * @return 숫자형 문자열
	 */
	public static String decimalFormat(String format, Object value){
	   	DecimalFormat df = new DecimalFormat(format);
	   	return df.format(value);
	}
	
	public static String toUnixPath(String path) {
		if (path.toUpperCase().startsWith("C:")) {
			path = path.replaceAll("\\\\", "/");
			path = path.replaceAll("C:", "");
			path = path.replaceAll("c:", "");
		}
		return path;
	}

}
