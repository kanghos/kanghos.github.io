package com.ntels.nidp.common.log;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 상세 로그를 처리하는 클래스<br>
 * <br>
 * Exception 발생시 Stacktrace를 로깅할 수 있도록 구현되어 있다.
 *  
 * @author hskang
 *
 */
public class LogManager {
	
	public static final String NTELS_NIDP_SYS = "ntels.nidp.platform";
	public static final String NTELS_NIDP_ANALYZER = "ntels.nidp.analyzer";
	/**
	 * 로깅 객체
	 */
	Log log;

	/**
	 * 생성자 (이름을 주어 독립적으로 생성)
	 * 
	 * @param name 로거명
	 */
	public LogManager(String name) {
		log = LogFactory.getLog(name);
	}
	
	/**
	 * DEBUG 레벨 로깅 가능 여부 리턴
	 * @return DEBUG 레벨 로깅 가능 여부
	 */
	public boolean isDebugEnabled() {
		return log.isDebugEnabled();
	}
	
	/**
	 * INFO 레벨 로깅 가능 여부 리턴
	 * @return INFO 레벨 로깅 가능 여부 리턴
	 */
	public boolean isInfoEnabled() {
		return log.isInfoEnabled();
	}
	
	/**
	 * WARN 레벨 로깅 가능 여부 리턴
	 * @return WARN 레벨 로깅 가능 여부 리턴
	 */
	public boolean isWarnEnabled() {
		return log.isWarnEnabled();
	}
	
	/**
	 * ERROR 레벨 로깅 가능 여부 리턴
	 * @return ERROR 레벨 로깅 가능 여부 리턴
	 */
	public boolean isErrorEnabled() {
		return log.isErrorEnabled();
	}
	
	/**
	 * FATAL 레벨 로깅 가능 여부 리턴
	 * @return FATAL 레벨 로깅 가능 여부 리턴
	 */
	public boolean isFatalEnabled() {
		return log.isFatalEnabled();
	}

	/**
	 * DEBUG 레벨 로깅
	 * @param str 로그 내용
	 */
	public void debug(String str) {
		log.debug(str);
	}
	
	/**
	 * INFO 레벨 로깅
	 * @param str 로그 내용
	 */
	public void info(String str) {
		log.info(str);
	}
	
	/**
	 * WARN 레벨 로깅
	 * @param str 로그 내용
	 */
	public void warn(String str) {
		log.warn(str);
	}
	
	/**
	 * ERROR 레벨 로깅
	 * @param str 로그 내용
	 */
	public void error(String str) {
		log.error(str);
	}
	
	/**
	 * FATAL 레벨 로깅
	 * @param str 로그 내용
	 */
	public void fatal(String str) {
		log.fatal(str);
	}

	/**
	 * 상세 Exception 로깅
	 * @param mention INFO 레벨로 먼저 로깅할 내용
	 * @param e Throwable 객체
	 */
    public void recordException(String mention, Throwable e) {
        log.info(mention);
        recordException(e);
    }

    /**
     * 상세 Exception 로깅
     * @param e Throwable 객체
     */
    public void recordException(Throwable e) {
        StackTraceElement[] traces = e.getStackTrace();
        int size = traces.length;
        log.error(e.toString());
        for(int i = 0; i < size; i++) {
            StackTraceElement element = traces[i];
            log.error("     " + element.toString());
        }
    }
}
