package com.ntels.nidp.common.utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;

import com.ntels.nidp.common.config.HdfsPropertyManager;
import com.ntels.nidp.common.log.LogManager;


public class DBAccessUtil /*extends BaseDao*/{
	static LogManager log = new LogManager("test");
	Connection connection = null;
	 Statement statement = null;
	 ResultSet resultSet = null;
	 
	String driveClass = null;


	private ResourceBundle dbPropertiesService;
	
	private static class Singleton {
		public Singleton() {
			
		}
	}
	
	private volatile static DBAccessUtil instance;
	
	public DBAccessUtil(Singleton singleton) throws Exception {
		   try {
			   initialize();
			   Class.forName(dbPropertiesService.getString("jdbc.driverClassName") );
		  } catch (ClassNotFoundException e) {
		   
			  e.printStackTrace();
		  }
	}
	
	public static DBAccessUtil getInstance() throws Exception {
		if(instance == null)
			synchronized (DBAccessUtil.class) {
				if(instance == null)
					instance = new DBAccessUtil(new Singleton());
			}
		return instance;
	}
	  
	private boolean initialized = false;
	  
	public void initialize() 
		    throws Exception {
		    if(!this.initialized) {
		    if (dbPropertiesService != null) {

			} else {
				dbPropertiesService = HdfsPropertyManager
							.getHifDbProperties();
			}
			createConnection();
		      
		    this.initialized = true;  
		    }
	}
	  
	  
	  /**
	   * @author pollux
	 * @param driverClassName
	 * @param url
	 * @throws Exception
	 */
	/*private void createConnection() throws Exception {
		   Class.forName(dbPropertiesService.getString("jdbc.driver") );
		   
		    connection = DriverManager.getConnection(dbPropertiesService.getString("jdbc.url"),dbPropertiesService.getString("jdbc.user"),
		    		dbPropertiesService.getString("jdbc.password"));
		    connection.setAutoCommit( Boolean.parseBoolean(dbPropertiesService.getString("jdbc.autocommit")));
		    //connection.s
		    //dbPropertiesService...
		    //connection.s
		  //  connection.setClientInfo("validationQuery", "SELECT 1");
	  }
	*/
	public DataSource setupDateSoource(String url){
		  
		  BasicDataSource basicSource = new BasicDataSource();
		  
		  basicSource.setDriverClassName(driveClass);
		  basicSource.setUsername(dbPropertiesService.getString("jdbc.username"));
		  basicSource.setPassword(dbPropertiesService.getString("jdbc.password"));
		  basicSource.setUrl(dbPropertiesService.getString("jdbc.url"));
		  basicSource.setMaxIdle(Integer.parseInt((String)dbPropertiesService.getString("jdbc.maxIdle")));
		  return basicSource;
	}

		

	  
	public void createConnection(){
		  DataSource dataSource = setupDateSoource(dbPropertiesService.getString("jdbc.url"));
		  
		  try {
			  if(connection == null)  {
				   connection = dataSource.getConnection();
			   //connection.setAutoCommit( Boolean.parseBoolean(dbPropertiesService.getString("jdbc.autocommit")));
			   //connection.setClientInfo("validationQuery", "SELECT 1");
				   log.info("Create DB Connection!");
				   System.out.println("Create DB Connection!");
			  } else if(connection.isClosed()) {
				  connection = dataSource.getConnection();
				  log.info("Create DB Connection!");
				   System.out.println("Create DB Connection!");
			  }
		  } catch (SQLException e) {
		   
		   e.printStackTrace();
		  }
		 
	}
	
	 public void shutdownDatasource(DataSource dataSource){
		 try {
		   
		   BasicDataSource basicDataSource = (BasicDataSource)dataSource;
		   basicDataSource.close();
		   
		  } catch (SQLException e) {
		   
		   e.printStackTrace();
		  }
		  
		  
		 }
		 
	 public void closeConnection(){
		  try {
			  if(resultSet != null)
				  resultSet.close();
		  } catch (SQLException e) {
		   
		   e.printStackTrace();
		  }
		  try {
			  if(statement != null)
				  statement.close();
		  } catch (SQLException e) {
		   
		   e.printStackTrace();
		  }
		  try {
			  if(connection != null)
				  connection.close();
		  } catch (SQLException e) {
		   
		   e.printStackTrace();
		  }
		  log.info("Close All Db Connections");
	 }
	
	 public ResultSet selectQuery(String sql){
		  /* Execute select Query
		   * */
		  try {
			  statement = connection.createStatement();
			  resultSet  = statement.executeQuery(sql);
			  return resultSet;
		  } catch (SQLException e) {

		   e.printStackTrace();
		  }
		  return null;
	 }
		 
	public boolean sendQuery(String sql){
		  /* figure out a result form a query
		   * */
		try {
			statement = connection.createStatement();
			int rows = statement.executeUpdate(sql);
		   
			if(rows > 0){   
				return true;
			}
			else{
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	/**
	 * @param currDateTime
	 * @param jobInfoVO
	 * @return
	 * @throws Exception
	 */
	
	  /**Verifies the results are correct */
	  private boolean verify() throws SQLException {
	    //check total num pageview
	    String countAccessQuery = "SELECT COUNT(*) FROM Access";
	    String sumPageviewQuery = "SELECT SUM(pageview) FROM Pageview";
	    Statement st = null;
	    ResultSet rs = null;
	    try {
	      st = connection.createStatement();
	      rs = st.executeQuery(countAccessQuery);
	      rs.next();
	      long totalPageview = rs.getLong(1);

	      rs = st.executeQuery(sumPageviewQuery);
	      rs.next();
	      long sumPageview = rs.getLong(1);

	     /* LOG.info("totalPageview=" + totalPageview);
	      LOG.info("sumPageview=" + sumPageview);*/

	      return totalPageview == sumPageview && totalPageview != 0;
	    }finally {
	      if(st != null)
	        st.close();
	      if(rs != null)
	        rs.close();
	    }
	  }
	  
	  public static void main(String args[]) throws Exception {
		   // GenericObjectPool gPool = new GenericObjectPool();
		    
		    final String currDate = DateUtils.getCurrentTime("yyyyMMddHHmmss");
		

		    
		    String driverClassName = "org.gjt.mm.mysql.Driver";// "com.mysql.jdbc.Driver";
		    String url = "jdbc:mysql://172.19.112.47:3306/hifdb?characterEncoding=euckr";
		    
		    if(args.length > 1) {
		      driverClassName = args[0];
		      url = args[1];
		    }
		  /*  DBAccessUtil dbA = DBAccessUtil.getInstance();
		    dbA.initialize();
		    dbA.moduleInsert(currDate, new JobInfoVO());*/
		    
		    //---------------------------------------------------------
		    
		    String sql = "select * from skcc_login";
		    DBAccessUtil dbcpUtils = DBAccessUtil.getInstance();
		   
		    dbcpUtils.createConnection();
		    ResultSet resultSet = dbcpUtils.selectQuery(sql);
		     
		   
		    try {
		     while (resultSet.next()) {
		      
		      System.out.println("Login -> ID : " + resultSet.getString("username")
		        + ", PW :" + resultSet.getString("password"));
		      
		     }
		    } catch (SQLException e) {
		     // TODO Auto-generated catch block
		     e.printStackTrace();
		    }
	  }
	  
	  
	  /**
	   * @author hskang
	 * @param currDateTime
	 * @param time, hit
	 * @throws Exception
	 */
	public void insertTwitterHit(String timeStr, int hitCnt, String dateTime) throws Exception {

		    PreparedStatement statement = null ;
		    DBAccessUtil dbcpUtils = DBAccessUtil.getInstance();
		     
		    dbcpUtils.createConnection();
		    
		    try {
		    	if(connection == null) 
		    		dbcpUtils.createConnection();
		    	 statement = connection.prepareStatement(
		    			 "INSERT INTO T_TWTHITSEC" +
		   			          "(TIMESEC, " +
		   			          "DATES, " +
		   			          "HITCNT " +
		   			          
		   			          ") \n" +
		   			          " VALUES (?,?,?)"
		   		          , Statement.RETURN_GENERATED_KEYS);
		    	 
		    	 
		    	 statement.setString(1, timeStr);
		//System.out.println("jobInfoVO.getOutputDir():"+jobInfoVO.getOutputDir()) ;   	 
		    	 statement.setString(2, dateTime);
		    	 statement.setInt(3, hitCnt);
		    	 
				 statement.executeUpdate();
			//      connection.commit();
		    }catch (SQLException ex) {
			 //     connection.rollback();
			//      statement.close();
			      ex.printStackTrace();
		    //	ex.getMessage();
			     // throw ex;
		    } finally {
			      if(statement != null) {
			    	  statement.close();
			   // 	  connection.close();
			    	 // closeConnection();
			      }
			}
	  }
	
	  /**
	   * @author hskang
	 * @param currDateTime
	 * @param time, hit
	 * @throws Exception
	 */
	public void updatetTwitterHit(String timeStr, int hitCnt, String dateTime) throws Exception {

		    PreparedStatement statement = null ;
		    DBAccessUtil dbcpUtils = DBAccessUtil.getInstance();
		     
		    dbcpUtils.createConnection();
		    
		    try {
		    	if(connection == null) 
		    		dbcpUtils.createConnection();
		    	 statement = connection.prepareStatement(
		    			 "UPDATE T_TWTHITSEC SET " +
		   			          "HITCNT = ? " +
		   			          "WHERE DATES = ? AND " +
		   			          "TIMESEC = ? \n"
		   		          , Statement.RETURN_GENERATED_KEYS);
		    	 
		    	 
		    	 statement.setInt(1, hitCnt);
		//System.out.println("jobInfoVO.getOutputDir():"+jobInfoVO.getOutputDir()) ;   	 
		    	 statement.setString(2, dateTime);
		    	 statement.setString(3, timeStr);
		    	 
				 statement.executeUpdate();
			//      connection.commit();
		    }catch (SQLException ex) {
			 //     connection.rollback();
			//      statement.close();
			      ex.printStackTrace();
		    //	ex.getMessage();
			     // throw ex;
		    } finally {
			      if(statement != null) {
			    	  statement.close();
			   // 	  connection.close();
			    	 // closeConnection();
			      }
			}
	  }
	
	 /**
	   * @author hskang
	 * @param currDateTime
	 * @param time, hit
	 * @throws Exception
	 */
	public void insertTwtWord(String wordStr, int hitCnt, int wordtype) throws Exception {

		    PreparedStatement statement = null ;
		    DBAccessUtil dbcpUtils = DBAccessUtil.getInstance();
		     
		    dbcpUtils.createConnection();
		    
		    try {
		    	if(connection == null) 
		    		dbcpUtils.createConnection();
		    	 statement = connection.prepareStatement(
		    			 "INSERT INTO T_TWTWORDTREND" +
		   			          "(DATETIMES, " +
		   			          "WORD, " +
		   			          "CNTS, " +
		   			          "WTYPE " +
		   			       
		   			          ") \n" +
		   			          " VALUES (DATE_FORMAT(NOW(),'%Y%m%d%H%i'),?,?,?)"
		   		          , Statement.RETURN_GENERATED_KEYS);
		    	 
		    	 
		    	 //statement.setString(1, timeStr);
		//System.out.println("jobInfoVO.getOutputDir():"+jobInfoVO.getOutputDir()) ;   	 
		    	 statement.setString(1, wordStr);
		    	 statement.setInt(2, hitCnt);
		    	 statement.setInt(3, wordtype);
		    	 
				 statement.executeUpdate();
			//      connection.commit();
		    }catch (SQLException ex) {
			 //     connection.rollback();
			//      statement.close();
		    	System.out.println(wordStr);
			      ex.printStackTrace();
			      throw ex;
		    } finally {
			      if(statement != null) {
			    	  statement.close();
			//    	  connection.close();
			    	  //closeConnection();
			      }
			}
	  }
	
	
	/**
	   * @author hskang
	 * @param currDateTime
	 * @param time, hit
	 * @throws Exception
	 */
	public void insertTwtWordUrl(String wordStr, String urlStr, int hitCnt) throws Exception {

		    PreparedStatement statement = null ;
		    DBAccessUtil dbcpUtils = DBAccessUtil.getInstance();
		     
		    dbcpUtils.createConnection();
		    
		    try {
		    	if(connection == null) 
		    		dbcpUtils.createConnection();
		    	 statement = connection.prepareStatement(
		    			 "INSERT INTO T_URLWORDMAP" +
		   			          "(DATETIMES, " +
		   			          "URLS, " +
		   			          "CNTS, " +
		   			          "WORD " +
		   			          ") \n" +
		   			          " VALUES (DATE_FORMAT(NOW(),'%Y%m%d%H%i'),?,?,?)"
		   		          , Statement.RETURN_GENERATED_KEYS);
		
		    	 statement.setString(1, urlStr);
		    	 statement.setInt(2, hitCnt);
		    	 statement.setString(3, wordStr);
		    	 
		    	 statement.executeUpdate();
			
		    	 //      connection.commit();
		    }catch (SQLException ex) {
			 //     connection.rollback();
			//      statement.close();
		    	System.out.println(urlStr);
			    ex.printStackTrace();
			      throw ex;
		    } finally {
			      if(statement != null) {
			    	  statement.close();
			    //	  closeConnection();
			    //	  connection.close();
			      }
			}
	  }
}
