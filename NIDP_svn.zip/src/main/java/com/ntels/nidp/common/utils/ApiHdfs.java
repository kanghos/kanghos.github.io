
package com.ntels.nidp.common.utils;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javax.annotation.Resource;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.BlockLocation;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FileUtil;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hdfs.DistributedFileSystem;
import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
import org.apache.hadoop.io.IOUtils;
import org.apache.log4j.Level;

import com.ntels.nidp.common.config.HdfsPropertyManager;
import com.ntels.nidp.common.log.LogManager;




/**
 * HDFS I/O class
 * 
 * @author hskang
 */
public class ApiHdfs {

	private static Configuration conf = null;
	private FileSystem fs = null;
	private DistributedFileSystem hdfs = null;

	private volatile static ApiHdfs instance;
	private ResourceBundle testHdfsProperties;

	
	private int FILE_IO_BUFFERSZ = 0;
	
	static LogManager log = new LogManager(LogManager.NTELS_NIDP_SYS);
	

	@Resource(name = "HdfsPropertiesService")
	private HdfsPropertyManager hdfsPropertiesService;

	public ApiHdfs(Singleton singleton) throws IOException {
		//log.`.setLevel(Level.WARN);

		if (conf == null)
			conf = new Configuration();
		
		//conf.setUser("hadoop");
		// conf.set("fs.default.name", "hdfs://192.168.10.130:9000");
		/*
		 * if (hdfsPropertiesService == null) { hdfsPropertiesService =
		 * //HdfsPropertyManager .getMapReduceModuleProperties(); }
		 */
		String HDFS_NAME_VAL = null;
		if(hdfsPropertiesService == null){
			testHdfsProperties = HdfsPropertyManager.getMapReduceModuleProperties();
			String hdfsNameVal = "hdfs://"
					+ testHdfsProperties.getString("HADOOP_MAIN_HOST") + ":"
					+ testHdfsProperties.getString("HDFS_PORT");

			HDFS_NAME_VAL = "hdfs://"
					+ testHdfsProperties.getString("HADOOP_MAIN_HOST") + ":"
					+ testHdfsProperties.getString("HDFS_PORT");
		} else {
			String hdfsNameVal = "hdfs://"
				+ hdfsPropertiesService
						.getHdfsPropertyStringValue("HADOOP_MAIN_HOST") + ":"
				+ hdfsPropertiesService.getHdfsPropertyStringValue("HDFS_PORT");

			HDFS_NAME_VAL = "hdfs://"
				+ hdfsPropertiesService
						.getHdfsPropertyStringValue("HADOOP_MAIN_HOST") + ":"
				+ hdfsPropertiesService.getHdfsPropertyStringValue("HDFS_PORT");
		
		}
		log.info("HDFS_NAME_VAL:"+HDFS_NAME_VAL);
		if (fs == null)
			fs = FileSystem.get(URI.create(HDFS_NAME_VAL), conf);

		if (hdfs == null)
			hdfs = (DistributedFileSystem) fs;
		
		FILE_IO_BUFFERSZ = hdfsPropertiesService.getHdfsPropertyIntValue("HADOOP_IO_BUFFSIZE");
	}

	public ApiHdfs(String mode) throws IOException { // test mode
		conf = new Configuration();
		// conf.set("fs.default.name", "hdfs://192.168.10.130:9000");
		/*
		 * if (hdfsPropertiesService == null) { hdfsPropertiesService =
		 * //HdfsPropertyManager .getMapReduceModuleProperties(); }
		 */
		testHdfsProperties = HdfsPropertyManager.getMapReduceModuleProperties();

		String hdfsNameVal = "hdfs://"
				+ testHdfsProperties.getString("HADOOP_MAIN_HOST") + ":"
				+ testHdfsProperties.getString("HDFS_PORT");

		String HDFS_NAME_VAL = "hdfs://"
				+ testHdfsProperties.getString("HADOOP_MAIN_HOST") + ":"
				+ testHdfsProperties.getString("HDFS_PORT");
		fs = FileSystem.get(URI.create(HDFS_NAME_VAL), conf);
		hdfs = (DistributedFileSystem) fs;
		
		FILE_IO_BUFFERSZ = hdfsPropertiesService.getHdfsPropertyIntValue("HADOOP_IO_BUFFSIZE");
	}

	public static ApiHdfs getInstance() {
		if (instance == null)
			synchronized (ApiHdfs.class) {
				if (instance == null)
					try {
						instance = new ApiHdfs(new Singleton());
					} catch (IOException e) {
						log.info(e.getMessage());
						//e.printStackTrace();
					}
			}
		return instance;
	}

	private static class Singleton {
		public Singleton() {
		}
	}

	public static Configuration getHrwpHdfsConf() {
		if (conf == null) {
			try {
				conf = getInstance().getHrwpHdfsConf();
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else
			return conf;
		return conf;
	}

	/**
	 * read the file from HDFS
	 * 
	 * @param pathFileName
	 */
	public boolean readFile(String pathFileName) {
		System.out.println("HDFS I/O readFile()");
		try {
			FSDataInputStream dis = hdfs.open(new Path(pathFileName));
			IOUtils.copyBytes(dis, System.out, hdfsPropertiesService
					.getHdfsPropertyIntValue("HADOOP_IO_BUFFSIZE"), false);

			dis.close();
			return true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	/**
	 * read the file from HDFS
	 * 
	 * @param pathFileName
	 */
	public ArrayList<String> readFileStream(String pathFileName) {
		System.out.println("HDFS I/O readFileStream()");
		BufferedReader bufferedReader = null;
		String[] readList = null;
		StringBuffer aa;
		
		//Set sss = new Set();
		ArrayList<String> lst = new ArrayList<String>();
	
		String lineStr = "";
		try {
			FSDataInputStream dis = hdfs.open(new Path(pathFileName));
			InputStreamReader inr = new InputStreamReader(dis);
			
			bufferedReader = new BufferedReader(inr);
			
			while ((lineStr = bufferedReader.readLine()) != null) {
				lst.add(lineStr);
				//System.out.println(lineStr);
			}
			
			//System.out.println("readList="+readList.length);
			return lst;
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (bufferedReader != null)
					bufferedReader.close();
				return lst;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return lst;
	}

	/**
	 * write the file from HDFS
	 * 
	 * @param pathFileName
	 * @param content
	 */
	public boolean writeFile(String pathFileName, String content) {
		System.out.println("HDFS I/O  writeFile()");
		try {
			FSDataOutputStream os = hdfs.create(new Path(pathFileName));
			os.write(content.getBytes("UTF-8"));
			os.close();
			return true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * append the file from HDFS
	 * 
	 * @param pathFileName
	 * @param content
	 */
	public synchronized boolean appendFile(String pathFileName, String content) {
		System.out.println("HDFS I/O  appendFile()");
		try {
			FSDataOutputStream os = hdfs.append(new Path(pathFileName));
			os.write(content.getBytes("UTF-8"));
			os.close();
			return true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * copy the file from HDFS to local
	 * 
	 * @param srcFile
	 * @param dstFile
	 */
	public boolean getFile(String srcFile, String dstFile) {
		System.out.println("HDFS I/O  getFile()");
		try {
			Path srcPath = new Path(srcFile);
			Path dstPath = new Path(dstFile);
			hdfs.copyToLocalFile(false, srcPath, dstPath);
			return true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * copy the local file to HDFS
	 * 
	 * @param srcFile
	 * @param dstFile
	 */
	public boolean putFile(String srcFile, String dstFile) {
		System.out.println("HDFS I/O  putFile()");
		try {
			Path srcPath = new Path(srcFile);
			Path dstPath = new Path(dstFile);
			hdfs.copyFromLocalFile(srcPath, dstPath);
			return true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * create the new file
	 * 
	 * @param pathFileName
	 * @return
	 */
	public FSDataOutputStream createFile(String pathFileName) {
		System.out.println("HDFS I/O  createFile()");
		try {
			Path path = new Path(pathFileName);
			FSDataOutputStream outputStream = hdfs.create(path);
			return outputStream;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * rename the file name
	 * 
	 * @param srcName
	 * @param dstName
	 * @return
	 */
	public boolean reNameFile(String srcName, String dstName) {
		System.out.println("HDFS I/O  reNameFile()");
		try {
			Path fromPath = new Path(srcName);
			Path toPath = new Path(dstName);
			boolean isRenamed = hdfs.rename(fromPath, toPath);
			return isRenamed;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * delete the file tyep = true, delete the directory type = false, delece
	 * the file
	 * 
	 * @param pathFileName
	 * @param type
	 * @return
	 */
	public boolean delFile(String pathFileName, boolean type) {
		System.out.println("HDFS I/O  delFile()");
		try {
			Path path = new Path(pathFileName);
			boolean isDeleted = hdfs.delete(path, type);
			return isDeleted;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * Get HDFS file last modification time
	 * 
	 * @param pathFileName
	 * @return
	 */
	public long getFileModTime(String pathFileName) {
		System.out.println("HDFS I/O  getFileModTime()");
		try {
			Path path = new Path(pathFileName);
			FileStatus fileStatus = hdfs.getFileStatus(path);
			long modificationTime = fileStatus.getModificationTime();
			return modificationTime;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return 0;
	}

	/**
	 * checke if a file exists in HDFS
	 * 
	 * @param pathFileName
	 * @return
	 */
	public boolean checkFileExist(String pathFileName) {
		//log.info("HDFS I/O  checkFileExist()");
		try {
			Path path = new Path(pathFileName);
			boolean isExists = hdfs.exists(path);
			log.info("ApiHDFS checkFileExist() isExists : "
					+ isExists);
			return isExists;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	/**
	 * checke if a file exists in HDFS
	 * 
	 * @param pathFileName
	 * @return
	 */
	public boolean checkPathGlobStaus(String pathFileName) {
		//log.info("HDFS I/O  checkFileExist()");
		try {
			Path path = new Path(pathFileName);
			//boolean isExists = hdfs.exists(path);
			log.info("Glob PathPattern check() : " + hdfs.globStatus(path).length
					);
			//if(isExists) {
			if(hdfs.globStatus(path).length > 0) {
				return true; 
			} else {
				return false;
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * Get the locations of a file in the HDFS cluster
	 * 
	 * @param pathFileName
	 * @return
	 */
	public List<String[]> getFileBolckHost(String pathFileName) {
		System.out.println("HDFS I/O  getFileBolckHost()");
		try {
			List<String[]> list = new ArrayList<String[]>();

			Path path = new Path(pathFileName);
			FileStatus fileStatus = hdfs.getFileStatus(path);

			BlockLocation[] blkLocations = hdfs.getFileBlockLocations(
					fileStatus, 0, fileStatus.getLen());

			int blkCount = blkLocations.length;
			for (int i = 0; i < blkCount; i++) {
				String[] hosts = blkLocations[i].getHosts();
				list.add(hosts);
			}
			return list;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Get a list of all the nodes host names in the HDFS cluster
	 * 
	 * @return
	 */
	public String[] getAllNodeName() {
		System.out.println("HDFS I/O  getAllNodeName()");
		try {
			DatanodeInfo[] dataNodeStats = hdfs.getDataNodeStats();
			String[] names = new String[dataNodeStats.length];
			for (int i = 0; i < dataNodeStats.length; i++) {
				names[i] = dataNodeStats[i].getHostName();
				System.out.println(names[i]);
			}
			return names;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * @author
	 * @param awsType
	 *            --> "SKT" or "KMA"
	 * @param path
	 *            --> localFile or dir path
	 * @param rtFlag
	 *            --> 0 : nrt, 1 : rt
	 * @return t/f
	 */
	public synchronized boolean writeHdfs(Path path, String rtFlag) {
		FSDataInputStream hin = null;
		FSDataOutputStream hout = null;

		String hdfsWritePath = "";
		Path hdfsFile = null;

		try {
			// Configuration conf = new Configuration();

			// FileSystem hdfs =
			// FileSystem.get(URI.create("hdfs://172.19.112.49:9000"), conf);

			FileSystem local = FileSystem.getLocal(conf);

			// Path inputDir = new Path(articlexml);
			/* "D:/PROJECT/interpolation/AWS_MIN_20120801" */
			// Path inputDir = new Path("D:/data/samples/AWS_MIN_20120801");
			hdfsWritePath = "/hrwp";

			if ("1".equals(rtFlag)) { // realtime AWS 정보 1분주기
				hdfsFile = new Path("/user/test/aws/rt/20130110"); // hdfs
																	// path
																	// 설정
																	// 관리자
																	// 추가필요
			} else if ("0".equals(rtFlag)) { // non realtime AWS 정보 비실시간 배치
				hdfsFile = new Path("/user/test/aws/nrt/20130110"); // hdfs
			}
			FileStatus[] inputFiles = local.listStatus(path);
			hout = hdfs.create(hdfsFile);

			for (int i = 0; i < inputFiles.length; i++) {
				System.out.println(inputFiles[i].getPath().getName());
				hin = local.open(inputFiles[i].getPath());
				byte[] buffer = new byte[4096];
				int bytesRead = 0;
				while ((bytesRead = hin.read(buffer)) > 0) {
					hout.write(buffer, 0, bytesRead);
				}

			}
		} catch (Exception e) {
			log.debug(e.getMessage());
			// Log.e.printStackTrace();
			return false;
		} finally {
			try {
				if (hin != null)
					hin.close();

			} catch (Exception e) {
			}
			try {
				if (hout != null)
					hout.close();
			} catch (Exception e) {
			}
		}
		return true;
	}

	public DistributedFileSystem getHdfs() {
		return hdfs;

	}
	
	/**
	 * @param dataType
	 * @param srcPath
	 * @param targetTime
	 * @return
	 */
	public synchronized boolean mergeFilePerHour(int dataType, String srcPath, String dateSubDir, String targetTime) {
		FSDataInputStream in = null;
		FSDataOutputStream out = null;
		Path inputPath = null;
		Path outputPath = null;
		
		Path tmpPath = null;
		Path deletePath = null;
		Path outputFilePath = null;
		Path mergePath = null;
		String srcDir="",destDir="",mergeFile="",deleteFiles="";
		
		if(dataType == 1) {
			srcDir = srcPath+"/"+"AWS_MIN_QC_"+dateSubDir+targetTime+"";
			destDir = srcPath+"/prehr/"+dateSubDir+targetTime+"/";
			mergeFile = srcPath+"/prehr/kma_"+dateSubDir+targetTime;
			deleteFiles = destDir +"AWS_MIN_QC_"+dateSubDir+targetTime;
		} else if(dataType == 2){	//QC
			srcDir = srcPath+"/"+"skp_sample_"+dateSubDir+targetTime+"";			//임시 skp qc 샘플 처리
			destDir = srcPath+"/prehr/"+dateSubDir+targetTime+"/";
			mergeFile = srcPath+"/prehr/qc1_"+dateSubDir+targetTime;
			deleteFiles = destDir +"skp_sample_"+dateSubDir+targetTime;
		} else if(dataType == 3){	//INTP
			srcDir = srcPath+"/AWS_MIN_INTP_"+dateSubDir+targetTime+"";			//임시 intp 샘플 처리
			destDir = srcPath+"/prehr/"+dateSubDir+targetTime+"/";
			mergeFile = srcPath+"/prehr/itp_"+dateSubDir+targetTime;
			deleteFiles = destDir +"AWS_MIN_INTP_"+dateSubDir+targetTime;
		}
		
		try {
			Path[] inputPaths = new Path[60];
			Path[] delPaths = new Path[60];
			Configuration conf = getHrwpHdfsConf();
			String minFileUri = "";

			
			hdfs = this.getHdfs();
		
			inputPath = new Path(srcDir);
			outputPath = new Path(destDir);
			outputFilePath = new Path(mergeFile);
				
			deletePath = new Path(deleteFiles);
			mergePath = new Path(mergeFile);
			
			int j = 0;
			for(int i = 0; i <60; i++){
				if(dataType == 2) {
				//	minFileUri = srcDir+StringUtil.decimalFormat("00", i) + ".dat";
					//log.info("minFileUri:"+minFileUri);
				} else if(dataType == 3) {
				//	minFileUri = srcDir+StringUtil.decimalFormat("00", i);// + ".dat";
					log.info("minFileUri:"+minFileUri);
				} else {
				//	minFileUri = srcDir+StringUtil.decimalFormat("00", i);
				}
				System.out.println("minFileUri:"+minFileUri);
				if(checkFileExist(minFileUri)) {
					if(dataType == 2) {
						inputPaths[j] = new Path(minFileUri);
						//log.info("delete:"+deleteFiles+StringUtil.decimalFormat("00", i)+".dat");
				//		delPaths[j] = new Path(deleteFiles+StringUtil.decimalFormat("00", i)+".dat");
					}
					else if(dataType == 3) {		//intp
						inputPaths[j] = new Path(minFileUri);
						//log.info("delete:"+deleteFiles+StringUtil.decimalFormat("00", i)+".dat");
				//		delPaths[j] = new Path(deleteFiles+StringUtil.decimalFormat("00", i));
					} else {
				//		inputPaths[j] = new Path(srcDir+StringUtil.decimalFormat("00", i));
				//		delPaths[j] = new Path(deleteFiles+StringUtil.decimalFormat("00", i));
					}
					j++;
					//System.out.println("inputPaths[i].toString():"+minFileUri);
					//getFile(inputPaths[i].toString(), tmpDir);
				} else {
					//log.info(inputDir+StringUtil.decimalFormat("00", i)+".dat");
				}
			}
			
			if(!checkFileExist(destDir)) {
				hdfs.mkdirs(outputPath);
			} else {
				;
			}
			
			try {
				FileUtil.copy(hdfs, inputPaths, hdfs, outputPath, false, true, conf);
				
			} catch (Exception e) {
				// 해당 내용을 파일 또는 DB 적재
				log.info(e.getMessage());
				//e.getStackTrace();
			}
			
			try {
				if(!checkFileExist(mergeFile)) {
					//out = hdfs.create(outputPath);
					hdfs.mkdirs(outputPath);
				} else {
					delFile(mergeFile, true);
				}
				log.info("outputPath="+outputPath+"\t mergePath"+mergePath);
				FileUtil.copyMerge(hdfs, outputPath, hdfs, mergePath, false, conf, "" );
			} catch (Exception e) {
				// 해당 내용을 파일 또는 DB 적재
				log.info(e.getMessage());
				//e.getStackTrace();
			}
			
			//post process
			for(Path delFile : delPaths) {
				if(delFile != null) {
					//log.info("delFile="+delFile);
					hdfs.delete(delFile, false);
						//hdfs.delete(outputPath, false);
				}
			}
			
			hdfs.delete(outputPath, false);
						
		} catch(Exception e) {
			log.debug(e.getMessage());
			e.printStackTrace();
		} finally {
			try { if(in != null) in.close(); } catch(Exception e) {}
			try { if(out != null) out.close(); } catch(Exception e) {}
		}
		return true;
	}


	/**
	 * 1차 SKP AWS 원천 데이터는 hdfs에 적재 안함
	 * @author
	 * @param awsType
	 *            --> "SKT"
	 * @param path
	 *            --> localFile or dir path
	 * @param rtFlag
	 *            --> 0 : nrt, 1 : rt
	 * @return t/f
	 */
	public synchronized boolean writeSkpAwsSourceData(String sourcePath,
			String fileName,  int rtFlag) {
		FSDataInputStream hin = null;
		FSDataOutputStream hout = null;
		Path srcPath = null;
		Path destPath = null;

		String dfsPath = "";

		try {
			Configuration conf = getHrwpHdfsConf();

			FileSystem hdfs = this.getHdfs();
			//FileSystem.get(URI.create("hdfs://172.19.112.49:9000"), conf);

			FileSystem local = FileSystem.getLocal(conf);

			dfsPath = hdfsPropertiesService.getHdfsPropertyStringValue("AWS.ROOT") +  "/skp/src/"; 
			//dataRoot = "/hrwp/aws/skp/src/" + fileName + "/";

			if (1 == rtFlag) { // realtime AWS �뺣낫 1遺꾩＜湲�
				dfsPath = dfsPath + "rt/";
			} else if (0 == rtFlag) { // non realtime AWS �뺣낫 鍮꾩떎�쒓컙 諛곗튂
				dfsPath = dfsPath + "nrt/";
			}
			
			if(sourcePath != null) {
				dfsPath += (sourcePath.substring((sourcePath.lastIndexOf("/")+1), sourcePath.length()));
			}
			
			srcPath = new Path(sourcePath + "/" + fileName); // local path
			destPath = new Path(dfsPath + "/" + fileName);
			
			FileStatus[] inputFiles = local.listStatus(srcPath);
			hout = hdfs.create(destPath,true);
			//hout = hdfs.create(destPath, true);		// overwrite 시

			for (int i = 0; i < inputFiles.length; i++) {
				log.debug(inputFiles[i].getPath().getName());
				hin = local.open(inputFiles[i].getPath());
				byte[] buffer = new byte[FILE_IO_BUFFERSZ];
				int bytesRead = 0;
				while ((bytesRead = hin.read(buffer)) > 0) {
					hout.write(buffer, 0, bytesRead);
				}

			}
		} catch (Exception e) {
			log.info(e.getMessage());
			e.printStackTrace();
			return false;
		} finally {
			try {
				if (hin != null)
					hin.close();

			} catch (Exception e) {
			}
			try {
				if (hout != null)
					hout.close();
			} catch (Exception e) {
			}
		}
		return true;
	}
	
	/**
	 * QC데이터 hdfs 적재
	 * @author
	 * @param awsType
	 *            --> "SKT"
	 * @param path
	 *            --> localFile or dir path
	 * @param rtFlag
	 *            --> 0 : nrt, 1 : rt
	 * @return t/f
	 */
	public synchronized boolean writeSkpAwsQcData(String sourcePath,
		String fileName,  int rtFlag, int qcLevel) {
		FSDataInputStream hin = null;
		FSDataOutputStream hout = null;
		Path srcPath = null;
		Path destPath = null;

		String dfsPath = "";

		try {
			Configuration conf = getHrwpHdfsConf();

			FileSystem hdfs = this.getHdfs();
			//FileSystem hdfs = FileSystem.get(URI.create("hdfs://172.19.112.49:9000"), conf);

			FileSystem local = FileSystem.getLocal(conf);

			dfsPath = hdfsPropertiesService.getHdfsPropertyStringValue("AWS.ROOT") + "/skp/qc"+qcLevel+"/"; // + fileName + "/";
			
			
			if (1 == rtFlag) { // realtime AWS �뺣낫 1遺꾩＜湲�
				dfsPath = dfsPath + "rt/";
			} else if (0 == rtFlag) { // non realtime AWS �뺣낫 鍮꾩떎�쒓컙 諛곗튂
				dfsPath = dfsPath + "nrt/";
			}
			if(sourcePath != null) {
				dfsPath += (sourcePath.substring((sourcePath.lastIndexOf("/")+1), sourcePath.length()));
			}
			
			srcPath = new Path(sourcePath + "/" + fileName); // local path
			destPath = new Path(dfsPath + "/" + fileName);
			log.info("DFS destPath:"+destPath.toString());
			FileStatus[] inputFiles = local.listStatus(srcPath);
			hout = hdfs.create(destPath, true);

			for (int i = 0; i < inputFiles.length; i++) {
				log.debug(inputFiles[i].getPath().getName());
				hin = local.open(inputFiles[i].getPath());
				byte[] buffer = new byte[FILE_IO_BUFFERSZ];
				int bytesRead = 0;
				while ((bytesRead = hin.read(buffer)) > 0) {
					hout.write(buffer, 0, bytesRead);
				}

			}
		} catch (Exception e) {
			log.info(e.getMessage());
			// Log.e.printStackTrace();
			return false;
		} finally {
			try {
				if (hin != null)
					hin.close();

			} catch (Exception e) {
			}
			try {
				if (hout != null)
					hout.close();
			} catch (Exception e) {
			}
		}
		return true;
	}

	/**
	 * KMA 원천 뎅터 hdfs 적재 
	 * 
	 * @author
	 * @param -->"KMA"
	 * @param path
	 *            --> localFile or dir path
	 * @param rtFlag
	 *            --> 0 : nrt, 1 : rt
	 * @return t/f
	 */
	public synchronized boolean writeKmaAwsSourceData(String sourcePath,
			String fileName, int rtFlag) {
		FSDataInputStream hin = null;
		FSDataOutputStream hout = null;
		Path srcPath = null;
		Path destPath = null;

		String dfsPath = "";

		if (("".equals(sourcePath) && sourcePath == null)
				|| ("".equals(fileName) && fileName == null)) {
			return false;
		}

		try {
			Configuration conf = getHrwpHdfsConf();

			FileSystem hdfs = getHdfs();

			FileSystem local = FileSystem.getLocal(conf);

			dfsPath = hdfsPropertiesService.getHdfsPropertyStringValue("AWS.ROOT") + "/kma/src/";
			
			if (1 == rtFlag) { // realtime AWS �뺣낫 1遺꾩＜湲�
				dfsPath = dfsPath + "rt/";
			} else if (0 == rtFlag) { // non realtime AWS �뺣낫 鍮꾩떎�쒓컙 諛곗튂
				dfsPath = dfsPath + "nrt/";
			}
			if(sourcePath != null) {
				dfsPath += (sourcePath.substring((sourcePath.lastIndexOf("/")+1), sourcePath.length()));
			}
			srcPath = new Path(sourcePath + "/" + fileName); // local path
			destPath = new Path(dfsPath + "/" + fileName);
			
			FileStatus[] inputFiles = local.listStatus(srcPath);

			hout = hdfs.create(destPath, true);

			for (int i = 0; i < inputFiles.length; i++) {
				hin = local.open(inputFiles[i].getPath());
				byte[] buffer = new byte[FILE_IO_BUFFERSZ];
				int bytesRead = 0;
				while ((bytesRead = hin.read(buffer)) > 0) {
					hout.write(buffer, 0, bytesRead);
				}

			}
		} catch (Exception e) {
			log.warn(e.getMessage());
			e.printStackTrace();
			return false;
		} finally {
			try {
				if (hin != null)
					hin.close();

			} catch (Exception e) {
			}
			try {
				if (hout != null)
					hout.close();
			} catch (Exception e) {
			}
		}
		return true;
	}

	/**
	 * KMA AWS 데이터 기반 내삽 결과 hdfs에 적재
	 * 
	 * @author
	 * @param -->"KMA"
	 * @param path
	 *            --> localFile or dir path
	 * @param rtFlag
	 *            --> 0 : nrt, 1 : rt
	 * @return t/f
	 */
	public synchronized boolean writeKmaAwsIntpData(String sourcePath,
			String fileName, int rtFlag) {
		FSDataInputStream hin = null;
		FSDataOutputStream hout = null;
		Path srcPath = null;
		Path destPath = null;

		String dfsPath = "";

		if (("".equals(sourcePath) && sourcePath == null)
				|| ("".equals(fileName) && fileName == null)) {
			return false;
		}

		try {
			Configuration conf = getHrwpHdfsConf();

			FileSystem hdfs = getHdfs();

			FileSystem local = FileSystem.getLocal(conf);

			dfsPath = hdfsPropertiesService.getHdfsPropertyStringValue("AWS.ROOT") + "/kma/intp/";

			if (1 == rtFlag) { // realtime AWS �뺣낫 1遺꾩＜湲�
				dfsPath = dfsPath + "rt/";
			} else if (0 == rtFlag) { // non realtime AWS �뺣낫 鍮꾩떎�쒓컙 諛곗튂
				dfsPath = dfsPath + "nrt/";
			}
			if(sourcePath != null) {
				dfsPath += (sourcePath.substring((sourcePath.lastIndexOf("/")+1), sourcePath.length()));
			}
			srcPath = new Path(sourcePath + "/" + fileName); // local path
			destPath = new Path(dfsPath + "/" + fileName);
			
			FileStatus[] inputFiles = local.listStatus(srcPath);

			hout = hdfs.create(destPath, true);

			for (int i = 0; i < inputFiles.length; i++) {
				hin = local.open(inputFiles[i].getPath());
				byte[] buffer = new byte[FILE_IO_BUFFERSZ];
				int bytesRead = 0;
				while ((bytesRead = hin.read(buffer)) > 0) {
					hout.write(buffer, 0, bytesRead);
				}

			}
		} catch (Exception e) {
			log.warn(e.getMessage());
			e.printStackTrace();
			return false;
		} finally {
			try {
				if (hin != null)
					hin.close();

			} catch (Exception e) {
			}
			try {
				if (hout != null)
					hout.close();
			} catch (Exception e) {
			}
		}
		return true;
	}

	public static void main(String[] args) throws IOException {
		ApiHdfs apiHDFS = new ApiHdfs("test");

		// hdfsPropertiesService =

		// Path path = new Path(
		// "D:\\data\\samples\\AWS_1HR_201208\\AWS_1HR_2012080100");
		// HdfsApi.getInstance().writeHdfs(path, "1");
		// testHDFS.writeTest();
		apiHDFS.writeKmaAwsSourceData("D:/data/samples/AWS_MIN_20120801","AWS_MIN_201208010007", 1);
		//apiHDFS.writeSkpAwsQcData("D:/data/samples/AWS_MIN_20120801", "AWS_MIN_201208010007", 1, 1);
		System.out.println("OK!");
		
		//String tmp = "/nfs_data/proc/kma/backup/03_AWS/INTP/YYYYMMDD";
				
		//System.out.println(tmp.substring((tmp.lastIndexOf("/")+1), tmp.length()));
		

		System.exit(0);
	}
}
