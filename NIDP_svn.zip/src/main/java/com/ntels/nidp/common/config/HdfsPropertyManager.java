package com.ntels.nidp.common.config;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Enumeration;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import javax.annotation.PostConstruct;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
//import org.springframework.stereotype.Service;

/**
 * 
 * 공통 프로퍼티 관리
 * 
 * @author
 * @since 2012.12.27
 * @version 0.9
 * @see
 * 
 *      <pre>
 * << 개정이력(Modification Information) >>
 * 
 *   수정일      수정자           수정내용
 *  -------    --------    ---------------------------
 *   2012.12.27  hskang          신규 작성
 * 
 * </pre>
 */

//@Service
@SuppressWarnings("unchecked")
public class HdfsPropertyManager {

	/**
	 * 로그
	 */
	private static Log log = LogFactory.getLog(HdfsPropertyManager.class);

	/**
	 * ProfService
	 */
	// @Autowired
	// public PropertyDAO dao;
	private final static String hdfsioProfPath = "hdfsio";
	private final static String hdfsioProfPath_dev = "properties/hdfsio_dev";
	private final static String dbProfPath = "properties/db";

	private static ResourceBundle hdfsioPropoperties;
	private static ResourceBundle hifdbPropoperties;

	/**
	 * prof. 정보 초기화
	 * 
	 * @return int 성공 : 1
	 */
	@PostConstruct
	public int init() {
		try {
			// 1.코드 데이터 취득
			//
			// 2. hdfsif 시스템 프로퍼티 취득
			loadHdfsIOProperties();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return 1;
	}

	/**
	 * 지정한(HDFSIO) 프로퍼티를 로드하는 메소드
	 * 
	 * @param name
	 *            프로퍼티명
	 * @return 프로퍼티클래스
	 */
	static void loadHdfsIOProperties() {
		if (hdfsioPropoperties != null) {
			ResourceBundle.clearCache();
		}

		String osName = System.getProperty("os.name");
		if (osName != null && "windows".equals(osName)) { // n개발

			log.debug("####### Local HDFSIO Properties Loading......");
			//hdfsioPropoperties = ResourceBundle.getBundle(hdfsioProfPath_dev);
			hdfsioPropoperties = ResourceBundle.getBundle(hdfsioProfPath_dev);
		} else { // 상용
			String hostName = null;
			try {
				hostName = InetAddress.getLocalHost().getHostName();
				log.debug("####### HDFSIO Properties Loading......");
				hdfsioPropoperties = ResourceBundle.getBundle(hdfsioProfPath);
			} catch (UnknownHostException e) {
				log.error("Getting HostName Error.", e);
			}

			log.debug("####### HDFSIO Properties Loading......");
			// log.debug("####### Svr #" + prodNum +
			// "Properties Loading......");
		}

		Enumeration<String> propertiesKeys = hdfsioPropoperties.getKeys();
		String key = null;
		while (propertiesKeys.hasMoreElements()) {
			key = propertiesKeys.nextElement();
			log.debug("## Configure Properties ## " + key + " : "
					+ hdfsioPropoperties.getString(key));
		}
	}

	public static ResourceBundle getMapReduceModuleProperties() {
		
		try {
			if (hdfsioPropoperties != null) {
				ResourceBundle.clearCache();
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}


		log.debug("####### Local HDFSIO Properties Loading......");
		hdfsioPropoperties = ResourceBundle.getBundle(hdfsioProfPath); // 개발/상용 구분
		
		return hdfsioPropoperties;
	}
	
	public static ResourceBundle getHifDbProperties() {
		if (hifdbPropoperties != null) {
			ResourceBundle.clearCache();
		}

		log.debug("####### Local DB Properties Loading......");
		hifdbPropoperties = ResourceBundle.getBundle(dbProfPath); // 개발/상용 구분

		return hifdbPropoperties;
	}
	
	
	

	/**
	 * hdfsif 프로퍼티 val 얻기
	 * 
	 * @param key
	 * @return
	 */
	public static String getHdfsPropertyStringValue(String key) {
		/*
		 * 
		 * try { cd = new String(
		 * systemPropoperties.getString(key).getBytes("ISO-8859-1"), "utf-8"); }
		 * catch (UnsupportedEncodingException e) { return
		 * systemPropoperties.getString(key); } return cd; } return null;
		 */
		try {
			return hdfsioPropoperties.getString(key);
		} catch (MissingResourceException e) {
			return null;
		}
	}

	/**
	 * hdfsif 프로퍼티 val 얻기
	 * 
	 * @param key
	 * @return
	 */
	public static int getHdfsPropertyIntValue(String key) {
		/*
		 * 
		 * try { cd = new String(
		 * systemPropoperties.getString(key).getBytes("ISO-8859-1"), "utf-8"); }
		 * catch (UnsupportedEncodingException e) { return
		 * systemPropoperties.getString(key); } return cd; } return null;
		 */
		try {
			return Integer.parseInt(hdfsioPropoperties.getString(key));
		} catch (MissingResourceException e) {
			return -1;
		}
	}

}
