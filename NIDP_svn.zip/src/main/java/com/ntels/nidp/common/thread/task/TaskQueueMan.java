package com.ntels.nidp.common.thread.task;

import java.util.*;

import com.ntels.nidp.common.log.LogManager;

public class TaskQueueMan {
	//static LogManager log = new LogManager("ntels.nidp.platform");
    
	protected static Vector queue = new Vector();
	protected String name;
	
	public TaskQueueMan() {
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public synchronized void putTask(Task task) {
		queue.add(task);
		notifyAll();
	}
	
	public synchronized Task getTask() {
		try {
			while(queue.size() == 0) {
				//if(log.isDebugEnabled()) log.debug("getTask() wait..");
				wait();
			}
		} catch(InterruptedException ie) {
		}
		
		Task task = (Task)queue.remove(0);
		
		return task;
	}
}
