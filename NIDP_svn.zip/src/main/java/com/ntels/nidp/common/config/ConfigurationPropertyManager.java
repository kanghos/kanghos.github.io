package com.ntels.nidp.common.config;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Enumeration;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import javax.annotation.PostConstruct;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 
 * 공통 프로퍼티 매니저
 * 
 * @author
 * @since 2012.12.27
 * @version 0.9
 * @see
 * 
 *      <pre>
 * << 개정이력(Modification Information) >>
 * 
 *   작성일                      작성자                         내용
 *  -------    --------    ---------------------------
 *   2012.12.27  hskang          신규생성
 * 
 * </pre>
 */

//@Service
@SuppressWarnings("unchecked")
public class ConfigurationPropertyManager {

	/**
	 * 로그
	 */
	private static Log log = LogFactory.getLog(ConfigurationPropertyManager.class);

	/**
	 * ProfService
	 */
	// @Autowired
	// public PropertyDAO dao;
	private final static String configProfPath = "conf/configuration";

	private static ResourceBundle configPropoperties;

	/**
	 * prof.
	 * 
	 * @return int
	 */
	@PostConstruct
	public int init() {
		try {
			// 1.코드 
			//
			// 2. hdfsif 취득
			loadConfigProperties();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return 1;
	}

	static void loadConfigProperties() {
		if (configPropoperties != null) {
			ResourceBundle.clearCache();
		}

		String osName = System.getProperty("os.name");
		if (osName != null && "windows".equals(osName)) { // none

			log.debug("####### Local config Properties Loading......");
			configPropoperties = ResourceBundle.getBundle(configProfPath);
		} else { // 개발
			String hostName = null;
			try {
				hostName = InetAddress.getLocalHost().getHostName();
				log.debug("####### config Properties Loading......");
				configPropoperties = ResourceBundle.getBundle(configProfPath);
			} catch (UnknownHostException e) {
				log.error("Getting HostName Error.", e);
			}

			log.debug("####### config Properties Loading......");
			// log.debug("####### Svr #" + prodNum +
			// "Properties Loading......");
		}

		Enumeration<String> propertiesKeys = configPropoperties.getKeys();
		String key = null;
		while (propertiesKeys.hasMoreElements()) {
			key = propertiesKeys.nextElement();
			log.debug("## Configure Properties ## " + key + " : "
					+ configPropoperties.getString(key));
		}
	}

	/**
	 * hdfsif 
	 * 
	 * @param key
	 * @return
	 */
	public String getValue(String key) {
		/*
		 * 
		 * try { cd = new String(
		 * systemPropoperties.getString(key).getBytes("ISO-8859-1"), "utf-8"); }
		 * catch (UnsupportedEncodingException e) { return
		 * systemPropoperties.getString(key); } return cd; } return null;
		 */
		try {
			return configPropoperties.getString(key);
		} catch (MissingResourceException e) {
			return null;
		}
	}

}
