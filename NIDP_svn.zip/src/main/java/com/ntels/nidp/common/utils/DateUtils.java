package com.ntels.nidp.common.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Date Utils
 * @author 
 */
public class DateUtils {
	private final static String DEFAULT_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS";
	private final static String TWITTER="EEE MMM dd HH:mm:ss ZZZZZ yyyy";
	//"yyyyMMdd hhmmssZ"
	
	public static String getDefaultFormat() {
		return DEFAULT_DATE_FORMAT;
	}

	public static TimeZone getTimeZone() {
		return TimeZone.getDefault();
	}

	public static String getCurrentTime() {
		return getCurrentTime(getDefaultFormat());
	}

	public static String getCurrentTime(String formatter) {
		SimpleDateFormat fmt = new SimpleDateFormat(formatter);
		fmt.setTimeZone(getTimeZone());

		return fmt.format(new java.util.Date(System.currentTimeMillis()));
	}

	public static java.util.Date getCurrentDate() {
		return new java.util.Date(System.currentTimeMillis());
	}

	public static java.util.Date getDate(String dt) {
		Calendar cal = Calendar.getInstance();
		cal.set(Integer.valueOf(dt.substring(0, 4)).intValue(), 
				Integer.valueOf(dt.substring(4, 6)).intValue() - 1,
				Integer.valueOf(dt.substring(6, 8)).intValue(), 
				Integer.valueOf(dt.substring(8, 10)).intValue(), 
				Integer.valueOf(dt.substring(10, 12)).intValue(), 
				Integer.valueOf(dt.substring(12, 14)).intValue());
		return cal.getTime();
	}
	
	public static String getStringDateFormat(String dt, String foramt) {
		return convertFormat(getDate(dt), foramt);
	}
	
	public static String adSecond(String dt, long second) {
		Date tempDate = getDate(dt);
		return convertFormat(tempDate.getTime() - (second*1000), "yyyyMMddHHmmss");
	}
	
	public static String adSecondPlus(String dt, long second) {
		Date tempDate = getDate(dt);
		return convertFormat(tempDate.getTime() + (second*1000), "yyyyMMddHHmmss");
	}
	
	public static long betweenSecond(String from, String to) {
		return betweenSecond(getDate(from), getDate(to));
	}

	public static long betweenSecond(java.util.Date from, java.util.Date to) {
		return new Double(Math.ceil((to.getTime() - from.getTime()) / 1000)).longValue();
	}

	public static String convertFormat(long dt, String formatter) {
		return convertFormat(toUtilDate(dt), formatter);
	}

	public static String convertFormat(java.util.Date dt, String formatter) {
		SimpleDateFormat sdf = new SimpleDateFormat(formatter);
		return sdf.format(dt);
	}

	public static java.util.Date toUtilDate(long dt) {
		return new java.util.Date(dt);
	}
	
	public static long diffOfSecond(String begin, String end) throws Exception {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		Date beginDate = formatter.parse(begin);
	    Date endDate = formatter.parse(end);
	    long diff = endDate.getTime() - beginDate.getTime();
	    long diffSecond = diff / 1000;
	    return diffSecond;
	}
	
	
	public static String transfromTwitterDate(String dateTime, String destFrommat) throws ParseException {

		SimpleDateFormat formatter = new SimpleDateFormat(TWITTER,Locale.ENGLISH);
		
		try {
			formatter.setLenient(true);
			Date dtime = (Date)formatter.parse(dateTime);
			return new SimpleDateFormat(destFrommat).format(dtime);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		formatter = null;
		return dateTime;
	}
}
