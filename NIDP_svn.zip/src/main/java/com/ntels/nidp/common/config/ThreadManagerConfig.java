package com.ntels.nidp.common.config;

import java.util.*;

import com.ntels.nidp.common.thread.ThreadManager;

public class ThreadManagerConfig {
	protected List list = new ArrayList();
	
	public ThreadManagerConfig() {}
	
	public void addThreadManager(ThreadManager threadManager) {
		list.add(threadManager);
	}
	
	public List getThreadManager() {
		return list;
	}
}
