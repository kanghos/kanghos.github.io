package com.ntels.nidp.common.thread.task;

public class Status {
	public static final int READY = 0;
	public static final int RUN = 1;
}
