package com.ntels.nidp.common.thread.action;

import java.util.*;

import com.ntels.nidp.common.log.LogManager;
import com.ntels.nidp.common.thread.task.Task;
import com.ntels.nidp.common.utils.StringUtil;


/**
 * 결과 처리
 * 
 * @author hskang
 *
 */
public class ResponseTask extends Task {
	static LogManager log = new LogManager(LogManager.NTELS_NIDP_SYS);
	private Request request;
	
	public ResponseTask(Request req) {
		this.request = req;
	}
	
	public void execute() {
		
		Map responseMap = new HashMap();
		boolean isEndOfResponse = true;
		
		try {
			
			responseMap = request.getResponseMap();
			
			//ResponseTask responseMap: {job_type=real_time, TO_HDFS_REAL_FILE=null, command=INTERPOLATION_HANDLER}
			//System.out.println("ResponseTask responseMap: " + responseMap);
			
			String command  = StringUtil.rmNullTrim((String) responseMap.get("command"));
			String job_type = StringUtil.rmNullTrim((String) responseMap.get("job_type"));
			
			if (command.equals("INTERPOLATION_HANDLER")) {
				
				if (job_type.equals("real_time")) {
					
					String path = (String) responseMap.get("TO_HDFS_REAL_FILE");
				}
				else if (job_type.equals("delay_time")) {
					
				}
			}
			else if (command.equals("QC_HANDLER")) {
				if (job_type.equals("real_time")) {
					
				}
				else if (job_type.equals("delay_time")) {
					
				}
			}
			
			
			isEndOfResponse = request.isEndOfResponse();
			
		} catch(Exception e) {
			log.error("ResponseTask execute ERROR:"+e.getMessage());
			log.recordException(e);
			responseMap.put("return_code", -1);
			responseMap.put("return_msg", e.getMessage());
		}
		
		request.setResponseTime();
		
	}

}
