package com.ntels.nidp.common.utils;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.hive.ql.parse.SemanticException;

import com.ntels.nidp.common.log.LogManager;
import com.ntels.nidp.mvc.comp.hive.domain.TableVo;

/**
 * Hive JDBC Client (Singleton)
 * @author
 */
public class ApiHiveSQL {
	private static LogManager log = new LogManager(LogManager.NTELS_NIDP_ANALYZER);
	private volatile static ApiHiveSQL instance;
	
	public ApiHiveSQL(Singleton singleton) {
	}
	
	public static ApiHiveSQL getInstance() {
		if(instance == null)
			synchronized (ApiHiveSQL.class) {
				if(instance == null)
					instance = new ApiHiveSQL(new Singleton());
			}
		return instance;
	}
	
	private static class Singleton {
		public Singleton() {}
	}
	
	private static final ApiHiveConnecter apiJDBCHiveBase = ApiHiveConnecter.getInstance();
	
	/**
	 * createTable
	 * @author
	 * @param tableInfo	ex) test (key int, value string)
	 * @throws SemanticException 
	 */
	public boolean createTable(String tableInfo){
		log.debug("ApiJDBCHive createTable()");
		return apiJDBCHiveBase.getSQL("CREATE EXTERNAL TABLE " + tableInfo);
	}
	
	/**
	 * create EXTERNAL Table
	 * @author
	 * @param tableInfos	ex) test (key int, value string)
	 * @param hdfsPath		ex) /user/chris/datastore/user/
	 * @throws SemanticException 
	 */
	public boolean createExternalTable(String tableInfo, String hdfsPath) {
		log.debug("ApiJDBCHive createExternalTable()");
		return apiJDBCHiveBase.getSQL("CREATE EXTERNAL TABLE " + tableInfo + " LOCATION '" + hdfsPath + "'");
	}
	
	/**
	 * create EXTERNAL Table
	 * @author 
	 * @param tableInfos	ex) test (key int, value string)
	 * @param rowFormat		ex) ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' STORED AS TEXTFILE
	 * @param hdfsPath		ex) /user/chris/datastore/user/
	 * @throws SemanticException 
	 */
	public boolean createExternalTable(String tableInfo, String rowFormat, String hdfsPath) {
		log.debug("ApiJDBCHive createExternalTable()");
		return apiJDBCHiveBase.getSQL("CREATE EXTERNAL TABLE " + tableInfo + " " + rowFormat + " LOCATION '" + hdfsPath + "'");
	}
	
	/**
	 * create table for csv file
	 * @param tableVo
	 * @return
	 * @throws SemanticException 
	 */
	public boolean createExternalTableForCSV(TableVo tableVo) {
		log.debug("ApiJDBCHive createExternalTable()");
		return apiJDBCHiveBase.getSQL("create table " + tableVo.getTableName() +" (" + tableVo.getColumns() +") row format delimited fields terminated by ',' lines terminated by '\n' stored as textfile");
	}
	
	/**
	 * dataLoad
	 * @author 
	 * @param tableName ex) user
	 * @param localPath	ex) /user/chris/data/testdata
	 * @throws SemanticException 
	 */
	public boolean dataLoad(String tableName, String localPath) {
		log.debug("ApiJDBCHive dataLoad()");
		return apiJDBCHiveBase.getSQL("LOAD DATA LOCAL INPATH  '" + localPath + "' INTO TABLE " + tableName);
	}
	
	/**
	 * 기존에 있는 파일을 지우고 현재 올린파일의 데이타만 insert 한다..
	 * 하나의 테이블에 여러 파일을 올리는 경우에 사용하지 않는다. 
	 * @param tableName
	 * @param localPath
	 * @return
	 */
	public boolean dataLoadOverWrite(String tableName, String localPath) {
		log.debug("ApiJDBCHive dataLoad()");
		return apiJDBCHiveBase.getSQL("LOAD DATA LOCAL INPATH  '" + localPath + "' OVERWRITE INTO TABLE " + tableName);
	}
	
	/**
	 * select Table
	 * @author 
	 * @param sql	ex) select a, b, c from testTable where a = 1
	 * @param columnLabelList ex) a, b, c ... (List<String>)
	 */
	public Map<String, String> selectTable(String sql, List<String> columnLabelList) {
		log.debug("ApiJDBCHive selectTable()");
		return apiJDBCHiveBase.getSQL(sql, columnLabelList);
	}
	
	/**
	 * get table rows
	 * @param sql
	 * @param columnLabelList
	 * @return  Map's key = column name, value = column value.
	 */
	public List<Map<String, String>> selectTableAsList(String sql, List<String> columnLabelList) {
		log.debug("ApiJDBCHive selectTable()");
		return apiJDBCHiveBase.getSQLAsList(sql, columnLabelList);
	}
	
	/**
	 * get Table list
	 * @author
	 * @param tableName	ex) show tables 'tableName'
	 * @return name of tables.
	 */
	public List<String> getTables(String sql) {
		log.debug("ApiJDBCHive getTable()");
		return apiJDBCHiveBase.getSQLAsList(sql);
	}
	
	/**
	 * Drop table
	 * @param tableName
	 * @return
	 * @throws SemanticException 
	 */
	public boolean dropTable(String tableName){
		log.debug("ApiJDBCHive getTable()");
		return apiJDBCHiveBase.getSQL("DROP TABLE "+tableName);
	}
	
	/**
	 * 해당 테이블의 속성(컬럼네임, 타입, 코멘트)를 반환하는 메소드
	 * @param tableName
	 * @return 해당 테이블의 속성(컬럼네임, 타입, 코멘트)를 반환. Map key=colunmName, type, comment 만일 
	 */
	public List<Map<String, String>> describeTable(String tableName) {
		log.debug("ApiJDBCHive getTable()");
		List<String> columnLabelList = new ArrayList<String>();
		columnLabelList.add("columnName");
		columnLabelList.add("type");
		columnLabelList.add("comment");
		return apiJDBCHiveBase.getSQLAsList("DESCRIBE "+tableName, columnLabelList);
	}

	/**
	 * select query문을 처리하고 결과를 csv 파일로 생성한다.
	 * @param sql
	 * @param outputFilePath
	 * @return
	 */
	public boolean ouputFileAsCSV(String sql, String outputFilePath) {
		log.debug("ApiJDBCHive getCSVFile()");
		return apiJDBCHiveBase.ouputFileAsCSV(sql, outputFilePath);
	}
	
	public String getOutputFilePath(String fileName){
		return apiJDBCHiveBase.getOutputFilePath(fileName);
	}
	
	public boolean isTable(String tableName){
		return apiJDBCHiveBase.getSQL("DESCRIBE "+tableName);
	}

	public void alterReplaceColumns(String tableName, String columns) {
		String replaceColumns = "ALTER TABLE {0} REPLACE COLUMNS ({1})";
		apiJDBCHiveBase.getSQL(MessageFormat.format(replaceColumns, tableName, columns));
	}

	public void alterRenameTable(String tableName, String newTableName) {
		String renameTable = " ALTER TABLE {0} RENAME TO {1}";
		apiJDBCHiveBase.getSQL(MessageFormat.format(renameTable, tableName, newTableName));
	}
	
}
