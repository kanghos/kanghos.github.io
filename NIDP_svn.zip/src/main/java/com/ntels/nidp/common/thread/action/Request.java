package com.ntels.nidp.common.thread.action;

import java.util.*;

/**
 * @author hskang
 *
 */
public class Request {
	private Map requestMap;
	private Map responseMap;
	private long requestTime;
	private long responseTime;
    protected boolean isEndOfResponse = true;
    protected boolean isOneWayRequest = false;
	
	public Request() {
		this.requestTime = System.currentTimeMillis();
		this.responseTime = System.currentTimeMillis();
	}

	public Map getRequestMap() {
		return requestMap;
	}

	public void setRequestMap(Map requestMap) {
		this.requestMap = requestMap;
	}

	public Map getResponseMap() {
		return responseMap;
	}

	public void setResponseMap(Map responseMap) {
		this.responseMap = responseMap;
	}

	public long getResponseTime() {
		return responseTime;
	}

	public void setResponseTime() {
		this.responseTime = System.currentTimeMillis();
	}

	public long getRequestTime() {
		return requestTime;
	}
	
	public long getDurationTime() {
		long duration = responseTime - requestTime;
		return duration;
	}

	public boolean isEndOfResponse() {
		return isEndOfResponse;
	}

	public void setEndOfResponse(boolean isEndOfResponse) {
		this.isEndOfResponse = isEndOfResponse;
	}

	public boolean isOneWayRequest() {
		return isOneWayRequest;
	}

	public void setOneWayRequest(boolean isOneWayRequest) {
		this.isOneWayRequest = isOneWayRequest;
	}

}
