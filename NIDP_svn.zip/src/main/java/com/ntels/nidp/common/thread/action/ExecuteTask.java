package com.ntels.nidp.common.thread.action;

import java.util.*;

import com.ntels.nidp.common.config.CommandHandlerConfig;
import com.ntels.nidp.common.config.ConfigurationLoader;
import com.ntels.nidp.common.handler.AbstractHandler;
import com.ntels.nidp.common.handler.CommandManager;
import com.ntels.nidp.common.log.LogManager;
import com.ntels.nidp.common.thread.task.Task;

/**
 * 
 * Handler Invoker
 * 
 * @author hskang
 *
 */
public class ExecuteTask extends Task {
	static LogManager log = new LogManager(LogManager.NTELS_NIDP_SYS);
	private Request request;
//	private CommandHandlerConfig commandHandlerConfig;
	private AbstractHandler abstractHandler;
	
	public ExecuteTask(Request req) {
		this.request = req;
	}
	
	public void execute() {
		
		Map requestMap = null;
		Map responseMap = new HashMap();
		
		try {
			abstractHandler = getCommandHandler();
			requestMap = request.getRequestMap();
			responseMap = abstractHandler.doHandle(requestMap);
		} catch(Exception e) {
			log.error("ExecuteTask execute ERROR:"+e.getMessage());
			log.recordException(e);
			responseMap.put("return_code", -1);
			responseMap.put("return_msg", e.getMessage());
		}

		if(request != null) request.setResponseMap(responseMap);
		
		Work.getInstance().makeResponse(request);
	}
	
	public AbstractHandler getCommandHandler() throws Exception {
		String id = (String) request.getRequestMap().get("command");
		
		CommandHandlerConfig commandHandlerConfig = ConfigurationLoader.getCommandHandlerConfig();
		CommandManager command = commandHandlerConfig.getCommand(id);
		abstractHandler = command.getHandlerInstance();
		
		return abstractHandler;
	}
}
