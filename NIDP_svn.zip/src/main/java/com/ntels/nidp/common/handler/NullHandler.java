package com.ntels.nidp.common.handler;

import java.util.*;

import com.ntels.nidp.common.log.LogManager;

public class NullHandler extends AbstractHandler {
	static LogManager log = new LogManager(LogManager.NTELS_NIDP_SYS);
	
	public Map doHandle(Map map) {
		map.put("command", "NullHandler");
		map.put("content", "");
		map.put("return_code", 1);
		map.put("return_msg", "");
		
		
		return map;
	}

}
