package com.ntels.nidp.common.handler;

import java.net.InetAddress;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 스케줄러가 정해진 시간에 호출하는 Handler 최상위 추상 클래스
 * 
 * @author hskang
 *
 */
public abstract class AbstractHandler {
	
	/**
	 * HADOOP 사용 여부 (개발/테스트시 false로 바꾸어 사용)
	 */
	protected static boolean hadoopEnabled = true;
	
	static {
		
		try {
			if ("khc".equalsIgnoreCase(InetAddress.getLocalHost().getHostName().substring(0,3))) {
				hadoopEnabled = false;
			}
		} catch (Exception e) {
		}
	}

	/**
	 * 로깅 클래스
	 */
	static Log log = LogFactory.getLog(AbstractHandler.class);
	
	/**
	 * 스케줄러에서 정해진 시간에 호출하는 메소드
	 *  
	 * @param map Job을 수행하기 위한 인자값 Map
	 * @return 결과값 Map
	 */
	public abstract Map doHandle(Map map);
}
