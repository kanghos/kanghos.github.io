package com.ntels.nidp.common.config;

import java.util.*;

import javax.security.auth.login.Configuration;


import com.ntels.nidp.common.log.LogManager;


public class ConfigurationLoader {
	
	/**
	 * 공통 상수 클래스
	 * 
	 * @author hskang
	 *
	 */
	public class Constants {
			
			/**
			 * HTTP CONNECTION TIMEOUT 문자열
			 */
			public static final String HTTP_CONNECTION_TIMEOUT = "HTTP_CONNECTION_TIMEOUT";
			
			/**
			 * HTTP_READ_TIMEOUT 문자열
			 */
			public static final String HTTP_READ_TIMEOUT = "HTTP_READ_TIMEOUT";
			
			/**
			 * HADOOP API 파라미터 구분값 - 실시간
			 */
			public static final int HDFS_PARAM_REALTIME  = 1;
			
			/**
			 * HADOOP API 파라미터 구분값 - 비실시간
			 */
			public static final int HDFS_PARAM_NONREALTIME = 0;
	}
	
	static LogManager log = new LogManager(LogManager.NTELS_NIDP_SYS);
    
    private static CommandHandlerConfig commandHandlerConfig;
    private static ThreadManagerConfig threadManagerConfig;
	private static Properties sysProps;
	
	public ConfigurationLoader() {
		try {
			//log.info("Server Configuration[ThreadManager] loading complete");
			commandHandlerConfig = CommandHandlerConfigDigester.digest();
			log.info("Server Configuration[CommandHandler] loading complete");
			
			threadManagerConfig = ThreadManagerConfigDigester.digest();
			log.info("Server Configuration[ThreadManager] loading complete");
		} catch(Exception e) {
			log.error("ConfigurationLoader ERROR : "+e.getMessage());
		}
	}
	
	public static CommandHandlerConfig getCommandHandlerConfig() {
		return commandHandlerConfig;
	}
	
	public static ThreadManagerConfig getThreadManagerConfig() {
		return threadManagerConfig;
	}
	
	public static Properties getSysProps() {
		return sysProps;
	}

	public void setSysProps(Properties sysProps_arg) {
		sysProps = sysProps_arg;
	}
	
	public static int getHttpConnectionTimeout() {
		return Integer.parseInt(sysProps.getProperty(Constants.HTTP_CONNECTION_TIMEOUT));
	}

	public static int getHttpReadTimeout() {
		return Integer.parseInt(sysProps.getProperty(Constants.HTTP_READ_TIMEOUT));
	}

	public static void main(String[] args) {
		ConfigurationLoader configurationLoader = new ConfigurationLoader();
	}
}
