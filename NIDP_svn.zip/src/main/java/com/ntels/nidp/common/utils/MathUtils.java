/* TweetTracker. Copyright (c) Arizona Board of Regents on behalf of Arizona State University
 * @author shamanth
 */
package com.ntels.nidp.common.utils;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MathUtils
{
	/**
	 * @param d
	 * @param n
	 * @return
	 */
	public static double round(double d, int n) {
	      return Math.round(d * Math.pow(10, n)) / Math.pow(10, n);
	}
	
	
}
