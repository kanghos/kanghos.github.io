/* TweetTracker. Copyright (c) Arizona Board of Regents on behalf of Arizona State University
 * @author shamanth
 */
package com.ntels.nidp.common.utils;

public class OAuthUtils
{
    //Please replace the Consumer key and secret to the one representing your application.
    public static final String CONSUMER_SECRET = "9ber9pJ9V2A5Ua8bixOc9qvyxbVobizuvKAoPEIGR0";//"PPCTObQGbGm1gkNvdJiTPKhoTksG787RTBwardkbM";
    public static final String CONSUMER_KEY = "Y2rBHRHBTRkSli7VgKxig";//"L8CRRCUoRl3xcZ9bdrfUw";
    public static final String REQUEST_TOKEN_URL = "https://twitter.com/oauth/request_token";
    public static final String AUTHORIZE_URL = "https://twitter.com/oauth/authorize";
    public static final String ACCESS_TOKEN_URL = "https://twitter.com/oauth/access_token";

    
    //Use a JFIG file for all the configurations
    public void ReadApplicationIdentity()
    {
        
    }
}
