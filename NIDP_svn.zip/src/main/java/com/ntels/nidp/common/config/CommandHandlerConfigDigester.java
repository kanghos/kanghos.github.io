package com.ntels.nidp.common.config;

import java.io.File;

import org.apache.commons.digester.Digester;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ntels.nidp.common.handler.CommandManager;
import com.ntels.nidp.common.log.LogManager;

/**
 * @author hskang
 *
 */
public class CommandHandlerConfigDigester {
	static LogManager log = new LogManager(LogManager.NTELS_NIDP_SYS);
	
	public CommandHandlerConfigDigester() {
	}
	
	public static CommandHandlerConfig digest() throws Exception {
		File file = new File(Thread.currentThread().getContextClassLoader().getResource("conf/handler/handler.xml").getFile());
		
		return digest(file);
	}
	
	public static CommandHandlerConfig digest(File file) throws Exception {
		Digester digester = new Digester();
		digester.setValidating(false);
		
		digester.addObjectCreate("CommandHandlerConfig", CommandHandlerConfig.class);
		digester.addObjectCreate("CommandHandlerConfig/Command", CommandManager.class);
		digester.addSetProperties("CommandHandlerConfig/Command", "id", "id");
		digester.addSetProperties("CommandHandlerConfig/Command", "handler", "handler");
		digester.addSetNext("CommandHandlerConfig/Command", "addCommand");
		
		try {
			CommandHandlerConfig dataconfig = (CommandHandlerConfig) digester.parse(file);
			return dataconfig;
		} catch(Exception e) {
			throw new Exception("CommandHandlerConfig Config Error : "+e.getMessage(), e);
		}
	}

	public static void main(String[] args) {
		try {
			CommandHandlerConfig commandHandlerConfig = CommandHandlerConfigDigester.digest();
			System.out.println(commandHandlerConfig.getCommandMap().size());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
