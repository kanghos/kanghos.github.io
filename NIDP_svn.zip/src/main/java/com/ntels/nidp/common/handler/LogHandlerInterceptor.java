package com.ntels.nidp.common.handler;

import java.net.UnknownHostException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Service;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

/**
 * LogHandlerInterceptor
 * 
 * @author hskang
 * @modifier hskang
 * @created 2012. 7. 20.
 */
@Service("logHandlerInterceptor")
public class LogHandlerInterceptor extends HandlerInterceptorAdapter {

	// private static Mongo mDB;

	// private static String MONGODB_SVRIP = "211.115.221.86";

	private static String MONGODB_SVRIP = "192.168.1.96";

	public void LogHandlerIntercepter() throws UnknownHostException {
		// mDB = new Mongo(MONGODB_SVRIP, 27017);

	}

	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		//

		return true;
	}
}
