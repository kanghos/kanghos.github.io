package com.ntels.nidp.common.thread.action;

import java.util.Map;

import com.ntels.nidp.common.log.LogManager;
import com.ntels.nidp.common.thread.action.ExecuteTask;
import com.ntels.nidp.common.thread.action.Request;
import com.ntels.nidp.common.thread.action.RequestTask;
import com.ntels.nidp.common.thread.action.ResponseTask;
import com.ntels.nidp.common.thread.task.TaskThreadPool;
import com.ntels.nidp.common.thread.task.TaskThreadPoolManager;

/**
 * Working TASK를 Thread로 태우는 역할
 * 
 * @author hskang
 *
 */
public class Work {
	
	private static LogManager log = new LogManager(LogManager.NTELS_NIDP_SYS);
	
	private static Work work = new Work();
	protected TaskThreadPool taskThreadPool;
	
	private Work() {
	}
	
	public static Work getInstance() {
		return work;
	}
	
	public void makeRequest(Map map) {
		
		RequestTask requestTask = new RequestTask(map);
//		session.setAttribute("requestTask", requestTask);
		
		if (taskThreadPool == null) {
			this.taskThreadPool = TaskThreadPoolManager.getTaskThreadPool(TaskThreadPoolManager.TASK_THREAD);
		}
		taskThreadPool.addTask(requestTask);
	}
	
	protected void makeExcute(Request req) {
		
		ExecuteTask executeTask = new ExecuteTask(req);
		taskThreadPool.addTask(executeTask);
	}
	
	protected void makeResponse(Request req) {
		
		ResponseTask responseTask = new ResponseTask(req);
		taskThreadPool.addTask(responseTask);
	}
}
