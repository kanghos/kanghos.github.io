package com.ntels.nidp.init;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import com.ntels.nidp.common.config.ConfigurationLoader;
import com.ntels.nidp.common.log.LogManager;
import com.ntels.nidp.common.thread.task.TaskThreadPoolManager;

/**
 * @author hskang
 *
 */
public class InitServlet extends HttpServlet{
			
	private static final long serialVersionUID = 1L;
	private final LogManager log = new LogManager(LogManager.NTELS_NIDP_SYS);
	private final boolean isInfoEnabled = log.isInfoEnabled();

	/** The appPath */
	private static String appPath = null;
	private ConfigurationLoader configLoader;
	private TaskThreadPoolManager taskThreadPoolManager;
		
		
	public InitServlet() {
		super();
	}

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);

			try {
				
				//*****************************************************//
				//*****************  Configuration  *******************//
				//*****************************************************//

				appPath = config.getServletContext().getRealPath("/");
				if (log.isInfoEnabled()) {
					log.info("#InitServlet#(init) appPath: " + appPath);
				}

				File file = new File(Thread.currentThread().getContextClassLoader()
						.getResource("conf/network.properties").getFile());
				Properties props = new Properties();
				props.load(new FileInputStream(file));
				configLoader = new ConfigurationLoader();
				taskThreadPoolManager = new TaskThreadPoolManager();
				
				/*
				 * 2013.12.11 임시로 주석처리 테스트 완료후 release
				taskThreadPoolManager.setConfigLoader(configLoader);
				taskThreadPoolManager.createTaskThreadPool();
				*/
			} catch (Exception e) {
				log.recordException(e);
			}
			
		}

		@Override
		public void destroy() {
			super.destroy();
		}
	}